/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.common.Mod$EventHandler
 *  net.minecraftforge.fml.common.Mod$Instance
 *  net.minecraftforge.fml.common.event.FMLInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPostInitializationEvent
 *  net.minecraftforge.fml.common.event.FMLPreInitializationEvent
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package it.make;

import it.make.TweaksClient;
import it.make.api.i18n.I18N;
import it.make.api.managers.BreakManager;
import it.make.api.managers.ColorManager;
import it.make.api.managers.CommandManager;
import it.make.api.managers.ConfigManager;
import it.make.api.managers.EventManager;
import it.make.api.managers.FileManager;
import it.make.api.managers.FriendManager;
import it.make.api.managers.HoleManager;
import it.make.api.managers.InventoryManager;
import it.make.api.managers.ModuleManager;
import it.make.api.managers.PacketManager;
import it.make.api.managers.PositionManager;
import it.make.api.managers.PotionManager;
import it.make.api.managers.RotationManager;
import it.make.api.managers.ServerManager;
import it.make.api.managers.SpeedManager;
import it.make.api.managers.TextManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(modid="makecc", name="Make.Life", version="0")
public class Client {
    public static final String MODID = "makecc";
    public static final String MODNAME = "Make.Life";
    public static final String MODVER = "0";
    public static final String FULLMODEVER = "Make.Life 0";
    public static final String CFGPATH = "MakeCat/";
    public static final String CFGFOLDER = "MakeCat";
    public static final Logger LOGGER = LogManager.getLogger((String)"Make.Life");
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static I18N i18NManager;
    public static BreakManager breakManager;
    @Mod.Instance
    public static Client INSTANCE;

    public static void load() {
        LOGGER.info("\n\nLoading Make.Life 0");
        i18NManager = new I18N();
        breakManager = new BreakManager();
        textManager = new TextManager();
        commandManager = new CommandManager();
        friendManager = new FriendManager();
        moduleManager = new ModuleManager();
        rotationManager = new RotationManager();
        packetManager = new PacketManager();
        eventManager = new EventManager();
        speedManager = new SpeedManager();
        potionManager = new PotionManager();
        inventoryManager = new InventoryManager();
        serverManager = new ServerManager();
        fileManager = new FileManager();
        colorManager = new ColorManager();
        positionManager = new PositionManager();
        configManager = new ConfigManager();
        holeManager = new HoleManager();
        LOGGER.info("Managers loaded.");
        moduleManager.init();
        LOGGER.info("Modules loaded.");
        configManager.init();
        eventManager.init();
        LOGGER.info("EventManager loaded.");
        textManager.init(true);
        moduleManager.onLoad();
        LOGGER.info("Make.Life successfully loaded!\n");
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER.info("I am gona gas you kike - Alpha432");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Client.load();
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        LOGGER.info("trying refill clientSettings");
        if (TweaksClient.setClientPre()) {
            LOGGER.info("seted");
        } else {
            LOGGER.warn("cannot set");
        }
    }
}

