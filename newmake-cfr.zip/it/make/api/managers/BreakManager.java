/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockAir
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 */
package it.make.api.managers;

import it.make.api.Wrapper;
import it.make.api.utils.M4keUtil;
import it.make.api.utils.second.m4ke.general.PairUtil;
import net.minecraft.block.BlockAir;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class BreakManager
implements Wrapper {
    private final PairUtil.Pair<Boolean, BlockPos> currentBreak = new PairUtil.Pair<Boolean, Object>(false, null);

    public void updateBreak(BlockPos pos, boolean breakWhenIsBreaking) {
        if (this.isFalse((Boolean)this.currentBreak.left) || breakWhenIsBreaking) {
            this.currentBreak.left = this.mineBlock(pos);
            this.currentBreak.right = pos;
        }
    }

    public void updateBreak(BlockPos pos) {
        this.updateBreak(pos, false);
    }

    public void updateBreak() {
        BlockPos breakPos = (BlockPos)this.currentBreak.right;
        if (!M4keUtil.isNull(breakPos)) {
            if (M4keUtil.getState(breakPos) instanceof BlockAir) {
                this.currentBreak.left = false;
                this.currentBreak.right = null;
            }
            if (this.isFalse((Boolean)this.currentBreak.left)) {
                this.currentBreak.left = this.mineBlock(breakPos);
                this.currentBreak.right = breakPos;
            }
        }
    }

    public void updateBreaks(BlockPos ... poses) {
        for (BlockPos pos : poses) {
            this.updateBreak(pos);
        }
    }

    private boolean mineBlock(BlockPos pos) {
        M4keUtil.getBlock(pos);
        EnumFacing sidehit = this.getSideHit(pos);
        EnumFacing facing = sidehit == null ? this.epsilonEF(pos) : sidehit;
        BreakManager.mc.field_71442_b.func_180512_c(pos, facing);
        return true;
    }

    public EnumFacing getSideHit(BlockPos pos) {
        return BreakManager.mc.field_71441_e.func_72933_a((Vec3d)new Vec3d((double)BreakManager.mc.field_71439_g.field_70165_t, (double)(BreakManager.mc.field_71439_g.field_70163_u + (double)BreakManager.mc.field_71439_g.func_70047_e()), (double)BreakManager.mc.field_71439_g.field_70161_v), (Vec3d)new Vec3d((double)((double)pos.func_177958_n() + 0.5), (double)((double)pos.func_177958_n() - 0.5), (double)((double)pos.func_177958_n() + 0.5))).field_178784_b;
    }

    public boolean isFalse(Boolean b) {
        return M4keUtil.isNull(b) || b == false;
    }

    public EnumFacing epsilonEF(BlockPos pos) {
        EntityPlayerSP player = BreakManager.mc.field_71439_g;
        Vec3d vector = BreakManager.getEyePosition((Entity)player).func_178786_a((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5);
        float x = (float)vector.field_72450_a;
        float y = (float)vector.field_72448_b;
        float z = (float)vector.field_72449_c;
        return EnumFacing.func_176737_a((float)x, (float)y, (float)z);
    }

    public static Vec3d getEyePosition(Entity entity) {
        return new Vec3d(entity.field_70165_t, entity.field_70163_u + (double)entity.func_70047_e(), entity.field_70161_v);
    }
}

