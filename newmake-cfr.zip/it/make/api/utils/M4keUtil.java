/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.item.Item
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3i
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.api.utils;

import it.make.api.Wrapper;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.two.BlockUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.LinkedBlockingQueue;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public final class M4keUtil
implements Wrapper {
    public static final Vec3i[] defends = new Vec3i[]{new Vec3i(0, 0, 0), new Vec3i(1, 0, 0), new Vec3i(0, 0, 1), new Vec3i(-1, 0, 0), new Vec3i(0, 0, -1)};

    public static ArrayList<BlockPos> getDefends(BlockPos main) {
        ArrayList<BlockPos> list = new ArrayList<BlockPos>();
        for (Vec3i vec : defends) {
            list.add(main.func_177971_a(vec));
        }
        return list;
    }

    public static IBlockState getState(BlockPos pos) {
        return M4keUtil.mc.field_71441_e.func_180495_p(pos);
    }

    public static Block getBlock(BlockPos pos) {
        return M4keUtil.getState(pos).func_177230_c();
    }

    public static Material getMaterial(BlockPos pos) {
        return M4keUtil.getState(pos).func_185904_a();
    }

    public static boolean isReplaceable(BlockPos pos) {
        return M4keUtil.getMaterial(pos).func_76222_j();
    }

    public static boolean isNull(Object ... objs) {
        for (Object obj : objs) {
            if (obj != null) continue;
            return true;
        }
        return false;
    }

    public static int swapPre(ITEM item) {
        return M4keUtil.swapPre(M4keUtil.findSlot(item.item));
    }

    public static int swapPre(int slot) {
        int post = M4keUtil.mc.field_71439_g.field_71071_by.field_70461_c;
        M4keUtil.swap(slot);
        return post;
    }

    public static void swap(int slot) {
        if (slot == -1) {
            return;
        }
        M4keUtil.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        M4keUtil.mc.field_71442_b.func_78765_e();
    }

    public static int findSlot(Item input) {
        if (M4keUtil.isNull(input)) {
            return -1;
        }
        for (int i = 0; i < 9; ++i) {
            Item item = M4keUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (Item.func_150891_b((Item)item) != Item.func_150891_b((Item)input)) continue;
            return i;
        }
        return -1;
    }

    public static void swapPlaceBlocks(ITEM item, BlockPos ... poses) {
        if (M4keUtil.isNull(item)) {
            M4keUtil.placeBlocks(poses);
        } else {
            M4keUtil.placeBlockIdk(M4keUtil.swapPre(item), poses);
        }
    }

    public static void swapPlaceBlocks(int slot, BlockPos ... poses) {
        M4keUtil.placeBlockIdk(M4keUtil.swapPre(slot), poses);
    }

    private static void placeBlockIdk(int pre_Post, BlockPos ... poses) {
        M4keUtil.placeBlocks(poses);
        M4keUtil.swap(pre_Post);
    }

    public static void placeBlocks(BlockPos ... poses) {
        for (BlockPos pos : poses) {
            if (!M4keUtil.isReplaceable(pos)) continue;
            BlockUtil.placeSync(pos, EnumHand.MAIN_HAND, true, true, true);
        }
    }

    public static abstract class DelayerTool<T> {
        protected final Timer timer = new Timer();
        protected T current = null;

        public final void start() {
            this.timer.reset();
            MinecraftForge.EVENT_BUS.register((Object)this);
        }

        public final void stop() {
            MinecraftForge.EVENT_BUS.unregister((Object)this);
            if (!this.isEnd()) {
                this.onAbort();
            }
        }

        @SubscribeEvent
        public final void subUpdate(UpdateWalkingPlayerEvent event) {
            if (this.isEnd()) {
                this.stop();
            } else {
                this.onUpdate();
            }
        }

        public abstract boolean isEnd();

        public abstract void onAbort();

        protected abstract void onUpdate();

        public static class DelayPlace
        extends DelayerTool<BlockPos> {
            private final long time;
            private final LinkedBlockingQueue<BlockPos> sides;

            @Override
            public boolean isEnd() {
                return this.sides.isEmpty();
            }

            @Override
            public void onAbort() {
                while (!this.isEnd()) {
                    this.placeNext();
                }
            }

            @Override
            protected void onUpdate() {
                if (!this.timer.passedMs(this.time)) {
                    return;
                }
                this.timer.reset();
                this.placeNext();
            }

            private void placeNext() {
                if (!this.isEnd()) {
                    M4keUtil.placeBlocks(this.simpleTake());
                }
            }

            public DelayPlace(long time, BlockPos ... sides) {
                this.time = time;
                this.sides = new LinkedBlockingQueue<BlockPos>(Arrays.asList(sides));
            }

            public BlockPos simpleTake() {
                try {
                    return this.sides.take();
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                    return null;
                }
            }
        }
    }

    public static class ITEM {
        public final Item item;

        public ITEM(Block block) {
            this.item = Item.func_150898_a((Block)block);
        }

        public ITEM(Item item) {
            this.item = item;
        }
    }
}

