/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils;

import java.awt.Color;

public class RainbowUtil {
    private Color color;
    private int speed;
    private int colorIndex;
    private Color[] RAINBOW_COLORS;

    public RainbowUtil(Color color, int speed, boolean setBlue) {
        this.setColor(color);
        this.setSpeed(speed);
        this.setRainbowColor(setBlue);
        this.colorIndex = 0;
    }

    public void setRainbowColor(boolean setBlue) {
        this.RAINBOW_COLORS = RainbowUtil.generateRainbowColors(setBlue);
    }

    public Color rainbow() {
        this.update();
        return this.getColor();
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return this.color;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void update() {
        this.colorIndex = (this.colorIndex + this.speed) % this.RAINBOW_COLORS.length;
        Color nextColor = this.RAINBOW_COLORS[this.colorIndex];
        int alpha = this.getColor().getAlpha();
        int red = nextColor.getRed();
        int green = nextColor.getGreen();
        int blue = nextColor.getBlue();
        this.setColor(new Color(red, green, blue, alpha));
    }

    private static Color[] generateRainbowColors(boolean setBlue) {
        int numColors = 256;
        Color[] gradientColors = new Color[numColors];
        for (int i = 0; i < numColors; ++i) {
            int red = i * 255 / (numColors - 1);
            int green = 255 - red;
            int blue = setBlue ? i : 128;
            gradientColors[i] = new Color(red, green, blue);
        }
        return gradientColors;
    }

    public static void main(String[] args2) {
        RainbowUtil rainbowUtil = new RainbowUtil(Color.BLACK, 1, true);
        for (int i = 0; i < 400; ++i) {
            Color color = rainbowUtil.rainbow();
            System.out.println("Color: " + color);
        }
    }
}

