/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 */
package it.make.api.utils.second.m4ke.render;

import it.make.api.Wrapper;
import it.make.api.utils.second.m4ke.math.FadeUtil2;
import it.make.api.utils.second.m4ke.render.ProgressRenderer;
import java.awt.Color;
import net.minecraft.util.math.BlockPos;

public class BlockAnimationMake
implements Wrapper {
    final long updateUnit;
    final FadeUtil2 fade;
    BlockPos select;
    Color color;
    int alpha;
    long united;
    int progress;

    public BlockAnimationMake(long updateUnit) {
        this(updateUnit, Color.GRAY, 100);
    }

    public static long lFromI(int i) {
        return i;
    }

    public BlockAnimationMake(long updateUnit, Color color, int alpha) {
        this.updateUnit = updateUnit;
        this.fade = new FadeUtil2(FadeUtil2.FadeMode.Fade_Both, true, 0, 100, 1);
        this.progress = (Integer)this.fade.fade().left;
        this.setColor(color, alpha);
        this.doReset();
    }

    public BlockAnimationMake(long updateUnit, Color color) {
        this(updateUnit, color, color.getAlpha());
    }

    public static BlockAnimationMake getNormalAnimation() {
        return new BlockAnimationMake(1L);
    }

    public static BlockAnimationMake getNormalAnimation(Color color) {
        return new BlockAnimationMake(1L, color);
    }

    public static BlockAnimationMake getNormalAnimation(Color color, int alpha) {
        return new BlockAnimationMake(1L, color, alpha);
    }

    public void select(BlockPos pos) {
        this.select = pos;
        this.doReset();
    }

    public void setColor(Color color, int alpha) {
        this.color = color;
        this.alpha = alpha;
    }

    public void setColor(Color color) {
        this.setColor(color, color.getAlpha());
    }

    private void doReset() {
        this.united = 0L;
    }

    public void doUpdate() {
        if (this.united < this.updateUnit) {
            ++this.united;
            return;
        }
        this.united = 0L;
        this.progress = (Integer)this.fade.fade().left;
    }

    public void doDraw() {
        if (this.select != null) {
            ProgressRenderer.draw(this.progress, this.select, this.color, this.alpha, this.fade.getIsOuting());
        }
    }
}

