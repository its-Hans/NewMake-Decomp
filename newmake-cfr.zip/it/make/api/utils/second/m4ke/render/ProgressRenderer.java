/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.client.renderer.RenderGlobal
 *  net.minecraft.client.renderer.culling.Frustum
 *  net.minecraft.client.renderer.culling.ICamera
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  org.lwjgl.opengl.GL11
 */
package it.make.api.utils.second.m4ke.render;

import it.make.api.Wrapper;
import java.awt.Color;
import java.util.Objects;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class ProgressRenderer {
    public static ICamera camera = new Frustum();

    public static void draw(int progress, BlockPos pos, Color color, int alpha, boolean reverse) {
        if (progress < 0 || progress > 100) {
            return;
        }
        if (alpha < 0 || alpha > 255) {
            return;
        }
        double ratio = (double)progress / 100.0;
        AxisAlignedBB bb = reverse ? new AxisAlignedBB((double)pos.func_177958_n(), (double)pos.func_177956_o() + (1.0 - ratio), (double)pos.func_177952_p(), (double)(pos.func_177958_n() + 1), (double)(pos.func_177956_o() + 1), (double)(pos.func_177952_p() + 1)) : new AxisAlignedBB((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p(), (double)(pos.func_177958_n() + 1), (double)pos.func_177956_o() + ratio, (double)(pos.func_177952_p() + 1));
        ProgressRenderer.drawBBFill(bb, color, alpha);
    }

    public static void drawBBFill(AxisAlignedBB BB, Color color, int alpha) {
        AxisAlignedBB bb = new AxisAlignedBB(BB.field_72340_a - Wrapper.mc.func_175598_ae().field_78730_l, BB.field_72338_b - Wrapper.mc.func_175598_ae().field_78731_m, BB.field_72339_c - Wrapper.mc.func_175598_ae().field_78728_n, BB.field_72336_d - Wrapper.mc.func_175598_ae().field_78730_l, BB.field_72337_e - Wrapper.mc.func_175598_ae().field_78731_m, BB.field_72334_f - Wrapper.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(Wrapper.mc.func_175606_aa()).field_70165_t, Wrapper.mc.func_175606_aa().field_70163_u, Wrapper.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + Wrapper.mc.func_175598_ae().field_78730_l, bb.field_72338_b + Wrapper.mc.func_175598_ae().field_78731_m, bb.field_72339_c + Wrapper.mc.func_175598_ae().field_78728_n, bb.field_72336_d + Wrapper.mc.func_175598_ae().field_78730_l, bb.field_72337_e + Wrapper.mc.func_175598_ae().field_78731_m, bb.field_72334_f + Wrapper.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
            GlStateManager.func_179097_i();
            GlStateManager.func_179118_c();
            GlStateManager.func_179129_p();
            GL11.glHint((int)3154, (int)4354);
            GlStateManager.func_179103_j((int)7425);
            GlStateManager.func_179090_x();
            GlStateManager.func_179140_f();
            GlStateManager.func_179132_a((boolean)false);
            RenderGlobal.func_189696_b((AxisAlignedBB)bb, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)alpha / 255.0f));
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179145_e();
            GlStateManager.func_179098_w();
            GlStateManager.func_179103_j((int)7424);
            GlStateManager.func_179141_d();
            GlStateManager.func_179089_o();
            GlStateManager.func_179126_j();
            GlStateManager.func_179084_k();
            GlStateManager.func_187441_d((float)1.0f);
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GlStateManager.func_179121_F();
        }
    }
}

