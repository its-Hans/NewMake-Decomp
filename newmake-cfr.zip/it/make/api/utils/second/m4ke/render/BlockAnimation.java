/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package it.make.api.utils.second.m4ke.render;

import it.make.api.Wrapper;
import it.make.api.utils.M4keUtil;
import it.make.api.utils.second.m4ke.math.FadeUtil2;
import it.make.api.utils.second.skid.RenderUtil;
import java.awt.Color;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockAnimation {
    public static final int min = 0;
    public static final int max = 1000;
    final FadeUtil2 backup;
    FadeUtil2 fade;
    BlockPos cache = null;

    public BlockAnimation(boolean unlimitFade, boolean firstIn, int speed) {
        FadeUtil2.FadeMode fm = unlimitFade ? FadeUtil2.FadeMode.Fade_Both : (firstIn ? FadeUtil2.FadeMode.Fade_In : FadeUtil2.FadeMode.Fade_Out);
        this.fade = this.backup = new FadeUtil2(fm, firstIn, 0, 1000, speed);
    }

    public int getNow() {
        return this.fade.getNow();
    }

    public double getScale() {
        return (float)this.getNow() * 0.001f;
    }

    public int update() {
        return (Integer)this.fade.fade().left;
    }

    public void select(BlockPos pos, boolean resetIf) {
        if (resetIf) {
            if (M4keUtil.isNull(this.cache, pos)) {
                this.reset();
            } else if (this.cache.func_177986_g() != pos.func_177986_g()) {
                this.reset();
            }
        }
        this.cache = pos;
    }

    public void draw(DrawMode.GenAABBMode animation, Color2 color, boolean outline, boolean fill) {
        if (this.cache == null) {
            return;
        }
        new DrawMode(this.cache, outline, fill).draw(this.getScale(), animation, color);
    }

    public void reset() {
        this.reset(false);
    }

    public void reset(boolean resetSpeed) {
        this.fade = this.backup;
        if (resetSpeed) {
            this.fade.setSpd(this.backup.getSpd());
        }
    }

    public static class DrawMode {
        final BlockPos pos;
        final boolean outline;
        final boolean fill;

        public DrawMode(BlockPos pos, boolean outline, boolean fill) {
            this.pos = pos;
            this.outline = outline;
            this.fill = fill;
        }

        public void draw(double scale, GenAABBMode mode, Color2 color) {
            AxisAlignedBB aabb;
            switch (mode) {
                default: {
                    aabb = Wrapper.mc.field_71441_e.func_180495_p(this.pos).func_185918_c((World)Wrapper.mc.field_71441_e, this.pos);
                    break;
                }
                case TWO: {
                    aabb = Wrapper.mc.field_71441_e.func_180495_p(this.pos).func_185918_c((World)Wrapper.mc.field_71441_e, this.pos).func_186662_g(scale / 2.0 - 0.5);
                    break;
                }
                case WATER: {
                    AxisAlignedBB bb = Wrapper.mc.field_71441_e.func_180495_p(this.pos).func_185918_c((World)Wrapper.mc.field_71441_e, this.pos);
                    aabb = new AxisAlignedBB(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * scale, bb.field_72334_f);
                    break;
                }
            }
            this.draw(aabb, color);
        }

        public void draw(AxisAlignedBB aabb, Color2 color) {
            if (this.outline) {
                RenderUtil.drawBBBox(aabb, color.color, color.alpha);
            }
            if (this.fill) {
                RenderUtil.drawBBFill(aabb, color.color, color.alpha);
            }
        }

        public static enum GenAABBMode {
            WATER,
            TWO;

        }
    }

    public static class Color2 {
        public final Color color;
        public final int alpha;

        public Color2(Color color) {
            this(color, color.getAlpha());
        }

        public Color2(Color color, int alpha) {
            this.color = color;
            this.alpha = alpha;
        }
    }
}

