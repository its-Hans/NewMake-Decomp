/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.render;

import it.make.api.utils.RainbowUtil;
import it.make.api.utils.second.m4ke.general.Converter;
import it.make.api.utils.second.m4ke.math.FadeUtil2;
import java.awt.Color;

public class RandomColor {
    Color color;
    int alpha;
    FadeUtil2 alphaFader;
    RainbowUtil colorFader;
    RandomMode rd;
    final long updateUnit;
    long united;

    public RandomColor(int alpha, long updateUnit, RandomMode rd) {
        this.setAlpha(alpha);
        this.updateUnit = updateUnit;
        this.setUnited(this.updateUnit);
        this.resetFader();
        this.setRd(rd);
    }

    public Color getColor(boolean refillAlpha) {
        if (refillAlpha) {
            return new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), this.alpha);
        }
        return this.color;
    }

    public Color getColor() {
        return this.getColor(true);
    }

    private void updateAlpha() {
        this.setAlpha((Integer)this.alphaFader.fade().left);
    }

    private void updateColor() {
        this.setColor(this.colorFader.rainbow());
    }

    public void doUpdate() {
        if (this.united < this.updateUnit) {
            ++this.united;
            return;
        }
        this.united = 0L;
        this.updateColor();
        this.updateAlpha();
    }

    public Color random() {
        this.doUpdate();
        return this.getColor();
    }

    public void setColor(Color color) {
        if (color == null) {
            return;
        }
        this.color = color;
    }

    public void setAlpha(int alpha) {
        this.alpha = Converter.convertVaildColorI(alpha);
    }

    public void setAlphaFadeMin(int alphaFadeMin) {
        this.alphaFader.setMin(alphaFadeMin);
    }

    public void setAlphaFadeMax(int alphaFadeMax) {
        this.alphaFader.setMax(alphaFadeMax);
    }

    public void setUnited(long united) {
        this.united = united;
    }

    public void setRd(RandomMode rd) {
        this.rd = rd;
    }

    public void resetFader() {
        this.alphaFader = new FadeUtil2.Presets.OneOfColor().getFadeUtil();
        this.colorFader = new RainbowUtil(Color.DARK_GRAY, 1, false);
    }

    public static void main(String[] args2) {
        RandomColor rc = new RandomColor(100, 1L, RandomMode.Both);
        for (int i = 0; i < 1000; ++i) {
            Color c = rc.random();
            System.out.println(c.getRed() + ", " + c.getBlue() + ", " + c.getGreen() + ", " + c.getAlpha());
        }
    }

    public static enum RandomMode {
        Rainbow,
        Fade,
        Both;

    }
}

