/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.math;

import it.make.api.utils.second.m4ke.general.Converter;
import it.make.api.utils.second.m4ke.general.PairUtil;
import java.awt.Color;

public class FadeUtil2 {
    public final FadeMode fadeMode;
    public final boolean firstIn;
    boolean isOuting;
    int now;
    int min;
    int max;
    int spd;

    public FadeUtil2(FadeMode fadeMode, boolean firstIn, int min, int max, int spd) {
        this.fadeMode = fadeMode;
        this.firstIn = firstIn;
        this.isOuting = !firstIn;
        this.min = min;
        this.max = max;
        this.now = firstIn ? min : max;
        this.spd = spd;
    }

    public PairUtil.Pair<Integer, Boolean> fade() {
        boolean isFaded;
        switch (this.fadeMode) {
            case Fade_In: {
                isFaded = this.fadeIn();
                break;
            }
            case Fade_Out: {
                isFaded = this.fadeOut();
                break;
            }
            case Fade_Both: {
                isFaded = this.fadeBoth();
                break;
            }
            default: {
                isFaded = false;
            }
        }
        return new PairUtil.Pair<Integer, Boolean>(this.getNow(), isFaded);
    }

    public int getNow() {
        return this.now;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private boolean fadeBoth() {
        if (this.isOuting) {
            if (this.fadeOut()) return true;
            this.isOuting = !this.isOuting;
            return false;
        } else {
            if (this.fadeIn()) return true;
            this.isOuting = !this.isOuting;
        }
        return false;
    }

    private boolean fadeIn() {
        if (this.now >= this.max) {
            return false;
        }
        this.setNow(this.now + this.spd);
        return true;
    }

    private boolean fadeOut() {
        if (this.now <= this.min) {
            return false;
        }
        this.setNow(this.now - this.spd);
        return true;
    }

    private void setNow(int now) {
        this.now = this.convertVaild(now);
    }

    public void setMin(int min) {
        this.min = this.convertVaild(min);
    }

    public void setMax(int max) {
        this.max = this.convertVaild(max);
    }

    public void setSpd(int spd) {
        this.spd = spd;
    }

    public int convertVaild(int value) {
        return Converter.convertVaild(value, this.min, this.max);
    }

    public boolean getIsOuting() {
        return this.isOuting;
    }

    public static void test() {
        FadeUtil2 fade = new FadeUtil2(FadeMode.Fade_Both, false, 0, 255, 2);
        for (int i = 0; i < 1000; ++i) {
            System.out.println(fade.fade().toString());
        }
    }

    public static void main(String[] args2) {
        FadeUtil2.test();
    }

    public int getMax() {
        return this.max;
    }

    public int getMin() {
        return this.min;
    }

    public int getSpd() {
        return this.spd;
    }

    public static abstract class Presets {
        public abstract FadeUtil2 getFadeUtil();

        public final int next() {
            return (Integer)this.getFadeUtil().fade().left;
        }

        public static class OneOfColor
        extends Presets {
            @Override
            public FadeUtil2 getFadeUtil() {
                return new FadeUtil2(FadeMode.Fade_Both, false, Converter.colorILimits[0], Converter.colorILimits[1], 1);
            }
        }

        public static class RainbowColor
        extends Presets {
            @Override
            public FadeUtil2 getFadeUtil() {
                return new FadeUtil2(FadeMode.Fade_Both, false, 0, 359, 1);
            }

            public Color rainbow() {
                int hue = this.next();
                float[] hsl = new float[]{hue, 1.0f, 0.5f};
                return Color.getHSBColor(hsl[0] / 360.0f, hsl[1], hsl[2]);
            }
        }
    }

    public static enum FadeMode {
        Fade_In,
        Fade_Out,
        Fade_Both,
        NO_FADE;

    }
}

