/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.general;

public class Converter {
    public static final int[] colorILimits = new int[]{0, 255};
    public static final float[] colorFLimits = new float[]{0.0f, 1.0f};

    public static int convertVaild(int value, int min, int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    public static float convertVaild(float value, float min, float max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    public static double convertVaild(double value, double min, double max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    public static int convertVaildColorI(int ci) {
        if (ci < colorILimits[0]) {
            return colorILimits[0];
        }
        if (ci > colorILimits[1]) {
            return colorILimits[1];
        }
        return ci;
    }

    public static float convertVaildColorF(float cf) {
        if (cf < colorFLimits[0]) {
            return colorFLimits[0];
        }
        if (cf > colorFLimits[1]) {
            return colorFLimits[1];
        }
        return cf;
    }
}

