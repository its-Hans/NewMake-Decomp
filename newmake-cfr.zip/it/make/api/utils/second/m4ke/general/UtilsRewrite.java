/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityExpBottle
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.item.Item
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.api.utils.second.m4ke.general;

import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.two.BlockUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class UtilsRewrite {
    static Minecraft mc = Minecraft.func_71410_x();

    public static class HelperEF {
        public static HelperEF hef;

        public HelperEF() {
            hef = new HelperEF();
        }

        public Vec3i posAdd(Vec3i pos, Vec3i pos2) {
            return new Vec3i(pos.func_177958_n() + pos2.func_177958_n(), pos.func_177956_o() + pos2.func_177956_o(), pos.func_177952_p() + pos2.func_177952_p());
        }

        public BlockPos posAdd(BlockPos pos, BlockPos pos2) {
            return new BlockPos(pos.func_177958_n() + pos2.func_177958_n(), pos.func_177956_o() + pos2.func_177956_o(), pos.func_177952_p() + pos2.func_177952_p());
        }

        public Vec3i posMinus(Vec3i pos, Vec3i pos2) {
            return new Vec3i(pos.func_177958_n() - pos2.func_177958_n(), pos.func_177956_o() - pos2.func_177956_o(), pos.func_177952_p() - pos2.func_177952_p());
        }

        public BlockPos posMinus(BlockPos pos, BlockPos pos2) {
            return new BlockPos(pos.func_177958_n() - pos2.func_177958_n(), pos.func_177956_o() - pos2.func_177956_o(), pos.func_177952_p() - pos2.func_177952_p());
        }

        public static enum facingHelper {
            NORTH(EnumFacing.NORTH),
            SOUTH(EnumFacing.SOUTH),
            WEST(EnumFacing.WEST),
            EAST(EnumFacing.EAST);

            final EnumFacing facing;

            private facingHelper(EnumFacing _facing) {
                this.facing = _facing;
            }

            public BlockPos getOffsetFac() {
                return this.getOffsets()[0];
            }

            public BlockPos getOffsetFacPos(BlockPos main) {
                return hef.posAdd(main, this.getOffsetFac());
            }

            public BlockPos getOffsetLeft() {
                return this.getOffsets()[1];
            }

            public BlockPos getOffsetLeftPos(BlockPos main) {
                return hef.posAdd(main, this.getOffsetLeft());
            }

            public BlockPos getOffsetRight() {
                return this.getOffsets()[2];
            }

            public BlockPos getOffsetRightPos(BlockPos main) {
                return hef.posAdd(main, this.getOffsetRight());
            }

            public BlockPos getOffsetForward(int forwards) {
                BlockPos forward;
                switch (this.facing) {
                    case NORTH: {
                        forward = new BlockPos(0, 0, -1 - forwards);
                        break;
                    }
                    case SOUTH: {
                        forward = new BlockPos(0, 0, 1 + forwards);
                        break;
                    }
                    case EAST: {
                        forward = new BlockPos(1 + forwards, 0, 0);
                        break;
                    }
                    case WEST: {
                        forward = new BlockPos(-1 + forwards, 0, 0);
                        break;
                    }
                    default: {
                        forward = null;
                    }
                }
                return forward;
            }

            public BlockPos getOffsetForwardPos(BlockPos main, int forwards) {
                return hef.posAdd(main, this.getOffsetForward(forwards));
            }

            public BlockPos[] getOffsets() {
                BlockPos oppoFac;
                BlockPos right;
                BlockPos left;
                BlockPos fac;
                switch (this.facing) {
                    case NORTH: {
                        fac = new BlockPos(0, 0, -1);
                        left = new BlockPos(-1, 0, -1);
                        right = new BlockPos(1, 0, -1);
                        oppoFac = new BlockPos(0, 0, 1);
                        break;
                    }
                    case SOUTH: {
                        fac = new BlockPos(0, 0, 1);
                        left = new BlockPos(1, 0, 1);
                        right = new BlockPos(-1, 0, 1);
                        oppoFac = new BlockPos(0, 0, -1);
                        break;
                    }
                    case EAST: {
                        fac = new BlockPos(1, 0, 0);
                        left = new BlockPos(1, 0, -1);
                        right = new BlockPos(1, 0, 1);
                        oppoFac = new BlockPos(-1, 0, 0);
                        break;
                    }
                    case WEST: {
                        fac = new BlockPos(-1, 0, 0);
                        left = new BlockPos(-1, 0, 1);
                        right = new BlockPos(-1, 0, -1);
                        oppoFac = new BlockPos(1, 0, 0);
                        break;
                    }
                    default: {
                        fac = null;
                        left = null;
                        right = null;
                        oppoFac = null;
                    }
                }
                return new BlockPos[]{fac, left, right, oppoFac};
            }

            public BlockPos[] getOffsetsFacPos(BlockPos main) {
                ArrayList<BlockPos> offs = new ArrayList<BlockPos>();
                for (BlockPos off : this.getOffsets()) {
                    offs.add(hef.posAdd(main, off));
                }
                return offs.toArray(new BlockPos[0]);
            }
        }
    }

    public static class PosHelper {
        EntityPlayer player;

        public PosHelper(EntityPlayer _player) {
            this.player = _player;
        }

        public void a() {
            ArrayList a = new ArrayList();
        }

        public Vec3d posEye() {
            return new Vec3d(this.player.field_70165_t, this.player.field_70163_u + (double)this.player.func_70047_e(), this.player.field_70161_v);
        }

        public Vec3d posFeet() {
            return new Vec3d(this.player.field_70165_t, this.player.field_70163_u, this.player.field_70161_v);
        }

        public Vec3d posPlayer() {
            return new Vec3d(this.player.field_70165_t, this.player.field_70163_u, this.player.field_70161_v);
        }

        public BlockPos getFeetBlock() {
            Vec3d burrow = this.posFeet();
            return new BlockPos(burrow);
        }

        public BlockPos getFaceBlock() {
            return this.getFeetBlock().func_177984_a();
        }

        public BlockPos getHeadBlock() {
            return this.getFeetBlock().func_177981_b(2);
        }

        public BlockPos surroundEast() {
            return offsets.EAST.add(this.getFeetBlock());
        }

        public BlockPos surroundWest() {
            return offsets.WEST.add(this.getFeetBlock());
        }

        public BlockPos surroundSouth() {
            return offsets.SOUTH.add(this.getFeetBlock());
        }

        public BlockPos surroundNorth() {
            return offsets.NORTH.add(this.getFeetBlock());
        }

        public BlockPos faceEast() {
            return this.surroundEast().func_177984_a();
        }

        public BlockPos faceWest() {
            return this.surroundWest().func_177984_a();
        }

        public BlockPos faceSouth() {
            return this.surroundSouth().func_177984_a();
        }

        public BlockPos faceNorth() {
            return this.surroundNorth().func_177984_a();
        }

        public BlockPos[] surroundList() {
            return new BlockPos[]{this.surroundEast(), this.surroundWest(), this.surroundSouth(), this.surroundNorth()};
        }

        public BlockPos[] pistonList() {
            return new BlockPos[]{this.faceEast(), this.faceWest(), this.faceSouth(), this.faceNorth()};
        }

        public BlockPos[] offsetList(BlockPos main) {
            return new BlockPos[]{offsets.NORTH.add(main), offsets.SOUTH.add(main), offsets.WEST.add(main), offsets.EAST.add(main), offsets.DOWN.add(main), offsets.UP.add(main)};
        }

        public BlockPos[] noHoriOffsets(BlockPos main) {
            return new BlockPos[]{offsets.NORTH.add(main), offsets.SOUTH.add(main), offsets.WEST.add(main), offsets.EAST.add(main)};
        }

        public static enum offsets {
            NORTH(0, 0, -1),
            EAST(1, 0, 0),
            SOUTH(0, 0, 1),
            WEST(-1, 0, 0),
            DOWN(0, -1, 0),
            UP(0, 1, 0);

            final int x;
            final int y;
            final int z;

            private offsets(int offX, int offY, int offZ) {
                this.x = offX;
                this.y = offY;
                this.z = offZ;
            }

            public BlockPos get() {
                return new BlockPos(this.x, this.y, this.z);
            }

            public BlockPos add(BlockPos main) {
                return UBlock.addPos(main, this.get());
            }
        }
    }

    public static class UInventory {
        public static void heldItemChange(int item, boolean setCur, boolean packet, boolean updCon) {
            if (setCur) {
                UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c = item;
            }
            if (packet) {
                UtilsRewrite.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(item));
            }
            if (updCon) {
                UtilsRewrite.mc.field_71442_b.func_78765_e();
            }
        }

        public static int itemSlot(Item input) {
            for (int i = 0; i < 9; ++i) {
                Item item = UtilsRewrite.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
                if (Item.func_150891_b((Item)item) != Item.func_150891_b((Item)input)) continue;
                return i;
            }
            return -1;
        }
    }

    public static class URotation {
        public static EnumFacing getBestFacing(BlockPos pos) {
            idk[] idks = URotation.offsetsBlockPos(pos);
            EntityPlayerSP player = UtilsRewrite.mc.field_71439_g;
            return Arrays.stream(idks).filter(idk2 -> idk2._pos != null).min(Comparator.comparingDouble(arg_0 -> URotation.lambda$getBestFacing$1((EntityPlayer)player, arg_0))).map(idk2 -> idk2._facing).orElse(null);
        }

        public static idk[] offsetsBlockPos(BlockPos pos) {
            return new idk[]{new idk(pos.func_177984_a(), EnumFacing.UP), new idk(pos.func_177977_b(), EnumFacing.DOWN), new idk(pos.func_177974_f(), EnumFacing.EAST), new idk(pos.func_177976_e(), EnumFacing.WEST), new idk(pos.func_177968_d(), EnumFacing.SOUTH), new idk(pos.func_177978_c(), EnumFacing.NORTH)};
        }

        public static void lookAtVec3d(Vec3d vec3d) {
            float[] angle = URotation.calculateAngle(UtilsRewrite.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c));
            UtilsRewrite.mc.field_71439_g.field_70125_A = angle[1];
            UtilsRewrite.mc.field_71439_g.field_70177_z = angle[0];
        }

        public static float[] calculateAngle(Vec3d from, Vec3d to) {
            double difX = to.field_72450_a - from.field_72450_a;
            double difY = (to.field_72448_b - from.field_72448_b) * -1.0;
            double difZ = to.field_72449_c - from.field_72449_c;
            double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
            float yD = (float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0));
            float pD = (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)));
            if (pD > 90.0f) {
                pD = 90.0f;
            } else if (pD < -90.0f) {
                pD = -90.0f;
            }
            return new float[]{yD, pD};
        }

        public static float[] getFacingPlace(EnumFacing facing) {
            float[] fac = new float[]{60.0f, 60.0f};
            if (facing == EnumFacing.EAST) {
                fac = new float[]{-90.0f, 5.0f};
            } else if (facing == EnumFacing.WEST) {
                fac = new float[]{90.0f, 5.0f};
            } else if (facing == EnumFacing.NORTH) {
                fac = new float[]{180.0f, 5.0f};
            } else if (facing == EnumFacing.SOUTH) {
                fac = new float[]{0.0f, 5.0f};
            }
            return fac;
        }

        public List<EnumFacing> getVisibleSides(BlockPos position) {
            ArrayList<EnumFacing> visibleSides = new ArrayList<EnumFacing>();
            Vec3d positionVector = new Vec3d((Vec3i)position).func_72441_c(0.5, 0.5, 0.5);
            double facingX = UtilsRewrite.mc.field_71439_g.func_174824_e((float)1.0f).field_72450_a - positionVector.field_72450_a;
            double facingY = UtilsRewrite.mc.field_71439_g.func_174824_e((float)1.0f).field_72448_b - positionVector.field_72448_b;
            double facingZ = UtilsRewrite.mc.field_71439_g.func_174824_e((float)1.0f).field_72449_c - positionVector.field_72449_c;
            if (facingX < -0.5) {
                visibleSides.add(EnumFacing.WEST);
            } else if (facingX > 0.5) {
                visibleSides.add(EnumFacing.EAST);
            } else if (!UtilsRewrite.mc.field_71441_e.func_180495_p(position).func_185913_b() || !UtilsRewrite.mc.field_71441_e.func_175623_d(position)) {
                visibleSides.add(EnumFacing.WEST);
                visibleSides.add(EnumFacing.EAST);
            }
            if (facingY < -0.5) {
                visibleSides.add(EnumFacing.DOWN);
            } else if (facingY > 0.5) {
                visibleSides.add(EnumFacing.UP);
            } else {
                visibleSides.add(EnumFacing.DOWN);
                visibleSides.add(EnumFacing.UP);
            }
            if (facingZ < -0.5) {
                visibleSides.add(EnumFacing.NORTH);
            } else if (facingZ > 0.5) {
                visibleSides.add(EnumFacing.SOUTH);
            } else if (!UtilsRewrite.mc.field_71441_e.func_180495_p(position).func_185913_b() || !UtilsRewrite.mc.field_71441_e.func_175623_d(position)) {
                visibleSides.add(EnumFacing.NORTH);
                visibleSides.add(EnumFacing.SOUTH);
            }
            return visibleSides;
        }

        private static /* synthetic */ double lambda$getBestFacing$1(EntityPlayer player, idk idk2) {
            return idk2._pos.func_177957_d(player.field_70165_t, player.field_70163_u + (double)player.func_70047_e(), player.field_70161_v);
        }

        public static class idk {
            BlockPos _pos;
            EnumFacing _facing;

            public idk(BlockPos pos, EnumFacing facing) {
                this._pos = pos;
                this._facing = facing;
            }
        }
    }

    public static class UBlock {
        public static List<Entity> findPosEntities(BlockPos pos) {
            return UtilsRewrite.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos));
        }

        public static BlockPos getPlayerPosition(EntityPlayer player) {
            if (player == null) {
                return null;
            }
            return new BlockPos(player.field_70165_t, player.field_70163_u + 0.5, player.field_70161_v);
        }

        public static String getPosString(BlockPos pos) {
            return UBlock.getPosString(pos, " ");
        }

        public static String getPosString(BlockPos pos, String connect) {
            return pos.func_177958_n() + connect + pos.func_177956_o() + connect + pos.func_177952_p();
        }

        public static BlockPos addPos(BlockPos pos1, BlockPos pos2) {
            int x = pos1.func_177958_n() + pos2.func_177958_n();
            int y = pos1.func_177956_o() + pos2.func_177956_o();
            int z = pos1.func_177952_p() + pos2.func_177952_p();
            return new BlockPos(x, y, z);
        }

        public static void placeBlock(BlockPos pos, EnumFacing placeFacing, Block blockType, boolean swap, boolean swapback, boolean packet, boolean rotate) {
            if (pos == null || blockType == null) {
                return;
            }
            int blockSlot = UInventory.itemSlot(Item.func_150898_a((Block)blockType));
            int oldslot = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            if (swap) {
                UInventory.heldItemChange(blockSlot, true, false, true);
            }
            if (placeFacing != null) {
                float[] fac = URotation.getFacingPlace(placeFacing);
                RebirthUtil.faceYawAndPitch(fac[0], fac[1]);
            }
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, rotate, packet, false);
            if (swapback) {
                UInventory.heldItemChange(oldslot, true, false, true);
            }
        }

        public static void doPlace2(BlockPos pos, EnumFacing fac, boolean rotate, boolean packet, Block block) {
            if (fac != null) {
                float[] facing = URotation.getFacingPlace(fac);
                RebirthUtil.faceYawAndPitch(facing[0], facing[1]);
            }
            int var3 = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            int swapTo = UInventory.itemSlot(Item.func_150898_a((Block)block));
            if (swapTo != -1) {
                RebirthUtil.doSwap(swapTo);
            }
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, false, packet);
            RebirthUtil.doSwap(var3);
            if (rotate) {
                RebirthUtil.facePlacePos(pos);
            }
        }

        public static void newPlace(BlockPos pos, EnumFacing fac, boolean rotate, boolean packet, Block block) {
            int swapTo;
            if (fac != null) {
                float[] facing = URotation.getFacingPlace(fac);
                RebirthUtil.faceYawAndPitch(facing[0], facing[1]);
            }
            int swapBack = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            if (block != null && (swapTo = UInventory.itemSlot(Item.func_150898_a((Block)block))) != -1) {
                RebirthUtil.doSwap(swapTo);
            }
            BlockUtil.placeSync(pos, EnumHand.MAIN_HAND, rotate, packet, true);
            if (block != null) {
                RebirthUtil.doSwap(swapBack);
            }
        }

        public static void doPlaceNoSwing(BlockPos pos, EnumFacing fac, boolean rotate, boolean packet, Block block) {
            if (fac != null) {
                float[] facing = URotation.getFacingPlace(fac);
                RebirthUtil.faceYawAndPitch(facing[0], facing[1]);
            }
            int var3 = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            int swapTo = UInventory.itemSlot(Item.func_150898_a((Block)block));
            if (swapTo != -1) {
                RebirthUtil.doSwap(swapTo);
            }
            BlockUtil.noSwingPlace(pos, EnumHand.MAIN_HAND, false, packet);
            RebirthUtil.doSwap(var3);
            if (rotate) {
                RebirthUtil.facePlacePos(pos);
            }
        }

        public static void placeUseSlot(BlockPos pos, EnumFacing fac, boolean rotate, boolean packet, int slot) {
            if (fac != null) {
                float[] facing = URotation.getFacingPlace(fac);
                RebirthUtil.faceYawAndPitch(facing[0], facing[1]);
            }
            int var3 = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            if (slot != -1) {
                RebirthUtil.doSwap(slot);
            }
            BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, false, packet);
            RebirthUtil.doSwap(var3);
            if (rotate) {
                RebirthUtil.facePlacePos(pos);
            }
        }

        public static void placeUseSlotNoSwing(BlockPos pos, EnumFacing fac, boolean rotate, boolean packet, int slot) {
            if (fac != null) {
                float[] facing = URotation.getFacingPlace(fac);
                RebirthUtil.faceYawAndPitch(facing[0], facing[1]);
            }
            int var3 = UtilsRewrite.mc.field_71439_g.field_71071_by.field_70461_c;
            if (slot != -1) {
                RebirthUtil.doSwap(slot);
            }
            BlockUtil.noSwingPlace(pos, EnumHand.MAIN_HAND, false, packet);
            RebirthUtil.doSwap(var3);
            if (rotate) {
                RebirthUtil.facePlacePos(pos);
            }
        }

        public static IBlockState getState(BlockPos pos) {
            return UtilsRewrite.mc.field_71441_e.func_180495_p(pos);
        }

        public static Block getBlock(BlockPos pos) {
            return UBlock.getState(pos).func_177230_c();
        }

        public static boolean isBlockAir(BlockPos pos) {
            IBlockState state = UBlock.getState(pos);
            return state instanceof BlockAir || state instanceof BlockLiquid;
        }

        public static boolean isBlockFull(BlockPos pos) {
            IBlockState state = UBlock.getState(pos);
            return state.func_185913_b();
        }

        public static boolean hasHelping(BlockPos pos) {
            return UBlock.findHelping(pos) != null;
        }

        public static BlockPos findHelping(BlockPos main) {
            BlockPos[] offsets2 = new PosHelper((EntityPlayer)UtilsRewrite.mc.field_71439_g).offsetList(main);
            ArrayList<BlockPos> canHelpingList = new ArrayList<BlockPos>();
            for (BlockPos _pos : offsets2) {
                if (RebirthUtil.canReplace(_pos)) continue;
                canHelpingList.add(_pos);
            }
            return UBlock.bestDistance(canHelpingList);
        }

        public static boolean canPlace(BlockPos pos) {
            boolean posNoEntity = UBlock.noEntity(pos);
            boolean posHasHelp = UBlock.hasHelping(pos);
            boolean posNoBlock = UBlock.isBlockAir(pos);
            return posNoEntity && posHasHelp && posNoBlock;
        }

        public static boolean customCanPlace(BlockPos pos, Block[] airBlocks) {
            boolean posNoEntity = UBlock.noEntity(pos);
            boolean posHasHelp = UBlock.hasHelping(pos);
            boolean posNoBlock = UBlock.posOnType(pos, airBlocks);
            return posNoEntity && posHasHelp && posNoBlock;
        }

        public static boolean fullCustomCanPlace(BlockPos pos, boolean pne, boolean phh, boolean pnb, Block[] airBlocks) {
            boolean posNoEntity = pne ? UBlock.noEntity(pos) : true;
            boolean posHasHelp = phh ? UBlock.hasHelping(pos) : true;
            boolean posNoBlock = pnb ? UBlock.posOnType(pos, airBlocks) : true;
            return posNoEntity && posHasHelp && posNoBlock;
        }

        public static boolean posOnType(BlockPos pos, Block[] types) {
            Block block = UBlock.getBlock(pos);
            ArrayList typelist = new ArrayList();
            Collections.addAll(typelist, types);
            return typelist.contains(block);
        }

        public static boolean posOnType(BlockPos pos, List<Block> types) {
            Block block = UBlock.getBlock(pos);
            return types.contains(block);
        }

        public static boolean noEntity(BlockPos pos) {
            List posEntities = UtilsRewrite.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos));
            for (Entity var2 : posEntities) {
                if (var2 instanceof EntityItem || var2 instanceof EntityXPOrb || var2 instanceof EntityExpBottle || var2 instanceof EntityArrow) continue;
                return false;
            }
            return true;
        }

        public static double getRange(BlockPos pos) {
            return UtilsRewrite.mc.field_71439_g.func_174791_d().func_72438_d(new Vec3d((Vec3i)pos));
        }

        public static void digBlock(digType type, BlockPos pos, EnumFacing facing) {
            UtilsRewrite.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(type.getType(), pos, facing));
        }

        public static void clickBlock(BlockPos pos) {
            EnumFacing legitFace = URotation.getBestFacing(pos);
            RebirthUtil.facePosFacing(pos, legitFace);
            UtilsRewrite.mc.field_71441_e.func_180495_p(pos).func_177230_c();
            UtilsRewrite.mc.field_71442_b.func_180512_c(pos, legitFace);
        }

        public static BlockPos bestDistance(BlockPos[] position) {
            BlockPos playerPos = UtilsRewrite.mc.field_71439_g.func_180425_c();
            double minDistance = Double.MAX_VALUE;
            BlockPos closestPos = null;
            ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
            for (BlockPos pos : position) {
                if (pos == null) continue;
                positions.add(pos);
            }
            for (BlockPos pos : positions) {
                double distance = playerPos.func_177951_i((Vec3i)pos);
                if (!(distance < minDistance)) continue;
                minDistance = distance;
                closestPos = pos;
            }
            return closestPos;
        }

        public static BlockPos bestDistance(List<BlockPos> position) {
            BlockPos playerPos = UtilsRewrite.mc.field_71439_g.func_180425_c();
            double minDistance = Double.MAX_VALUE;
            BlockPos closestPos = null;
            ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
            for (BlockPos pos : position) {
                if (pos == null) continue;
                positions.add(pos);
            }
            for (BlockPos pos : positions) {
                double distance = playerPos.func_177951_i((Vec3i)pos);
                if (!(distance < minDistance)) continue;
                minDistance = distance;
                closestPos = pos;
            }
            return closestPos;
        }

        public static enum digType {
            START(CPacketPlayerDigging.Action.START_DESTROY_BLOCK),
            STOP(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK),
            ABORT(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK);

            final CPacketPlayerDigging.Action action;

            private digType(CPacketPlayerDigging.Action _action) {
                this.action = _action;
            }

            public CPacketPlayerDigging.Action getType() {
                return this.action;
            }
        }
    }
}

