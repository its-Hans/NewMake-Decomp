/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.general;

public class PairUtil {

    public static class SafePair<L, R> {
        final L left;
        final R right;

        public SafePair(L left, R right) {
            this.left = left;
            this.right = right;
        }

        public L getLeft() {
            return this.left;
        }

        public R getRight() {
            return this.right;
        }

        public String toString() {
            return "Left: " + this.left + ", Right: " + this.right + " .";
        }
    }

    public static class Pair<L, R> {
        public L left;
        public R right;

        public Pair(L left, R right) {
            this.left = left;
            this.right = right;
        }

        public String toString() {
            return "Left: " + this.left + ", Right: " + this.right + " .";
        }
    }
}

