/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 */
package it.make.api.utils.second.m4ke.fun;

import it.make.modules.client.Targets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class GayCounter {
    private int tickCount = 0;
    private final HashMap<EntityPlayer, Integer> gayMap = new HashMap();
    private final HashMap<EntityPlayer, Boolean> sneakCounter = new HashMap();

    public void updateByTick() {
        if (this.tickCount >= 20) {
            this.tickCount = 0;
            this.gayMap.clear();
            this.sneakCounter.clear();
            return;
        }
        ++this.tickCount;
        for (EntityPlayer player : Targets.findPlayersByRange(Float.valueOf(2.2f), Minecraft.func_71410_x().field_71441_e)) {
            this.putSneakMap(player);
        }
    }

    public void putSneakMap(EntityPlayer player) {
        boolean isSneaking = player.func_70093_af();
        if (this.sneakCounter.containsKey(player)) {
            if (this.sneakCounter.get(player) != isSneaking) {
                int currentSneakCount = this.gayMap.getOrDefault(player, 0);
                this.gayMap.put(player, currentSneakCount + 1);
            }
        } else {
            this.sneakCounter.put(player, isSneaking);
        }
    }

    public List<EntityPlayer> getGays(int minSneakCount) {
        ArrayList<EntityPlayer> result = new ArrayList<EntityPlayer>();
        for (Map.Entry<EntityPlayer, Integer> entry : this.gayMap.entrySet()) {
            EntityPlayer player = entry.getKey();
            int sneakCount = entry.getValue();
            if (sneakCount < minSneakCount) continue;
            result.add(player);
        }
        return result.isEmpty() ? null : result;
    }
}

