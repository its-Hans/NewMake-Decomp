/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.io;

public enum HAND {
    LEFT,
    RIGHT,
    NONE;

}

