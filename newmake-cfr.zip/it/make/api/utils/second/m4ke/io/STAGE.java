/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.m4ke.io;

public enum STAGE {
    PRE,
    POST,
    NONE;

}

