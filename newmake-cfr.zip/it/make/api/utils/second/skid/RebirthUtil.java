/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.network.NetHandlerPlayClient
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.item.EntityBoat
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.item.EntityExpBottle
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.init.MobEffects
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemFood
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.CombatRules
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.MovementInput
 *  net.minecraft.util.NonNullList
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.World
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package it.make.api.utils.second.skid;

import it.make.Client;
import it.make.api.Wrapper;
import it.make.api.events.player.MoveEvent;
import it.make.api.utils.BlockUtil;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.EntityUtil;
import it.make.api.utils.InventoryUtil;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.MathUtil;
import it.make.api.utils.second.skid.RotationUtil;
import it.make.features.commands.Command;
import it.make.modules.render.PlaceRender;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.MovementInput;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class RebirthUtil
implements Wrapper {
    static final Timer breakTimer = new Timer();
    public static final List<Block> canUseList = Arrays.asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT, Blocks.field_150381_bn);
    public static final List<Block> shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);

    public static int getItemHotbar(Item input) {
        for (int i = 0; i < 9; ++i) {
            Item item = RebirthUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (Item.func_150891_b((Item)item) != Item.func_150891_b((Item)input)) continue;
            return i;
        }
        return -1;
    }

    public static boolean isEating() {
        return RebirthUtil.mc.field_71439_g.func_184587_cr() && RebirthUtil.mc.field_71439_g.func_184607_cu().func_77973_b() instanceof ItemFood || RebirthUtil.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemFood && Mouse.isButtonDown((int)1);
    }

    public static EntityPlayer getTarget(double var0) {
        EntityPlayer var2 = null;
        double var3 = var0;
        for (EntityPlayer var6 : RebirthUtil.mc.field_71441_e.field_73010_i) {
            boolean bl;
            if (RebirthUtil.invalid((Entity)var6, var0)) {
                bl = false;
                continue;
            }
            if (var2 == null) {
                var2 = var6;
                var3 = RebirthUtil.mc.field_71439_g.func_70068_e((Entity)var6);
                bl = false;
                continue;
            }
            if (RebirthUtil.mc.field_71439_g.func_70068_e((Entity)var6) >= var3) {
                bl = false;
                continue;
            }
            var2 = var6;
            var3 = RebirthUtil.mc.field_71439_g.func_70068_e((Entity)var6);
            bl = false;
        }
        return var2;
    }

    public static boolean invalid(Entity var0, double var1) {
        boolean var10000;
        if (!(var0 == null || RebirthUtil.isDead(var0) || var0.equals((Object)RebirthUtil.mc.field_71439_g) || var0 instanceof EntityPlayer && Client.friendManager.isFriend(var0.func_70005_c_()) || RebirthUtil.mc.field_71439_g.func_70068_e(var0) > MathUtil.square(var1))) {
            var10000 = false;
        } else {
            var10000 = true;
            boolean bl = false;
        }
        return var10000;
    }

    public static boolean isDead(Entity var0) {
        boolean var10000;
        if (!RebirthUtil.isAlive(var0)) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static boolean isAlive(Entity var0) {
        boolean var10000;
        if (RebirthUtil.isLiving(var0) && !var0.field_70128_L && ((EntityLivingBase)var0).func_110143_aJ() > 0.0f) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static boolean isLiving(Entity var0) {
        return var0 instanceof EntityLivingBase;
    }

    public static BlockPos getEntityPos(Entity var0) {
        return new BlockPos(var0.field_70165_t, var0.field_70163_u + 0.5, var0.field_70161_v);
    }

    public static void attackCrystal(BlockPos var0, boolean rotate, boolean noESTOP) {
        if (!(!breakTimer.passedMs(300L) || noESTOP && RebirthUtil.isEating())) {
            for (Entity var4 : RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var0))) {
                if (!(var4 instanceof EntityEnderCrystal)) continue;
                breakTimer.reset();
                RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(var4));
                RebirthUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                if (!rotate) break;
                RebirthUtil.faceXYZ(var4.field_70165_t, var4.field_70163_u + 0.25, var4.field_70161_v);
                break;
            }
        }
    }

    public static void attackCrystal(Entity var0, boolean var1, boolean var2) {
        if (breakTimer.passedMs(300L) && (!var2 || RebirthUtil.isEating()) && var0 != null) {
            breakTimer.reset();
            boolean var10000 = false;
            RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(var0));
            RebirthUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            if (var1) {
                RebirthUtil.faceXYZ(var0.field_70165_t, var0.field_70163_u + 0.25, var0.field_70161_v);
            }
        }
    }

    public static void faceXYZ(double var0, double var2, double var4) {
        RebirthUtil.faceYawAndPitch(RebirthUtil.getXYZYaw(var0, var2, var4), RebirthUtil.getXYZPitch(var0, var2, var4));
    }

    public static void faceYawAndPitch(float var0, float var1) {
        RebirthUtil.sendPlayerRot(var0, var1, RebirthUtil.mc.field_71439_g.field_70122_E);
    }

    public static void sendPlayerRot(float var0, float var1, boolean var2) {
        RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(var0, var1, var2));
    }

    public static float getXYZYaw(double var0, double var2, double var4) {
        float[] var6 = MathUtil.calcAngle(RebirthUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d(var0, var2, var4));
        return var6[0];
    }

    public static float getXYZPitch(double var0, double var2, double var4) {
        float[] var6 = MathUtil.calcAngle(RebirthUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d(var0, var2, var4));
        return var6[1];
    }

    public static float calculateDamage(Entity var0, Entity var1) {
        return RebirthUtil.calculateDamage(var0.field_70165_t, var0.field_70163_u, var0.field_70161_v, var1);
    }

    public static float calculateDamage(double var0, double var2, double var4, Entity var6) {
        double var11;
        double var8;
        float var7;
        block3: {
            var7 = 12.0f;
            var8 = var6.func_70011_f(var0, var2, var4) / (double)var7;
            Vec3d var10 = new Vec3d(var0, var2, var4);
            var11 = 0.0;
            Entity var10000 = var6;
            try {
                var11 = var10000.field_70170_p.func_72842_a(var10, var6.func_174813_aQ());
            }
            catch (Exception var18) {
                break block3;
            }
            boolean var18 = false;
        }
        double var13 = (1.0 - var8) * var11;
        float var15 = (int)((var13 * var13 + var13) / 2.0 * 7.0 * (double)var7 + 1.0);
        double var16 = 1.0;
        if (var6 instanceof EntityLivingBase) {
            var16 = RebirthUtil.getBlastReduction((EntityLivingBase)var6, RebirthUtil.getDamageMultiplied(var15), new Explosion((World)RebirthUtil.mc.field_71441_e, null, var0, var2, var4, 6.0f, false, true));
        }
        return (float)var16;
    }

    public static float getDamageMultiplied(float var0) {
        float var10001;
        int var1 = RebirthUtil.mc.field_71441_e.func_175659_aa().func_151525_a();
        if (var1 == 0) {
            var10001 = 0.0f;
            boolean bl = false;
        } else if (var1 == 2) {
            var10001 = 1.0f;
            boolean bl = false;
        } else if (var1 == 1) {
            var10001 = 0.5f;
            boolean bl = false;
        } else {
            var10001 = 1.5f;
        }
        return var0 * var10001;
    }

    public static float getBlastReduction(EntityLivingBase var0, float var1, Explosion var2) {
        if (var0 instanceof EntityPlayer) {
            int var6;
            float var3;
            block4: {
                EntityPlayer var4 = (EntityPlayer)var0;
                DamageSource var5 = DamageSource.func_94539_a((Explosion)var2);
                var3 = CombatRules.func_189427_a((float)var1, (float)var4.func_70658_aO(), (float)((float)var4.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
                var6 = 0;
                EntityPlayer var10000 = var4;
                try {
                    var6 = EnchantmentHelper.func_77508_a((Iterable)var10000.func_184193_aE(), (DamageSource)var5);
                }
                catch (Exception var8) {
                    break block4;
                }
                boolean var8 = false;
            }
            float var7 = MathHelper.func_76131_a((float)var6, (float)0.0f, (float)20.0f);
            var3 *= 1.0f - var7 / 25.0f;
            if (var0.func_70644_a(MobEffects.field_76429_m)) {
                var3 -= var3 / 4.0f;
            }
            return Math.max(var3, 0.0f);
        }
        return CombatRules.func_189427_a((float)var1, (float)var0.func_70658_aO(), (float)((float)var0.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
    }

    public static boolean isMoving() {
        return (double)RebirthUtil.mc.field_71439_g.field_191988_bg != 0.0 || (double)RebirthUtil.mc.field_71439_g.field_70702_br != 0.0;
    }

    public static int findHotbarBlock(Block var0) {
        for (int var1 = 0; var1 < 9; ++var1) {
            boolean bl;
            ItemStack var2 = RebirthUtil.mc.field_71439_g.field_71071_by.func_70301_a(var1);
            if (var2 != ItemStack.field_190927_a && var2.func_77973_b() instanceof ItemBlock) {
                if (((ItemBlock)var2.func_77973_b()).func_179223_d() == var0) {
                    return var1;
                }
                bl = false;
            }
            bl = false;
        }
        return -1;
    }

    public static int findHotbarBlock(Class clazz) {
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = RebirthUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack == ItemStack.field_190927_a) continue;
            if (clazz.isInstance(stack.func_77973_b())) {
                return i;
            }
            if (!(stack.func_77973_b() instanceof ItemBlock) || !clazz.isInstance(((ItemBlock)stack.func_77973_b()).func_179223_d())) continue;
            return i;
        }
        return -1;
    }

    public static int findHotbarClass(Class var0) {
        for (int var1 = 0; var1 < 9; ++var1) {
            boolean bl;
            ItemStack var2 = RebirthUtil.mc.field_71439_g.field_71071_by.func_70301_a(var1);
            if (var2 == ItemStack.field_190927_a) {
                bl = false;
            } else {
                if (var0.isInstance(var2.func_77973_b())) {
                    return var1;
                }
                if (var2.func_77973_b() instanceof ItemBlock) {
                    if (var0.isInstance(((ItemBlock)var2.func_77973_b()).func_179223_d())) {
                        return var1;
                    }
                    bl = false;
                }
            }
            bl = false;
        }
        return -1;
    }

    public static int findItemInHotbar(Item var0) {
        int var1 = -1;
        for (int var2 = 0; var2 < 9; ++var2) {
            boolean bl;
            ItemStack var3 = RebirthUtil.mc.field_71439_g.field_71071_by.func_70301_a(var2);
            if (var3 == ItemStack.field_190927_a) {
                bl = false;
            } else {
                var3.func_77973_b();
                boolean var5 = false;
                Item var4 = var3.func_77973_b();
                if (var4.equals(var0)) {
                    var1 = var2;
                    var5 = false;
                    break;
                }
            }
            bl = false;
        }
        return var1;
    }

    public static boolean canPlaceCrystal(BlockPos var0) {
        BlockPos var1 = var0.func_177977_b();
        BlockPos var2 = var1.func_177984_a();
        BlockPos var3 = var1.func_177981_b(2);
        return (RebirthUtil.getBlock(var1) == Blocks.field_150357_h || RebirthUtil.getBlock(var1) == Blocks.field_150343_Z) && RebirthUtil.getBlock(var2) == Blocks.field_150350_a && RebirthUtil.getBlock(var3) == Blocks.field_150350_a && RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var2)).isEmpty() && RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var3)).isEmpty();
    }

    public static Block getBlock(BlockPos var0) {
        return RebirthUtil.getState(var0).func_177230_c();
    }

    public static IBlockState getState(BlockPos var0) {
        return RebirthUtil.mc.field_71441_e.func_180495_p(var0);
    }

    public static boolean posHasCrystal(BlockPos var0) {
        for (Entity var2 : RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var0))) {
            if (var2 instanceof EntityEnderCrystal && new BlockPos(var2.field_70165_t, var2.field_70163_u, var2.field_70161_v).equals((Object)var0)) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    public static void doSwap(int var0) {
        RebirthUtil.mc.field_71439_g.field_71071_by.field_70461_c = var0;
        RebirthUtil.mc.field_71442_b.func_78765_e();
    }

    public static EnumFacing getFirstFacing(BlockPos var0) {
        Iterator<EnumFacing> var1 = RebirthUtil.getPossibleSides(var0).iterator();
        if (var1.hasNext()) {
            return var1.next();
        }
        boolean var10000 = false;
        return null;
    }

    public static List<EnumFacing> getPossibleSides(BlockPos var0) {
        ArrayList<EnumFacing> var1 = new ArrayList<EnumFacing>();
        for (EnumFacing var5 : EnumFacing.values()) {
            boolean bl;
            BlockPos var6 = var0.func_177972_a(var5);
            if (RebirthUtil.getBlock(var6).func_176209_a(RebirthUtil.getState(var6), false)) {
                if (!RebirthUtil.canReplace(var6)) {
                    var1.add(var5);
                }
                bl = false;
            }
            bl = false;
        }
        return var1;
    }

    public static boolean canReplace(BlockPos pos) {
        return RebirthUtil.getState(pos).func_185904_a().func_76222_j();
    }

    public static float[] getLegitRotations(Vec3d var0) {
        Vec3d var1 = RotationUtil.getEyesPos();
        double var2 = var0.field_72450_a - var1.field_72450_a;
        double var4 = var0.field_72448_b - var1.field_72448_b;
        double var6 = var0.field_72449_c - var1.field_72449_c;
        double var8 = Math.sqrt(var2 * var2 + var6 * var6);
        float var10 = (float)Math.toDegrees(Math.atan2(var6, var2)) - 90.0f;
        float var11 = (float)(-Math.toDegrees(Math.atan2(var4, var8)));
        return new float[]{RebirthUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(var10 - RebirthUtil.mc.field_71439_g.field_70177_z)), RebirthUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(var11 - RebirthUtil.mc.field_71439_g.field_70125_A))};
    }

    public static void placeCrystal(BlockPos pos, boolean rotate) {
        boolean offhand = RebirthUtil.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
        BlockPos obsPos = pos.func_177977_b();
        RayTraceResult result = RebirthUtil.mc.field_71441_e.func_72933_a(new Vec3d(RebirthUtil.mc.field_71439_g.field_70165_t, RebirthUtil.mc.field_71439_g.field_70163_u + (double)RebirthUtil.mc.field_71439_g.func_70047_e(), RebirthUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() - 0.5, (double)pos.func_177952_p() + 0.5));
        EnumFacing facing = result != null && result.field_178784_b != null ? result.field_178784_b : EnumFacing.UP;
        Vec3d vec = new Vec3d((Vec3i)obsPos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(facing.func_176730_m()).func_186678_a(0.5));
        if (rotate) {
            RebirthUtil.faceVector(vec);
        }
        RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(obsPos, facing, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
        RebirthUtil.mc.field_71439_g.func_184609_a(offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
    }

    public static void placeCrystal(BlockPos var0, boolean var1, boolean debug) {
        EnumHand var13;
        EnumHand var10005;
        EnumFacing var8;
        boolean var10000;
        if (debug) {
            Command.sendMessage("crystal pos maybe " + var0);
        }
        if (RebirthUtil.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        boolean var2 = var10000;
        BlockPos var3 = var0.func_177977_b();
        RayTraceResult var4 = RebirthUtil.mc.field_71441_e.func_72933_a(new Vec3d(RebirthUtil.mc.field_71439_g.field_70165_t, RebirthUtil.mc.field_71439_g.field_70163_u + (double)RebirthUtil.mc.field_71439_g.func_70047_e(), RebirthUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)var0.func_177958_n() + 0.5, (double)var0.func_177956_o() - 0.5, (double)var0.func_177952_p() + 0.5));
        if (var4 != null && var4.field_178784_b != null) {
            var8 = var4.field_178784_b;
        } else {
            var8 = EnumFacing.UP;
            boolean bl = false;
        }
        EnumFacing var5 = var8;
        EnumFacing var6 = var5.func_176734_d();
        Vec3d var7 = new Vec3d((Vec3i)var3).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(var6.func_176730_m()));
        if (var1) {
            RotationUtil.faceVector(var7, true);
        }
        NetHandlerPlayClient var9 = RebirthUtil.mc.field_71439_g.field_71174_a;
        CPacketPlayerTryUseItemOnBlock var12 = new CPacketPlayerTryUseItemOnBlock();
        if (var2) {
            var10005 = EnumHand.OFF_HAND;
            boolean bl = false;
        } else {
            var10005 = EnumHand.MAIN_HAND;
        }
        Command.sendMessage("crystalbase: " + var3 + "facing: " + var5);
        var12 = new CPacketPlayerTryUseItemOnBlock(var3, var5, var10005, 0.0f, 0.0f, 0.0f);
        var9.func_147297_a((Packet)var12);
        EntityPlayerSP var10 = RebirthUtil.mc.field_71439_g;
        if (var2) {
            var13 = EnumHand.OFF_HAND;
            boolean bl = false;
        } else {
            var13 = EnumHand.MAIN_HAND;
        }
        var10.func_184609_a(var13);
    }

    public static void placeCrystalFix(BlockPos basePos, boolean var1, boolean debug) {
        RebirthUtil.placeCrystal(basePos.func_177984_a(), var1, debug);
    }

    public static void mineBlock(BlockPos var0) {
        RebirthUtil.getBlock(var0);
        RebirthUtil.mc.field_71442_b.func_180512_c(var0, BlockUtil.getRayTraceFacing(var0));
        boolean var10000 = false;
    }

    public static boolean canPlace(BlockPos var0) {
        boolean var10000;
        if (RebirthUtil.mc.field_71439_g.func_70011_f((double)var0.func_177958_n() + 0.5, (double)var0.func_177956_o() + 0.5, (double)var0.func_177952_p() + 0.5) > 6.0) {
            return false;
        }
        if (!RebirthUtil.canBlockFacing(var0)) {
            return false;
        }
        if (!RebirthUtil.canReplace(var0)) {
            return false;
        }
        if (!RebirthUtil.strictPlaceCheck(var0)) {
            return false;
        }
        if (!RebirthUtil.checkEntity(var0)) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static boolean canBlockFacing(BlockPos var0) {
        boolean var1 = false;
        for (EnumFacing var5 : EnumFacing.values()) {
            if (RebirthUtil.canClick(var0.func_177972_a(var5))) {
                var1 = true;
            }
            boolean bl = false;
        }
        return var1;
    }

    public static boolean canClick(BlockPos var0) {
        return RebirthUtil.mc.field_71441_e.func_180495_p(var0).func_177230_c().func_176209_a(RebirthUtil.mc.field_71441_e.func_180495_p(var0), false);
    }

    public static boolean strictPlaceCheck(BlockPos var0) {
        for (EnumFacing var2 : RebirthUtil.getPlacableFacings(var0, true, false)) {
            if (RebirthUtil.canClick(var0.func_177972_a(var2))) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    public static List<EnumFacing> getPlacableFacings(BlockPos var0, boolean var1, boolean var2) {
        boolean bl;
        ArrayList<EnumFacing> var3 = new ArrayList<EnumFacing>();
        for (EnumFacing var7 : EnumFacing.values()) {
            if (RebirthUtil.getRaytrace(var0, var7)) {
                bl = false;
            } else {
                RebirthUtil.getPlaceFacing(var0, var1, var3, var7);
            }
            bl = false;
        }
        for (EnumFacing var11 : EnumFacing.values()) {
            if (var2 && RebirthUtil.getRaytrace(var0, var11)) {
                bl = false;
            } else {
                RebirthUtil.getPlaceFacing(var0, var1, var3, var11);
            }
            bl = false;
        }
        return var3;
    }

    private static void getPlaceFacing(BlockPos var0, boolean var1, ArrayList<EnumFacing> var2, EnumFacing var3) {
        IBlockState var10;
        BlockPos var4 = var0.func_177972_a(var3);
        if (var1) {
            boolean bl;
            boolean var10004;
            boolean var10000;
            Vec3d var5 = RebirthUtil.mc.field_71439_g.func_174824_e(1.0f);
            Vec3d var6 = new Vec3d((double)var4.func_177958_n() + 0.5, (double)var4.func_177956_o() + 0.5, (double)var4.func_177952_p() + 0.5);
            IBlockState var7 = RebirthUtil.mc.field_71441_e.func_180495_p(var4);
            if (var7.func_177230_c() != Blocks.field_150350_a && !var7.func_185913_b()) {
                var10000 = false;
            } else {
                var10000 = true;
                boolean bl2 = false;
            }
            boolean var8 = var10000;
            ArrayList<EnumFacing> var9 = new ArrayList<EnumFacing>();
            double var15 = var5.field_72450_a - var6.field_72450_a;
            EnumFacing var10002 = EnumFacing.WEST;
            EnumFacing var10003 = EnumFacing.EAST;
            if (!var8) {
                var10004 = true;
                bl = false;
            } else {
                var10004 = false;
            }
            var9.addAll(RebirthUtil.checkAxis(var15, var10002, var10003, var10004));
            var10000 = false;
            var9.addAll(RebirthUtil.checkAxis(var5.field_72448_b - var6.field_72448_b, EnumFacing.DOWN, EnumFacing.UP, true));
            var10000 = false;
            var15 = var5.field_72449_c - var6.field_72449_c;
            var10002 = EnumFacing.NORTH;
            var10003 = EnumFacing.SOUTH;
            if (!var8) {
                var10004 = true;
                bl = false;
            } else {
                var10004 = false;
            }
            var9.addAll(RebirthUtil.checkAxis(var15, var10002, var10003, var10004));
            var10000 = false;
            if (!var9.contains(var3.func_176734_d())) {
                return;
            }
        }
        if ((var10 = RebirthUtil.mc.field_71441_e.func_180495_p(var4)).func_177230_c().func_176209_a(var10, false) && !var10.func_185904_a().func_76222_j()) {
            var2.add(var3);
            boolean bl = false;
        }
    }

    public static ArrayList<EnumFacing> checkAxis(double var0, EnumFacing var2, EnumFacing var3, boolean var4) {
        boolean bl;
        ArrayList<EnumFacing> var5 = new ArrayList<EnumFacing>();
        if (var0 < -0.5) {
            var5.add(var2);
            bl = false;
        }
        if (var0 > 0.5) {
            var5.add(var3);
            bl = false;
        }
        if (var4) {
            if (!var5.contains(var2)) {
                var5.add(var2);
                bl = false;
            }
            if (!var5.contains(var3)) {
                var5.add(var3);
                bl = false;
            }
        }
        return var5;
    }

    public static boolean checkEntity(BlockPos var0) {
        for (Entity var2 : RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var0))) {
            if (var2.field_70128_L || var2 instanceof EntityItem || var2 instanceof EntityXPOrb || var2 instanceof EntityExpBottle) continue;
            if (!(var2 instanceof EntityArrow)) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private static boolean getRaytrace(BlockPos var0, EnumFacing var1) {
        boolean var10000;
        Vec3d var2 = new Vec3d((Vec3i)var0).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(var1.func_176730_m()).func_186678_a(0.5));
        RayTraceResult var3 = RebirthUtil.mc.field_71441_e.func_72933_a(RebirthUtil.mc.field_71439_g.func_174824_e(1.0f), var2);
        if (var3 != null && var3.field_72313_a != RayTraceResult.Type.MISS) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static double distanceToXZ(double var0, double var2) {
        double var4 = RebirthUtil.mc.field_71439_g.field_70165_t - var0;
        double var6 = RebirthUtil.mc.field_71439_g.field_70161_v - var2;
        return Math.sqrt(var4 * var4 + var6 * var6);
    }

    public static void facePlacePos(BlockPos var0) {
        EnumFacing var1 = BlockUtil.getFirstFacing(var0);
        if (var1 != null) {
            BlockPos var2 = var0.func_177972_a(var1);
            EnumFacing var3 = var1.func_176734_d();
            Vec3d var4 = new Vec3d((Vec3i)var2).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(var3.func_176730_m()).func_186678_a(0.5));
            RotationUtil.faceVector(var4, true);
        }
    }

    public static boolean canPlace2(BlockPos var0) {
        boolean var10000;
        if (RebirthUtil.mc.field_71439_g.func_70011_f((double)var0.func_177958_n() + 0.5, (double)var0.func_177956_o() + 0.5, (double)var0.func_177952_p() + 0.5) > 6.0) {
            return false;
        }
        if (!RebirthUtil.canReplace(var0)) {
            return false;
        }
        if (!RebirthUtil.checkPlayer(var0)) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static boolean canPlace2(BlockPos pos, double distance) {
        if (RebirthUtil.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5) > distance) {
            return false;
        }
        if (!BlockUtil.canReplace(pos)) {
            return false;
        }
        return !RebirthUtil.checkPlayer(pos);
    }

    public static boolean checkPlayer(BlockPos var0) {
        for (Entity var2 : RebirthUtil.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var0))) {
            if (var2.field_70128_L || var2 instanceof EntityItem || var2 instanceof EntityXPOrb || var2 instanceof EntityExpBottle || var2 instanceof EntityArrow) continue;
            if (!(var2 instanceof EntityEnderCrystal)) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    public static boolean canPlace(BlockPos var0, double var1) {
        boolean var10000;
        if (RebirthUtil.mc.field_71439_g.func_70011_f((double)var0.func_177958_n() + 0.5, (double)var0.func_177956_o() + 0.5, (double)var0.func_177952_p() + 0.5) > var1) {
            return false;
        }
        if (!RebirthUtil.canBlockFacing(var0)) {
            return false;
        }
        if (!RebirthUtil.canReplace(var0)) {
            return false;
        }
        if (!RebirthUtil.strictPlaceCheck(var0)) {
            return false;
        }
        if (!RebirthUtil.checkEntity(var0)) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public static EnumFacing getBestNeighboring(BlockPos var0, EnumFacing var1) {
        for (EnumFacing var5 : EnumFacing.field_82609_l) {
            int n;
            if (var1 == null || !var0.func_177972_a(var5).equals((Object)var0.func_177967_a(var1, -1))) {
                if (var5 == EnumFacing.DOWN) {
                    n = 0;
                } else {
                    for (EnumFacing var7 : RebirthUtil.getPlacableFacings(var0.func_177972_a(var5), true, true)) {
                        if (RebirthUtil.canClick(var0.func_177972_a(var5).func_177972_a(var7))) {
                            return var5;
                        }
                        boolean bl = false;
                    }
                }
            }
            n = 0;
        }
        EnumFacing var11 = null;
        double var12 = 0.0;
        for (EnumFacing var8 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var1 == null || !var0.func_177972_a(var8).equals((Object)var0.func_177967_a(var1, -1))) {
                if (var8 == EnumFacing.DOWN) {
                    bl = false;
                } else {
                    for (EnumFacing var10 : RebirthUtil.getPlacableFacings(var0.func_177972_a(var8), true, false)) {
                        boolean bl2;
                        if (!RebirthUtil.canClick(var0.func_177972_a(var8).func_177972_a(var10))) {
                            bl2 = false;
                            continue;
                        }
                        if (var11 == null || RebirthUtil.mc.field_71439_g.func_174818_b(var0.func_177972_a(var8)) < var12) {
                            var11 = var8;
                            var12 = RebirthUtil.mc.field_71439_g.func_174818_b(var0.func_177972_a(var8));
                        }
                        bl2 = false;
                    }
                }
            }
            bl = false;
        }
        return null;
    }

    public static Vec3d[] getVarOffsets(int var0, int var1, int var2) {
        List<Vec3d> var3 = RebirthUtil.getVarOffsetList(var0, var1, var2);
        Vec3d[] var4 = var3.toArray(new Vec3d[0]);
        return var4;
    }

    public static List<Vec3d> getVarOffsetList(int var0, int var1, int var2) {
        ArrayList<Vec3d> var3 = new ArrayList<Vec3d>();
        var3.add(new Vec3d((double)var0, (double)var1, (double)var2));
        boolean var10000 = false;
        return var3;
    }

    public static BlockPos getPlayerPos() {
        return RebirthUtil.getEntityPos((Entity)RebirthUtil.mc.field_71439_g);
    }

    public static boolean canPlaceEnum(BlockPos var0) {
        return RebirthUtil.canBlockFacing(var0) && RebirthUtil.strictPlaceCheck(var0);
    }

    public static void facePosFacing(BlockPos var0, EnumFacing var1) {
        Vec3d var2 = new Vec3d((Vec3i)var0).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(var1.func_176730_m()).func_186678_a(0.5));
        RotationUtil.faceVector(var2, true);
    }

    public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        HashMap<Integer, ItemStack> var0 = new HashMap<Integer, ItemStack>();
        for (int var1 = 9; var1 <= 44; ++var1) {
            var0.put(var1, (ItemStack)RebirthUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(var1));
            boolean var10000 = false;
            boolean bl = false;
        }
        return var0;
    }

    public static void placeBlock(BlockPos var0, EnumHand var1, boolean var2, boolean var3) {
        EnumFacing var4 = RebirthUtil.getFirstFacing(var0);
        if (var4 != null) {
            BlockPos var5 = var0.func_177972_a(var4);
            EnumFacing var6 = var4.func_176734_d();
            Vec3d var7 = new Vec3d((Vec3i)var5).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(var6.func_176730_m()).func_186678_a(0.5));
            Block var8 = RebirthUtil.mc.field_71441_e.func_180495_p(var5).func_177230_c();
            boolean var9 = false;
            if (!RebirthUtil.mc.field_71439_g.func_70093_af() && (canUseList.contains(var8) || shulkerList.contains(var8))) {
                RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)RebirthUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                var9 = true;
            }
            if (var2) {
                RebirthUtil.faceVector(var7);
            }
            boolean var10000 = false;
            RebirthUtil.rightClickBlock(var5, var7, var1, var6, var3);
            PlaceRender.putMap(var0);
            if (var9) {
                RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)RebirthUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            }
        }
    }

    public static void rightClickBlock(BlockPos var0, Vec3d var1, EnumHand var2, EnumFacing var3, boolean var4) {
        if (var4) {
            float var5 = (float)(var1.field_72450_a - (double)var0.func_177958_n());
            float var6 = (float)(var1.field_72448_b - (double)var0.func_177956_o());
            float var7 = (float)(var1.field_72449_c - (double)var0.func_177952_p());
            RebirthUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(var0, var3, var2, var5, var6, var7));
        } else {
            RebirthUtil.mc.field_71442_b.func_187099_a(RebirthUtil.mc.field_71439_g, RebirthUtil.mc.field_71441_e, var0, var3, var1, var2);
        }
        boolean var10000 = false;
        RebirthUtil.mc.field_71439_g.func_184609_a(var2);
        RebirthUtil.mc.field_71467_ac = 4;
    }

    public static void faceVector(Vec3d var0) {
        float[] var1 = RebirthUtil.getLegitRotations(var0);
        boolean var10000 = false;
        RebirthUtil.sendPlayerRot(var1[0], var1[1], RebirthUtil.mc.field_71439_g.field_70122_E);
    }

    public static int findItemInventorySlot(Item item, boolean offHand, boolean withXCarry) {
        int slot = InventoryUtil.findItemInventorySlot(item, offHand);
        if (slot == -1 && withXCarry) {
            for (int i = 1; i < 5; ++i) {
                Slot craftingSlot = (Slot)RebirthUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack craftingStack = craftingSlot.func_75211_c();
                if (craftingStack.func_77973_b() == Items.field_190931_a || craftingStack.func_77973_b() != item) continue;
                slot = i;
            }
        }
        return slot;
    }

    public static float getHealth(Entity entity) {
        if (EntityUtil.isLiving(entity)) {
            EntityLivingBase livingBase = (EntityLivingBase)entity;
            return livingBase.func_110143_aJ() + livingBase.func_110139_bj();
        }
        return 0.0f;
    }

    public static NonNullList<BlockPos> getBox(float range) {
        NonNullList positions = NonNullList.func_191196_a();
        positions.addAll(BlockUtil.getSphere(new BlockPos(Math.floor(RebirthUtil.mc.field_71439_g.field_70165_t), Math.floor(RebirthUtil.mc.field_71439_g.field_70163_u), Math.floor(RebirthUtil.mc.field_71439_g.field_70161_v)), range, 0, false, true, 0));
        return positions;
    }

    public static void placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, boolean attackEntity, boolean eatingPause) {
        if (attackEntity) {
            RebirthUtil.attackCrystal(pos, rotate, eatingPause);
        }
        RebirthUtil.placeBlock(pos, hand, rotate, packet);
    }

    public static boolean isInMovementDirection(double x, double y, double z) {
        if (RebirthUtil.mc.field_71439_g.field_70159_w != 0.0 || RebirthUtil.mc.field_71439_g.field_70179_y != 0.0) {
            BlockPos movingPos = new BlockPos((Entity)RebirthUtil.mc.field_71439_g).func_177963_a(RebirthUtil.mc.field_71439_g.field_70159_w * 10000.0, 0.0, RebirthUtil.mc.field_71439_g.field_70179_y * 10000.0);
            BlockPos antiPos = new BlockPos((Entity)RebirthUtil.mc.field_71439_g).func_177963_a(RebirthUtil.mc.field_71439_g.field_70159_w * -10000.0, 0.0, RebirthUtil.mc.field_71439_g.field_70181_x * -10000.0);
            return movingPos.func_177954_c(x, y, z) < antiPos.func_177954_c(x, y, z);
        }
        return true;
    }

    public static double getDistance2D() {
        double xDist = RebirthUtil.mc.field_71439_g.field_70165_t - RebirthUtil.mc.field_71439_g.field_70169_q;
        double zDist = RebirthUtil.mc.field_71439_g.field_70161_v - RebirthUtil.mc.field_71439_g.field_70166_s;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static double getSpeed() {
        return RebirthUtil.getSpeed(false);
    }

    public static double getSpeed(boolean slowness) {
        int amplifier;
        double defaultSpeed = 0.2873;
        if (RebirthUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = Objects.requireNonNull(RebirthUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            defaultSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (slowness && RebirthUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = Objects.requireNonNull(RebirthUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d)).func_76458_c();
            defaultSpeed /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (RebirthUtil.mc.field_71439_g.func_70093_af()) {
            defaultSpeed /= 5.0;
        }
        return defaultSpeed;
    }

    public static boolean inLiquid() {
        return RebirthUtil.inLiquid(MathHelper.func_76128_c((double)(RebirthUtil.requirePositionEntity().func_174813_aQ().field_72338_b + 0.01)));
    }

    public static boolean inLiquid(boolean feet) {
        return RebirthUtil.inLiquid(MathHelper.func_76128_c((double)(RebirthUtil.requirePositionEntity().func_174813_aQ().field_72338_b - (feet ? 0.03 : 0.2))));
    }

    private static boolean inLiquid(int y) {
        return RebirthUtil.findState(BlockLiquid.class, y) != null;
    }

    public static Entity getPositionEntity() {
        Entity ridingEntity;
        EntityPlayerSP player = RebirthUtil.mc.field_71439_g;
        return player == null ? null : ((ridingEntity = player.func_184187_bx()) != null && !(ridingEntity instanceof EntityBoat) ? ridingEntity : player);
    }

    public static Entity requirePositionEntity() {
        return Objects.requireNonNull(RebirthUtil.getPositionEntity());
    }

    private static IBlockState findState(Class<? extends Block> block, int y) {
        Entity entity = RebirthUtil.requirePositionEntity();
        int startX = MathHelper.func_76128_c((double)entity.func_174813_aQ().field_72340_a);
        int startZ = MathHelper.func_76128_c((double)entity.func_174813_aQ().field_72339_c);
        int endX = MathHelper.func_76143_f((double)entity.func_174813_aQ().field_72336_d);
        int endZ = MathHelper.func_76143_f((double)entity.func_174813_aQ().field_72334_f);
        for (int x = startX; x < endX; ++x) {
            for (int z = startZ; z < endZ; ++z) {
                IBlockState s = RebirthUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z));
                if (!block.isInstance(s.func_177230_c())) continue;
                return s;
            }
        }
        return null;
    }

    public static double getSpeed(boolean slowness, double defaultSpeed) {
        int amplifier;
        if (RebirthUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = Objects.requireNonNull(RebirthUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            defaultSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (slowness && RebirthUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = Objects.requireNonNull(RebirthUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d)).func_76458_c();
            defaultSpeed /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (RebirthUtil.mc.field_71439_g.func_70093_af()) {
            defaultSpeed /= 5.0;
        }
        return defaultSpeed;
    }

    public static double getJumpSpeed() {
        double defaultSpeed = 0.0;
        if (RebirthUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76430_j)) {
            int amplifier = RebirthUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76430_j).func_76458_c();
            defaultSpeed += (double)(amplifier + 1) * 0.1;
        }
        return defaultSpeed;
    }

    public static void strafe(MoveEvent event, double speed) {
        if (RebirthUtil.isMoving()) {
            double[] strafe = RebirthUtil.strafe(speed);
            event.setX(strafe[0]);
            event.setZ(strafe[1]);
        } else {
            event.setX(0.0);
            event.setZ(0.0);
        }
    }

    public static double[] strafe(double speed) {
        return RebirthUtil.strafe((Entity)RebirthUtil.mc.field_71439_g, speed);
    }

    public static double[] strafe(Entity entity, double speed) {
        return RebirthUtil.strafe(entity, RebirthUtil.mc.field_71439_g.field_71158_b, speed);
    }

    public static double[] strafe(Entity entity, MovementInput movementInput, double speed) {
        float moveForward = movementInput.field_192832_b;
        float moveStrafe = movementInput.field_78902_a;
        float rotationYaw = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double posX = (double)moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + (double)moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
        double posZ = (double)moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - (double)moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
        return new double[]{posX, posZ};
    }

    public static boolean isValid(Entity entity, double range) {
        boolean invalid = entity == null || EntityUtil.isDead(entity) || entity.equals((Object)RebirthUtil.mc.field_71439_g) || entity instanceof EntityPlayer && Client.friendManager.isFriend(entity.func_70005_c_()) || RebirthUtil.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(range);
        return !invalid;
    }

    public static void drawText(AxisAlignedBB axisAlignedBB, String text) {
        if (axisAlignedBB != null && text != null) {
            double x = axisAlignedBB.field_72340_a + (axisAlignedBB.field_72336_d - axisAlignedBB.field_72340_a) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78725_b;
            double y = axisAlignedBB.field_72338_b + (axisAlignedBB.field_72337_e - axisAlignedBB.field_72338_b) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78726_c - 1.5;
            double z = axisAlignedBB.field_72339_c + (axisAlignedBB.field_72334_f - axisAlignedBB.field_72339_c) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78723_d;
            RebirthUtil.drawText(text, x, y, z, new Color(255, 255, 255, 255));
        }
    }

    public static void drawText(AxisAlignedBB axisAlignedBB, String text, Color color) {
        if (axisAlignedBB != null && text != null) {
            double x = axisAlignedBB.field_72340_a + (axisAlignedBB.field_72336_d - axisAlignedBB.field_72340_a) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78725_b;
            double y = axisAlignedBB.field_72338_b + (axisAlignedBB.field_72337_e - axisAlignedBB.field_72338_b) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78726_c - 1.5;
            double z = axisAlignedBB.field_72339_c + (axisAlignedBB.field_72334_f - axisAlignedBB.field_72339_c) / 2.0 - RebirthUtil.mc.func_175598_ae().field_78723_d;
            RebirthUtil.drawText(text, x, y, z, color);
        }
    }

    public static void drawText(String text, double x, double y, double z, Color color) {
        Entity camera = mc.func_175606_aa();
        if (camera != null) {
            double originalPositionX = camera.field_70165_t;
            double originalPositionY = camera.field_70163_u;
            double originalPositionZ = camera.field_70161_v;
            camera.field_70165_t = camera.field_70169_q;
            camera.field_70163_u = camera.field_70167_r;
            camera.field_70161_v = camera.field_70166_s;
            int width = Client.textManager.getStringWidth(text) / 2;
            double scale = 0.027999999999999997;
            GlStateManager.func_179094_E();
            RenderHelper.func_74519_b();
            GlStateManager.func_179088_q();
            GlStateManager.func_179136_a((float)1.0f, (float)-1500000.0f);
            GlStateManager.func_179140_f();
            GlStateManager.func_179109_b((float)((float)x), (float)((float)y + 1.4f), (float)((float)z));
            GlStateManager.func_179114_b((float)(-RebirthUtil.mc.func_175598_ae().field_78735_i), (float)0.0f, (float)1.0f, (float)0.0f);
            float var10001 = RebirthUtil.mc.field_71474_y.field_74320_O == 2 ? -1.0f : 1.0f;
            GlStateManager.func_179114_b((float)RebirthUtil.mc.func_175598_ae().field_78732_j, (float)var10001, (float)0.0f, (float)0.0f);
            GlStateManager.func_179139_a((double)(-scale), (double)(-scale), (double)scale);
            GlStateManager.func_179097_i();
            Client.textManager.drawString(text, -width, -(Client.textManager.getFontHeight() - 1), ColorUtil.toRGBA(color), true);
            GlStateManager.func_179126_j();
            camera.field_70165_t = originalPositionX;
            camera.field_70163_u = originalPositionY;
            camera.field_70161_v = originalPositionZ;
            GlStateManager.func_179113_r();
            GlStateManager.func_179136_a((float)1.0f, (float)1500000.0f);
            GlStateManager.func_179121_F();
        }
    }

    public static class RenderUtil {
        public static void drawBBBox(AxisAlignedBB var0, Color var1, int var2) {
            AxisAlignedBB var3 = it.make.api.utils.RenderUtil.interpolateAxis(new AxisAlignedBB(var0.field_72340_a, var0.field_72338_b, var0.field_72339_c, var0.field_72336_d, var0.field_72337_e, var0.field_72334_f));
            float var4 = (float)var1.getRed() / 255.0f;
            float var5 = (float)var1.getGreen() / 255.0f;
            float var6 = (float)var1.getBlue() / 255.0f;
            float var7 = (float)var2 / 255.0f;
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLineWidth((float)1.0f);
            Tessellator var8 = Tessellator.func_178181_a();
            BufferBuilder var9 = var8.func_178180_c();
            var9.func_181668_a(3, DefaultVertexFormats.field_181706_f);
            var9.func_181662_b(var3.field_72340_a, var3.field_72338_b, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72338_b, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72338_b, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72338_b, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72338_b, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72337_e, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72337_e, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72338_b, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72338_b, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72337_e, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72337_e, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72337_e, var3.field_72334_f).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72337_e, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72338_b, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72336_d, var3.field_72337_e, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var9.func_181662_b(var3.field_72340_a, var3.field_72337_e, var3.field_72339_c).func_181666_a(var4, var5, var6, var7).func_181675_d();
            var8.func_78381_a();
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }

        public static void drawBoxESP(BlockPos var0, Color var1, int var2) {
            it.make.api.utils.RenderUtil.drawBox(var0, new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var2));
        }
    }
}

