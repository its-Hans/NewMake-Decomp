/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Enchantments
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemAir
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 */
package it.make.api.utils.second.skid;

import it.make.api.Wrapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;

public class InventoryUtil
implements Wrapper {
    public static void switchToHotbarSlot(Class clazz, boolean bl) {
        int n = InventoryUtil.findHotbarBlock(clazz);
        if (n > -1) {
            InventoryUtil.switchToHotbarSlot(n, bl);
        }
    }

    public static int findItemInventorySlot(Item item, boolean bl) {
        AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(-1);
        for (Map.Entry<Integer, ItemStack> entry : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
            if (entry.getValue().func_77973_b() != item || entry.getKey() == 45 && !bl) continue;
            atomicInteger.set(entry.getKey());
            return atomicInteger.get();
        }
        return atomicInteger.get();
    }

    public static boolean isNull(ItemStack itemStack) {
        return itemStack == null || itemStack.func_77973_b() instanceof ItemAir;
    }

    public static boolean isInstanceOf(ItemStack itemStack, Class clazz) {
        if (itemStack == null) {
            return false;
        }
        Item item = itemStack.func_77973_b();
        if (clazz.isInstance(item)) {
            return true;
        }
        if (item instanceof ItemBlock) {
            Block block = Block.func_149634_a((Item)item);
            return clazz.isInstance(block);
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int findArmorSlot(EntityEquipmentSlot entityEquipmentSlot, boolean bl) {
        int n = -1;
        float f = 0.0f;
        int i = 9;
        while (i < 45) {
            ItemArmor itemArmor;
            boolean bl2 = false;
            ItemStack itemStack = InventoryUtil.mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (itemStack.func_77973_b() != Items.field_190931_a && itemStack.func_77973_b() instanceof ItemArmor && (itemArmor = (ItemArmor)itemStack.func_77973_b()).func_185083_B_() == entityEquipmentSlot) {
                boolean bl3;
                float f2 = itemArmor.field_77879_b + EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_180310_c, (ItemStack)itemStack);
                if (!bl || !EnchantmentHelper.func_190938_b((ItemStack)itemStack)) {
                    bl2 = false;
                    bl3 = false;
                } else {
                    boolean bl32;
                    bl3 = bl32 = true;
                }
                if (f2 > f && !bl2) {
                    f = f2;
                    n = i;
                }
            }
            ++i;
        }
        return n;
    }

    public static List<Integer> findEmptySlots(boolean bl) {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        for (Map.Entry<Integer, ItemStack> entry : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
            if (!entry.getValue().func_190926_b() && entry.getValue().func_77973_b() != Items.field_190931_a) continue;
            arrayList.add(entry.getKey());
        }
        if (bl) {
            for (int i = 1; i < 5; ++i) {
                Slot slot = (Slot)InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack itemStack = slot.func_75211_c();
                if (!itemStack.func_190926_b() && itemStack.func_77973_b() != Items.field_190931_a) continue;
                arrayList.add(i);
            }
        }
        return arrayList;
    }

    public static int getItemHotbars(Item item) {
        for (int i = 0; i < 36; ++i) {
            Item item2 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (Item.func_150891_b((Item)item2) != Item.func_150891_b((Item)item)) continue;
            return i;
        }
        return -1;
    }

    public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
        return InventoryUtil.getInventorySlots();
    }

    public static boolean isBlock(Item item, Class clazz) {
        if (item instanceof ItemBlock) {
            Block block = ((ItemBlock)item).func_179223_d();
            return clazz.isInstance(block);
        }
        return false;
    }

    public static int findItemInHotbar(Item item) {
        int n = -1;
        for (int i = 0; i < 9; ++i) {
            if (InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != item) continue;
            n = i;
            break;
        }
        return n;
    }

    public static int findHotbarBlock(Block block) {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (itemStack == ItemStack.field_190927_a || !(itemStack.func_77973_b() instanceof ItemBlock) || ((ItemBlock)itemStack.func_77973_b()).func_179223_d() != block) continue;
            return i;
        }
        return -1;
    }

    public static void switchToHotbarSlot(int n, boolean bl) {
        if (InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == n || n < 0) {
            return;
        }
        if (bl) {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(n));
            InventoryUtil.mc.field_71442_b.func_78765_e();
        } else {
            InventoryUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(n));
            InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c = n;
            InventoryUtil.mc.field_71442_b.func_78765_e();
        }
    }

    public static int getItemDurability(ItemStack itemStack) {
        if (itemStack == null) {
            return 0;
        }
        return itemStack.func_77958_k() - itemStack.func_77952_i();
    }

    public static int getEmptyXCarry() {
        for (int i = 1; i < 5; ++i) {
            Slot slot = (Slot)InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
            ItemStack itemStack = slot.func_75211_c();
            if (!itemStack.func_190926_b() && itemStack.func_77973_b() != Items.field_190931_a) continue;
            return i;
        }
        return -1;
    }

    public static boolean holdingItem(Class clazz) {
        ItemStack itemStack = InventoryUtil.mc.field_71439_g.func_184614_ca();
        boolean bl = InventoryUtil.isInstanceOf(itemStack, clazz);
        if (!bl) {
            bl = InventoryUtil.isInstanceOf(itemStack, clazz);
        }
        return bl;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static int findArmorSlot(EntityEquipmentSlot entityEquipmentSlot, boolean bl, boolean bl2) {
        int n = InventoryUtil.findArmorSlot(entityEquipmentSlot, bl);
        if (n == -1 && bl2) {
            float f = 0.0f;
            for (int i = 1; i < 5; ++i) {
                boolean bl3;
                ItemArmor itemArmor;
                boolean bl32 = false;
                Slot slot = (Slot)InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack itemStack = slot.func_75211_c();
                if (itemStack.func_77973_b() == Items.field_190931_a || !(itemStack.func_77973_b() instanceof ItemArmor) || (itemArmor = (ItemArmor)itemStack.func_77973_b()).func_185083_B_() != entityEquipmentSlot) continue;
                float f2 = itemArmor.field_77879_b + EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_180310_c, (ItemStack)itemStack);
                if (!bl || !EnchantmentHelper.func_190938_b((ItemStack)itemStack)) {
                    bl32 = false;
                    bl3 = false;
                } else {
                    boolean bl4;
                    bl3 = bl4 = true;
                }
                if (!(f2 > f) || bl32) continue;
                f = f2;
                n = i;
            }
        }
        return n;
    }

    private static Map<Integer, ItemStack> getInventorySlots() {
        HashMap<Integer, ItemStack> hashMap = new HashMap<Integer, ItemStack>();
        for (int i = 9; i <= 44; ++i) {
            hashMap.put(i, (ItemStack)InventoryUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(i));
        }
        return hashMap;
    }

    public static int findItemInventorySlot(Item item, boolean bl, boolean bl2) {
        int n = InventoryUtil.findItemInventorySlot(item, bl);
        if (n == -1 && bl2) {
            for (int i = 1; i < 5; ++i) {
                Slot slot = (Slot)InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
                ItemStack itemStack = slot.func_75211_c();
                if (itemStack.func_77973_b() == Items.field_190931_a || itemStack.func_77973_b() != item) continue;
                n = i;
            }
        }
        return n;
    }

    public static int findAnyBlock() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (itemStack == ItemStack.field_190927_a || !(itemStack.func_77973_b() instanceof ItemBlock)) continue;
            return i;
        }
        return -1;
    }

    public static void switchToItem(Item item) {
        int n = InventoryUtil.getItemHotbar(item);
        if (n == -1) {
            return;
        }
        InventoryUtil.switchToHotbarSlot(n, false);
    }

    public static int getItemHotbar(Item item) {
        for (int i = 0; i < 9; ++i) {
            Item item2 = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
            if (Item.func_150891_b((Item)item2) != Item.func_150891_b((Item)item)) continue;
            return i;
        }
        return -1;
    }

    public static void switchToSlot(int n) {
        if (InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c == n || n < 0) {
            return;
        }
        InventoryUtil.mc.field_71439_g.field_71071_by.field_70461_c = n;
        InventoryUtil.mc.field_71442_b.func_78765_e();
    }

    public static int pickItem(int n) {
        ArrayList<Object> arrayList = new ArrayList<Object>();
        for (int i = 0; i < 9; ++i) {
            if (Item.func_150891_b((Item)((ItemStack)InventoryUtil.mc.field_71439_g.field_71071_by.field_70462_a.get(i)).func_77973_b()) != n) continue;
            arrayList.add(InventoryUtil.mc.field_71439_g.field_71071_by.field_70462_a.get(i));
        }
        if (arrayList.size() >= 1) {
            return InventoryUtil.mc.field_71439_g.field_71071_by.field_70462_a.indexOf(arrayList.get(0));
        }
        return -1;
    }

    public static int findPistonBlock() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (itemStack == ItemStack.field_190927_a || !(itemStack.func_77973_b() instanceof ItemBlock) || !(((ItemBlock)itemStack.func_77973_b()).func_179223_d() instanceof BlockPistonBase)) continue;
            return i;
        }
        return -1;
    }

    public static int findHotbarBlock(Class clazz) {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (itemStack == ItemStack.field_190927_a) continue;
            if (clazz.isInstance(itemStack.func_77973_b())) {
                return i;
            }
            if (!(itemStack.func_77973_b() instanceof ItemBlock) || !clazz.isInstance(((ItemBlock)itemStack.func_77973_b()).func_179223_d())) continue;
            return i;
        }
        return -1;
    }

    public static boolean isSlotEmpty(int n) {
        Slot slot = (Slot)InventoryUtil.mc.field_71439_g.field_71069_bz.field_75151_b.get(n);
        ItemStack itemStack = slot.func_75211_c();
        return itemStack.func_190926_b();
    }

    public static int findInventoryBlock(Class clazz, boolean bl) {
        AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.set(-1);
        for (Map.Entry<Integer, ItemStack> entry : InventoryUtil.getInventoryAndHotbarSlots().entrySet()) {
            if (!InventoryUtil.isBlock(entry.getValue().func_77973_b(), clazz) || entry.getKey() == 45 && !bl) continue;
            atomicInteger.set(entry.getKey());
            return atomicInteger.get();
        }
        return atomicInteger.get();
    }

    public static int findHotbarClass(Class clazz) {
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = InventoryUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack == ItemStack.field_190927_a) continue;
            if (clazz.isInstance(stack.func_77973_b())) {
                return i;
            }
            if (!(stack.func_77973_b() instanceof ItemBlock) || !clazz.isInstance(((ItemBlock)stack.func_77973_b()).func_179223_d())) continue;
            return i;
        }
        return -1;
    }

    public static class Task {
        private final int slot;
        private final boolean update;
        private final boolean quickClick;

        public Task() {
            this.update = true;
            this.slot = -1;
            this.quickClick = false;
        }

        public Task(int n) {
            this.slot = n;
            this.quickClick = false;
            this.update = false;
        }

        public void run() {
            if (this.update) {
                Wrapper.mc.field_71442_b.func_78765_e();
            }
            if (this.slot != -1) {
                Wrapper.mc.field_71442_b.func_187098_a(0, this.slot, 0, this.quickClick ? ClickType.QUICK_MOVE : ClickType.PICKUP, (EntityPlayer)Wrapper.mc.field_71439_g);
            }
        }

        public Task(int n, boolean bl) {
            this.slot = n;
            this.quickClick = bl;
            this.update = false;
        }
    }
}

