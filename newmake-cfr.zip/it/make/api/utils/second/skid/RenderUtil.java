/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.BufferBuilder
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.RenderGlobal
 *  net.minecraft.client.renderer.RenderItem
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.culling.Frustum
 *  net.minecraft.client.renderer.culling.ICamera
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.client.shader.Framebuffer
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.EXTFramebufferObject
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package it.make.api.utils.second.skid;

import it.make.Client;
import it.make.api.Wrapper;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.second.skid.EntityUtil;
import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.Objects;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class RenderUtil
implements Wrapper {
    private static boolean bind;
    private static boolean clean;
    private static final FloatBuffer projection;
    private static final IntBuffer viewport;
    static final boolean $assertionsDisabled;
    public static final ICamera camera;
    private static boolean override;
    private static final FloatBuffer modelView;
    private static final Frustum frustrum;
    public static final RenderItem itemRender;
    private static boolean texture;
    private static final FloatBuffer screenCoords;
    private static boolean depth;

    public static void drawBoxESP(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air, double height, boolean gradientBox, boolean gradientOutline, boolean invertGradientBox, boolean invertGradientOutline, int gradientAlpha) {
        if (box) {
            RenderUtil.drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha), height, gradientBox, invertGradientBox, gradientAlpha);
        }
        if (outline) {
            RenderUtil.drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air, height, gradientOutline, invertGradientOutline, gradientAlpha);
        }
    }

    public static void drawOutlineRect(double x, double y, double w, double h, float lineWidth, Color color) {
        RenderUtil.drawLine(x, y, x + w, y, lineWidth, color);
        RenderUtil.drawLine(x, y, x, y + h, lineWidth, color);
        RenderUtil.drawLine(x, y + h, x + w, y + h, lineWidth, color);
        RenderUtil.drawLine(x + w, y, x + w, y + h, lineWidth, color);
    }

    public static void drawLine(Double x1, Double y1, Double x2, Double y2, Float lineWidth) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)lineWidth.floatValue());
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)2);
        GL11.glVertex2d((double)x1, (double)y1);
        GL11.glVertex2d((double)x2, (double)y2);
        GL11.glEnd();
        GL11.glShadeModel((int)7424);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
    }

    public static void drawLine(double x1, double y1, double x2, double y2, float lineWidth, Color ColorStart) {
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)lineWidth);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)2);
        RenderUtil.setColor(ColorStart);
        GL11.glVertex2d((double)x1, (double)y1);
        GL11.glVertex2d((double)x2, (double)y2);
        GL11.glEnd();
        GL11.glShadeModel((int)7424);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
    }

    public static void drawSexyBoxPhobosIsRetardedFuckYouESP(AxisAlignedBB axisAlignedBB, Color color, Color color2, float f, boolean bl, boolean bl2, float f2, float f3, float f4) {
        double d = 0.5 * (double)(1.0f - f3);
        AxisAlignedBB axisAlignedBB2 = RenderUtil.interpolateAxis(new AxisAlignedBB(axisAlignedBB.field_72340_a + d, axisAlignedBB.field_72338_b + d + (double)(1.0f - f4), axisAlignedBB.field_72339_c + d, axisAlignedBB.field_72336_d - d, axisAlignedBB.field_72337_e - d, axisAlignedBB.field_72334_f - d));
        float f5 = (float)color.getRed() / 255.0f;
        float f6 = (float)color.getGreen() / 255.0f;
        float f7 = (float)color.getBlue() / 255.0f;
        float f8 = (float)color.getAlpha() / 255.0f;
        float f9 = (float)color2.getRed() / 255.0f;
        float f10 = (float)color2.getGreen() / 255.0f;
        float f11 = (float)color2.getBlue() / 255.0f;
        float f12 = (float)color2.getAlpha() / 255.0f;
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        f8 *= f2;
        f12 *= f2;
        if (bl2) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB2, (float)f5, (float)f6, (float)f7, (float)f8);
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
        if (bl) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLineWidth((float)f);
            Tessellator tessellator = Tessellator.func_178181_a();
            BufferBuilder bufferBuilder = tessellator.func_178180_c();
            bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72334_f).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72338_b, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72336_d, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB2.field_72340_a, axisAlignedBB2.field_72337_e, axisAlignedBB2.field_72339_c).func_181666_a(f9, f10, f11, f12).func_181675_d();
            tessellator.func_78381_a();
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static boolean isInViewFrustrum(Entity entity) {
        return RenderUtil.isInViewFrustrum(entity.func_174813_aQ()) || entity.field_70158_ak;
    }

    public static void drawColorBox(AxisAlignedBB axisAlignedBB, float f, float f2, float f3, float f4) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f, f2, f3, f4).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void prepareGL3D() {
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179097_i();
        GlStateManager.func_179118_c();
        GlStateManager.func_179129_p();
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GlStateManager.func_179103_j((int)7425);
        GlStateManager.func_179090_x();
        GlStateManager.func_179140_f();
        GlStateManager.func_179132_a((boolean)false);
    }

    private static void GLPost(boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        GlStateManager.func_179132_a((boolean)true);
        if (!bl5) {
            GL11.glDisable((int)2848);
        }
        if (bl4) {
            GL11.glEnable((int)2929);
        }
        if (bl3) {
            GL11.glEnable((int)3553);
        }
        if (!bl2) {
            GL11.glDisable((int)3042);
        }
        if (bl) {
            GL11.glEnable((int)2896);
        }
    }

    public static void drawGradientRect(int n, int n2, int n3, int n4, int n5, int n6) {
        float f = (float)(n5 >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n5 >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n5 >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n5 & 0xFF) / 255.0f;
        float f5 = (float)(n6 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n6 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n6 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n6 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)n + (double)n3, (double)n2, 0.0).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b((double)n, (double)n2, 0.0).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b((double)n, (double)n2 + (double)n4, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)n + (double)n3, (double)n2 + (double)n4, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawFilledBox(AxisAlignedBB axisAlignedBB, int n) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void drawOpenGradientBox(BlockPos blockPos, Color color, Color color2, double d) {
        for (EnumFacing enumFacing : EnumFacing.values()) {
            if (enumFacing == EnumFacing.UP) continue;
            RenderUtil.drawGradientPlane(blockPos, enumFacing, color, color2, d);
        }
    }

    public static void drawBoxESP(BlockPos blockPos, Color color, float f, boolean bl, boolean bl2, int n) {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)blockPos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, (double)blockPos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, (double)blockPos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(blockPos.func_177958_n() + 1) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(blockPos.func_177956_o() + 1) - RenderUtil.mc.func_175598_ae().field_78731_m, (double)(blockPos.func_177952_p() + 1) - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLineWidth((float)f);
            if (bl2) {
                RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)n / 255.0f));
            }
            if (bl) {
                RenderGlobal.func_189694_a((double)axisAlignedBB.field_72340_a, (double)axisAlignedBB.field_72338_b, (double)axisAlignedBB.field_72339_c, (double)axisAlignedBB.field_72336_d, (double)axisAlignedBB.field_72337_e, (double)axisAlignedBB.field_72334_f, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            }
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void drawText(AxisAlignedBB axisAlignedBB, String string) {
        if (axisAlignedBB == null || string == null) {
            return;
        }
        GlStateManager.func_179094_E();
        RenderUtil.glBillboardDistanceScaled((float)axisAlignedBB.field_72340_a + 0.5f, (float)axisAlignedBB.field_72338_b + 0.5f, (float)axisAlignedBB.field_72339_c + 0.5f, (EntityPlayer)RenderUtil.mc.field_71439_g, 1.0f);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b((double)(-((double)Client.textManager.getStringWidth(string) / 2.0)), (double)0.0, (double)0.0);
        Client.textManager.drawStringWithShadow(string, 0.0f, 0.0f, -5592406);
        GlStateManager.func_179121_F();
    }

    public static void glScissor(float f, float f2, float f3, float f4, ScaledResolution scaledResolution) {
        GL11.glScissor((int)((int)(f * (float)scaledResolution.func_78325_e())), (int)((int)((float)RenderUtil.mc.field_71440_d - f4 * (float)scaledResolution.func_78325_e())), (int)((int)((f3 - f) * (float)scaledResolution.func_78325_e())), (int)((int)((f4 - f2) * (float)scaledResolution.func_78325_e())));
    }

    public static void drawBlockOutline(AxisAlignedBB axisAlignedBB, Color color, float f) {
        float f2 = (float)color.getRed() / 255.0f;
        float f3 = (float)color.getGreen() / 255.0f;
        float f4 = (float)color.getBlue() / 255.0f;
        float f5 = (float)color.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static Vec3d to2D(double d, double d2, double d3) {
        GL11.glGetFloat((int)2982, (FloatBuffer)modelView);
        GL11.glGetFloat((int)2983, (FloatBuffer)projection);
        GL11.glGetInteger((int)2978, (IntBuffer)viewport);
        boolean bl = GLU.gluProject((float)((float)d), (float)((float)d2), (float)((float)d3), (FloatBuffer)modelView, (FloatBuffer)projection, (IntBuffer)viewport, (FloatBuffer)screenCoords);
        if (bl) {
            return new Vec3d((double)screenCoords.get(0), (double)((float)Display.getHeight() - screenCoords.get(1)), (double)screenCoords.get(2));
        }
        return null;
    }

    public static void drawBlockOutline(BlockPos blockPos, Color color, float f, boolean bl) {
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        if ((bl || iBlockState.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(blockPos)) {
            Vec3d vec3d = EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, mc.func_184121_ak());
            RenderUtil.drawBlockOutline(iBlockState.func_185918_c((World)RenderUtil.mc.field_71441_e, blockPos).func_186662_g((double)0.002f).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c), color, f);
        }
    }

    public static void drawGradientPlane(BlockPos blockPos, EnumFacing enumFacing, Color color, Color color2, double d) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        Vec3d vec3d = EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, mc.func_184121_ak());
        AxisAlignedBB axisAlignedBB = iBlockState.func_185918_c((World)RenderUtil.mc.field_71441_e, blockPos).func_186662_g((double)0.002f).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c).func_72321_a(0.0, d, 0.0);
        float f = (float)color.getRed() / 255.0f;
        float f2 = (float)color.getGreen() / 255.0f;
        float f3 = (float)color.getBlue() / 255.0f;
        float f4 = (float)color.getAlpha() / 255.0f;
        float f5 = (float)color2.getRed() / 255.0f;
        float f6 = (float)color2.getGreen() / 255.0f;
        float f7 = (float)color2.getBlue() / 255.0f;
        float f8 = (float)color2.getAlpha() / 255.0f;
        double d2 = 0.0;
        double d3 = 0.0;
        double d4 = 0.0;
        double d5 = 0.0;
        double d6 = 0.0;
        double d7 = 0.0;
        if (enumFacing == EnumFacing.DOWN) {
            d2 = axisAlignedBB.field_72340_a;
            d5 = axisAlignedBB.field_72336_d;
            d3 = axisAlignedBB.field_72338_b;
            d6 = axisAlignedBB.field_72338_b;
            d4 = axisAlignedBB.field_72339_c;
            d7 = axisAlignedBB.field_72334_f;
        } else if (enumFacing == EnumFacing.UP) {
            d2 = axisAlignedBB.field_72340_a;
            d5 = axisAlignedBB.field_72336_d;
            d3 = axisAlignedBB.field_72337_e;
            d6 = axisAlignedBB.field_72337_e;
            d4 = axisAlignedBB.field_72339_c;
            d7 = axisAlignedBB.field_72334_f;
        } else if (enumFacing == EnumFacing.EAST) {
            d2 = axisAlignedBB.field_72336_d;
            d5 = axisAlignedBB.field_72336_d;
            d3 = axisAlignedBB.field_72338_b;
            d6 = axisAlignedBB.field_72337_e;
            d4 = axisAlignedBB.field_72339_c;
            d7 = axisAlignedBB.field_72334_f;
        } else if (enumFacing == EnumFacing.WEST) {
            d2 = axisAlignedBB.field_72340_a;
            d5 = axisAlignedBB.field_72340_a;
            d3 = axisAlignedBB.field_72338_b;
            d6 = axisAlignedBB.field_72337_e;
            d4 = axisAlignedBB.field_72339_c;
            d7 = axisAlignedBB.field_72334_f;
        } else if (enumFacing == EnumFacing.SOUTH) {
            d2 = axisAlignedBB.field_72340_a;
            d5 = axisAlignedBB.field_72336_d;
            d3 = axisAlignedBB.field_72338_b;
            d6 = axisAlignedBB.field_72337_e;
            d4 = axisAlignedBB.field_72334_f;
            d7 = axisAlignedBB.field_72334_f;
        } else if (enumFacing == EnumFacing.NORTH) {
            d2 = axisAlignedBB.field_72340_a;
            d5 = axisAlignedBB.field_72336_d;
            d3 = axisAlignedBB.field_72338_b;
            d6 = axisAlignedBB.field_72337_e;
            d4 = axisAlignedBB.field_72339_c;
            d7 = axisAlignedBB.field_72339_c;
        }
        GlStateManager.func_179094_E();
        GlStateManager.func_179097_i();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179132_a((boolean)false);
        bufferBuilder.func_181668_a(5, DefaultVertexFormats.field_181706_f);
        if (enumFacing == EnumFacing.EAST || enumFacing == EnumFacing.WEST || enumFacing == EnumFacing.NORTH || enumFacing == EnumFacing.SOUTH) {
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
        } else if (enumFacing == EnumFacing.UP) {
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f5, f6, f7, f8).func_181675_d();
        } else if (enumFacing == EnumFacing.DOWN) {
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d3, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d2, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d4).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
            bufferBuilder.func_181662_b(d5, d6, d7).func_181666_a(f, f2, f3, f4).func_181675_d();
        }
        tessellator.func_78381_a();
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179126_j();
        GlStateManager.func_179121_F();
    }

    public static void drawBoxESP(BlockPos blockPos, Color color, boolean bl, Color color2, float f, boolean bl2, boolean bl3, int n, boolean bl4) {
        if (bl3) {
            RenderUtil.drawBox(blockPos, new Color(color.getRed(), color.getGreen(), color.getBlue(), n));
        }
        if (bl2) {
            RenderUtil.drawBlockOutline(blockPos, bl ? color2 : color, f, bl4);
        }
    }

    public static void drawArc(float f, float f2, float f3, float f4, float f5, int n) {
        GL11.glBegin((int)4);
        int n2 = (int)((float)n / (360.0f / f4)) + 1;
        while ((float)n2 <= (float)n / (360.0f / f5)) {
            double d = Math.PI * 2 * (double)(n2 - 1) / (double)n;
            double d2 = Math.PI * 2 * (double)n2 / (double)n;
            GL11.glVertex2d((double)f, (double)f2);
            GL11.glVertex2d((double)((double)f + Math.cos(d2) * (double)f3), (double)((double)f2 + Math.sin(d2) * (double)f3));
            GL11.glVertex2d((double)((double)f + Math.cos(d) * (double)f3), (double)((double)f2 + Math.sin(d) * (double)f3));
            ++n2;
        }
        RenderUtil.glEnd();
    }

    public static void drawOutlinedRoundedRectangle(int n, int n2, int n3, int n4, float f, float f2, float f3, float f4, float f5, float f6) {
        RenderUtil.drawRoundedRectangle(n, n2, n3, n4, f);
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f5);
        RenderUtil.drawRoundedRectangle((float)n + f6, (float)n2 + f6, (float)n3 - f6 * 2.0f, (float)n4 - f6 * 2.0f, f);
    }

    public static void drawGradientSideways(double d, double d2, double d3, double d4, int n, int n2) {
        float f = (float)(n >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n & 0xFF) / 255.0f;
        float f5 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n2 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glPushMatrix();
        GL11.glBegin((int)7);
        GL11.glColor4f((float)f2, (float)f3, (float)f4, (float)f);
        GL11.glVertex2d((double)d, (double)d2);
        GL11.glVertex2d((double)d, (double)d4);
        GL11.glColor4f((float)f6, (float)f7, (float)f8, (float)f5);
        GL11.glVertex2d((double)d3, (double)d4);
        GL11.glVertex2d((double)d3, (double)d2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glShadeModel((int)7424);
    }

    public static void drawEntityBoxESP(Entity entity, Color color, boolean bl, Color color2, float f, boolean bl2, boolean bl3, int n) {
        Vec3d vec3d = RenderUtil.getInterpolatedPos(entity, mc.func_184121_ak(), true);
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + vec3d.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + vec3d.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + vec3d.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + vec3d.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + vec3d.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + vec3d.field_72449_c);
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        if (bl3) {
            RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)n / 255.0f));
        }
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
        if (bl2) {
            RenderUtil.drawBlockOutline(axisAlignedBB, bl ? color2 : color, f, false);
        }
    }

    public static void drawLine(float f, float f2, float f3, float f4, float f5, int n) {
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        float f9 = (float)(n >> 24 & 0xFF) / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        GlStateManager.func_179103_j((int)7425);
        GL11.glLineWidth((float)f5);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f4, 0.0).func_181666_a(f6, f7, f8, f9).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GL11.glDisable((int)2848);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179121_F();
    }

    public static void drawText(BlockPos blockPos, String string) {
        if (blockPos == null || string == null) {
            return;
        }
        GlStateManager.func_179094_E();
        RenderUtil.glBillboard((float)blockPos.func_177958_n() + 0.5f, (float)blockPos.func_177956_o() + 0.5f, (float)blockPos.func_177952_p() + 0.5f);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b((double)(-((double)Client.textManager.getStringWidth(string) / 2.0)), (double)0.0, (double)0.0);
        Client.textManager.drawStringWithShadow(string, 0.0f, 0.0f, -5592406);
        GlStateManager.func_179121_F();
    }

    public static void drawText(String s, double x, double y, double z) {
        GlStateManager.func_179094_E();
        RenderUtil.glBillboard((float)x, (float)y, (float)z);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b((double)(-((double)Client.textManager.getStringWidth(s) / 2.0)), (double)0.0, (double)0.0);
        Client.textManager.drawStringWithShadow(s, 0.0f, 0.0f, -5592406);
        GlStateManager.func_179121_F();
    }

    public static void drawRect(float f, float f2, float f3, float f4, int n) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179147_l();
        GlStateManager.func_179090_x();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)f, (double)f4, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f4, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
    }

    public static void drawBlockOutline(BlockPos blockPos, Color color, float f, boolean bl, double d, boolean bl2, boolean bl3, int n, boolean bl4) {
        if (bl2) {
            Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
            RenderUtil.drawFadingOutline(blockPos, bl3 ? color : color2, bl3 ? color2 : color, f, d);
            return;
        }
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        if ((bl || iBlockState.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(blockPos)) {
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)blockPos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, (double)blockPos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, (double)blockPos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(blockPos.func_177958_n() + 1) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(blockPos.func_177956_o() + 1) - RenderUtil.mc.func_175598_ae().field_78731_m + d, (double)(blockPos.func_177952_p() + 1) - RenderUtil.mc.func_175598_ae().field_78728_n);
            RenderUtil.drawBlockOutline(axisAlignedBB.func_186662_g((double)0.002f), color, f, bl4);
        }
    }

    public static boolean isInViewFrustrum(AxisAlignedBB axisAlignedBB) {
        Entity entity = Minecraft.func_71410_x().func_175606_aa();
        if (!$assertionsDisabled && entity == null) {
            throw new AssertionError();
        }
        frustrum.func_78547_a(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v);
        return frustrum.func_78546_a(axisAlignedBB);
    }

    public static void drawBoxESP(BlockPos blockPos, Color color, boolean bl, Color color2, float f, boolean bl2, boolean bl3, int n, boolean bl4, double d) {
        if (bl3) {
            RenderUtil.drawBox(blockPos, new Color(color.getRed(), color.getGreen(), color.getBlue(), n), d, false, false, 0);
        }
        if (bl2) {
            RenderUtil.drawBlockOutline(blockPos, bl ? color2 : color, f, bl4, d, false, false, 0, false);
        }
    }

    public static void drawCircle(float f, float f2, float f3, float f4, Color color) {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)f - RenderUtil.mc.func_175598_ae().field_78730_l, (double)f2 - RenderUtil.mc.func_175598_ae().field_78731_m, (double)f3 - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(f + 1.0f) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(f2 + 1.0f) - RenderUtil.mc.func_175598_ae().field_78731_m, (double)(f3 + 1.0f) - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            RenderUtil.drawCircleVertices(axisAlignedBB, f4, color);
        }
    }

    public static void GlPost() {
        RenderUtil.GLPost(depth, texture, clean, bind, override);
    }

    public static void drawBBFill(AxisAlignedBB axisAlignedBB, Color color, int n) {
        AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(axisAlignedBB.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB2.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB2.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB2, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)n / 255.0f));
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void drawBBBox(BlockPos blockPos, Color color) {
        AxisAlignedBB axisAlignedBB = RenderUtil.mc.field_71441_e.func_180495_p(blockPos).func_185918_c((World)RenderUtil.mc.field_71441_e, blockPos);
        double d = axisAlignedBB.field_72340_a + (axisAlignedBB.field_72336_d - axisAlignedBB.field_72340_a) / 2.0;
        double d2 = axisAlignedBB.field_72338_b + (axisAlignedBB.field_72337_e - axisAlignedBB.field_72338_b) / 2.0;
        double d3 = axisAlignedBB.field_72339_c + (axisAlignedBB.field_72334_f - axisAlignedBB.field_72339_c) / 2.0;
        double d4 = 10.01 * ((axisAlignedBB.field_72336_d - d) / 10.0);
        double d5 = 10.01 * ((axisAlignedBB.field_72337_e - d2) / 10.0);
        double d6 = 10.01 * ((axisAlignedBB.field_72334_f - d3) / 10.0);
        AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(d - d4, d2 - d5, d3 - d6, d + d4, d2 + d5, d3 + d6);
        AxisAlignedBB axisAlignedBB3 = new AxisAlignedBB(axisAlignedBB2.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB2.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB3.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB3.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB3.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB3.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB3.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB3.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189697_a((AxisAlignedBB)axisAlignedBB3, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void drawBlockOutline(BlockPos blockPos, Color color, float f, boolean bl, double d, boolean bl2, boolean bl3, int n) {
        if (bl2) {
            Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
            RenderUtil.drawGradientBlockOutline(blockPos, bl3 ? color2 : color, bl3 ? color : color2, f, d);
            return;
        }
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        if ((bl || iBlockState.func_185904_a() != Material.field_151579_a) && RenderUtil.mc.field_71441_e.func_175723_af().func_177746_a(blockPos)) {
            AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)blockPos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, (double)blockPos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, (double)blockPos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(blockPos.func_177958_n() + 1) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(blockPos.func_177956_o() + 1) - RenderUtil.mc.func_175598_ae().field_78731_m + d, (double)(blockPos.func_177952_p() + 1) - RenderUtil.mc.func_175598_ae().field_78728_n);
            RenderUtil.drawBlockOutline(axisAlignedBB.func_186662_g((double)0.002f), color, f);
        }
    }

    public static void drawPolygonPart(double d, double d2, int n, int n2, int n3, int n4) {
        float f = (float)(n3 >> 24 & 0xFF) / 255.0f;
        float f2 = (float)(n3 >> 16 & 0xFF) / 255.0f;
        float f3 = (float)(n3 >> 8 & 0xFF) / 255.0f;
        float f4 = (float)(n3 & 0xFF) / 255.0f;
        float f5 = (float)(n4 >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n4 >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n4 >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n4 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(6, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(d, d2, 0.0).func_181666_a(f2, f3, f4, f).func_181675_d();
        double d3 = Math.PI * 2;
        for (int i = n2 * 90; i <= n2 * 90 + 90; ++i) {
            double d4 = Math.PI * 2 * (double)i / 360.0 + Math.toRadians(180.0);
            bufferBuilder.func_181662_b(d + Math.sin(d4) * (double)n, d2 + Math.cos(d4) * (double)n, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        }
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void glBillboardDistanceScaled(float f, float f2, float f3, EntityPlayer entityPlayer, float f4) {
        RenderUtil.glBillboard(f, f2, f3);
        int n = (int)entityPlayer.func_70011_f((double)f, (double)f2, (double)f3);
        float f5 = (float)n / 2.0f / (2.0f + (2.0f - f4));
        if (f5 < 1.0f) {
            f5 = 1.0f;
        }
        GlStateManager.func_179152_a((float)f5, (float)f5, (float)f5);
    }

    public static void drawBoundingBox(AxisAlignedBB axisAlignedBB, float f, int n) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        float f2 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f3 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f4 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f5 = (float)(n & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f3, f4, f5, f2).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void setColor(Color color) {
        GL11.glColor4d((double)((double)color.getRed() / 255.0), (double)((double)color.getGreen() / 255.0), (double)((double)color.getBlue() / 255.0), (double)((double)color.getAlpha() / 255.0));
    }

    public static void glColor(Color color) {
        GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
    }

    public static int getRainbow(int n, int n2, float f, float f2) {
        float f3 = (System.currentTimeMillis() + (long)n2) % (long)n;
        return Color.getHSBColor(f3 / (float)n, f, f2).getRGB();
    }

    public static void renderThree() {
        GL11.glStencilFunc((int)514, (int)1, (int)15);
        GL11.glStencilOp((int)7680, (int)7680, (int)7680);
        GL11.glPolygonMode((int)1032, (int)6913);
    }

    public static void drawHGradientRect(float f, float f2, float f3, float f4, int n, int n2) {
        float f5 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f7 = (float)(n & 0xFF) / 255.0f;
        float f8 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f11 = (float)(n2 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_181666_a(f5, f6, f7, f8).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f4, 0.0).func_181666_a(f5, f6, f7, f8).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f4, 0.0).func_181666_a(f9, f10, f11, f8).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f2, 0.0).func_181666_a(f9, f10, f11, f8).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawGlow(double d, double d2, double d3, double d4, int n) {
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        RenderUtil.drawVGradientRect((int)d, (int)d2, (int)d3, (int)(d2 + (d4 - d2) / 2.0), ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0), n);
        RenderUtil.drawVGradientRect((int)d, (int)(d2 + (d4 - d2) / 2.0), (int)d3, (int)d4, n, ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0));
        int n2 = (int)((d4 - d2) / 2.0);
        RenderUtil.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 0, n, ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0));
        RenderUtil.drawPolygonPart(d, d2 + (d4 - d2) / 2.0, n2, 1, n, ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0));
        RenderUtil.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 2, n, ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0));
        RenderUtil.drawPolygonPart(d3, d2 + (d4 - d2) / 2.0, n2, 3, n, ColorUtil.toRGBA(new Color(n).getRed(), new Color(n).getGreen(), new Color(n).getBlue(), 0));
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawCircleOutline(float f, float f2, float f3) {
        RenderUtil.drawCircleOutline(f, f2, f3, 0, 360, 40);
    }

    public static void drawCircleVertices(AxisAlignedBB axisAlignedBB, float f, Color color) {
        float f2 = (float)color.getRed() / 255.0f;
        float f3 = (float)color.getGreen() / 255.0f;
        float f4 = (float)color.getBlue() / 255.0f;
        float f5 = (float)color.getAlpha() / 255.0f;
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)1.0f);
        for (int i = 0; i < 360; ++i) {
            bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
            bufferBuilder.func_181662_b(axisAlignedBB.func_189972_c().field_72450_a + Math.sin((double)i * 3.1415926 / 180.0) * (double)f, axisAlignedBB.field_72338_b, axisAlignedBB.func_189972_c().field_72449_c + Math.cos((double)i * 3.1415926 / 180.0) * (double)f).func_181666_a(f2, f3, f4, f5).func_181675_d();
            bufferBuilder.func_181662_b(axisAlignedBB.func_189972_c().field_72450_a + Math.sin((double)(i + 1) * 3.1415926 / 180.0) * (double)f, axisAlignedBB.field_72338_b, axisAlignedBB.func_189972_c().field_72449_c + Math.cos((double)(i + 1) * 3.1415926 / 180.0) * (double)f).func_181666_a(f2, f3, f4, f5).func_181675_d();
            tessellator.func_78381_a();
        }
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void drawBBBox(AxisAlignedBB axisAlignedBB, Color color, int n) {
        AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(axisAlignedBB.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB2.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB2.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB2.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB2.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189697_a((AxisAlignedBB)axisAlignedBB2, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)n / 255.0f));
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void glBillboard(float f, float f2, float f3) {
        float f4 = 0.02666667f;
        Vec3d renderPos = RenderUtil.mc.func_175598_ae().field_78734_h.func_174791_d();
        Vec3d entityPos = new Vec3d((double)f, (double)f2, (double)f3);
        Vec3d diffVec = entityPos.func_178788_d(renderPos);
        GlStateManager.func_179137_b((double)diffVec.field_72450_a, (double)diffVec.field_72448_b, (double)diffVec.field_72449_c);
        GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)(-RenderUtil.mc.field_71439_g.field_70177_z), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)RenderUtil.mc.field_71439_g.field_70125_A, (float)(RenderUtil.mc.field_71474_y.field_74320_O == 2 ? -1.0f : 1.0f), (float)0.0f, (float)0.0f);
        GlStateManager.func_179152_a((float)-0.02666667f, (float)-0.02666667f, (float)0.02666667f);
    }

    public static void GLPre(float f) {
        depth = GL11.glIsEnabled((int)2896);
        texture = GL11.glIsEnabled((int)3042);
        clean = GL11.glIsEnabled((int)3553);
        bind = GL11.glIsEnabled((int)2929);
        override = GL11.glIsEnabled((int)2848);
        RenderUtil.GLPre(depth, texture, clean, bind, override, f);
    }

    public static void drawCircleOutline(float f, float f2, float f3, int n, int n2, int n3) {
        RenderUtil.drawArcOutline(f, f2, f3, n, n2, n3);
    }

    public static AxisAlignedBB interpolateAxis(AxisAlignedBB axisAlignedBB) {
        return new AxisAlignedBB(axisAlignedBB.field_72340_a - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c - RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d - RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e - RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f - RenderUtil.mc.func_175598_ae().field_78728_n);
    }

    public static void drawRectangleCorrectly(int n, int n2, int n3, int n4, int n5) {
        GL11.glLineWidth((float)1.0f);
        Gui.func_73734_a((int)n, (int)n2, (int)(n + n3), (int)(n2 + n4), (int)n5);
    }

    public static void checkSetupFBO() {
        Framebuffer framebuffer = mc.func_147110_a();
        if (framebuffer != null && framebuffer.field_147624_h > -1) {
            RenderUtil.setupFBO(framebuffer);
            framebuffer.field_147624_h = -1;
        }
    }

    private static void colorVertex(double d, double d2, double d3, Color color, int n, BufferBuilder bufferBuilder) {
        bufferBuilder.func_181662_b(d - RenderUtil.mc.func_175598_ae().field_78730_l, d2 - RenderUtil.mc.func_175598_ae().field_78731_m, d3 - RenderUtil.mc.func_175598_ae().field_78728_n).func_181669_b(color.getRed(), color.getGreen(), color.getBlue(), n).func_181675_d();
    }

    public static void drawBox(BlockPos blockPos, Color color) {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)blockPos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, (double)blockPos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, (double)blockPos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(blockPos.func_177958_n() + 1) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(blockPos.func_177956_o() + 1) - RenderUtil.mc.func_175598_ae().field_78731_m, (double)(blockPos.func_177952_p() + 1) - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void glrendermethod() {
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)2.0f);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2884);
        GL11.glDisable((int)2929);
        double d = RenderUtil.mc.func_175598_ae().field_78730_l;
        double d2 = RenderUtil.mc.func_175598_ae().field_78731_m;
        double d3 = RenderUtil.mc.func_175598_ae().field_78728_n;
        GL11.glPushMatrix();
        GL11.glTranslated((double)(-d), (double)(-d2), (double)(-d3));
    }

    public static void renderTwo() {
        GL11.glStencilFunc((int)512, (int)0, (int)15);
        GL11.glStencilOp((int)7681, (int)7681, (int)7681);
        GL11.glPolygonMode((int)1032, (int)6914);
    }

    public static Vec3d getInterpolatedPos(Entity entity, float f, boolean bl) {
        Vec3d vec3d = entity.func_174791_d().func_178786_a(entity.field_70169_q, entity.field_70167_r, entity.field_70166_s).func_186678_a((double)f);
        Vec3d vec3d2 = entity.func_174791_d().func_178787_e(vec3d);
        if (bl) {
            return vec3d2.func_178788_d(RenderUtil.mc.func_175598_ae().field_78734_h.func_174791_d());
        }
        return vec3d2;
    }

    public static void drawGradientBlockOutline(BlockPos blockPos, Color color, Color color2, float f, double d) {
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        Vec3d vec3d = EntityUtil.interpolateEntity((Entity)RenderUtil.mc.field_71439_g, mc.func_184121_ak());
        RenderUtil.drawGradientBlockOutline(iBlockState.func_185918_c((World)RenderUtil.mc.field_71441_e, blockPos).func_186662_g((double)0.002f).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c).func_72321_a(0.0, d, 0.0), color, color2, f);
    }

    public static void glEnd() {
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
        GL11.glEnable((int)2929);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
    }

    public static void renderFive() {
        GL11.glPolygonOffset((float)1.0f, (float)2000000.0f);
        GL11.glDisable((int)10754);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2960);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)3008);
        GL11.glPopAttrib();
    }

    public static void drawTracerPointer(float f, float f2, float f3, float f4, float f5, boolean bl, float f6, int n) {
        boolean bl2 = GL11.glIsEnabled((int)3042);
        float f7 = (float)(n >> 24 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glPushMatrix();
        RenderUtil.hexColor(n);
        GL11.glBegin((int)7);
        GL11.glVertex2d((double)f, (double)f2);
        GL11.glVertex2d((double)(f - f3 / f4), (double)(f2 + f3));
        GL11.glVertex2d((double)f, (double)(f2 + f3 / f5));
        GL11.glVertex2d((double)(f + f3 / f4), (double)(f2 + f3));
        GL11.glVertex2d((double)f, (double)f2);
        GL11.glEnd();
        if (bl) {
            GL11.glLineWidth((float)f6);
            GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)f7);
            GL11.glBegin((int)2);
            GL11.glVertex2d((double)f, (double)f2);
            GL11.glVertex2d((double)(f - f3 / f4), (double)(f2 + f3));
            GL11.glVertex2d((double)f, (double)(f2 + f3 / f5));
            GL11.glVertex2d((double)(f + f3 / f4), (double)(f2 + f3));
            GL11.glVertex2d((double)f, (double)f2);
            GL11.glEnd();
        }
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        if (!bl2) {
            GL11.glDisable((int)3042);
        }
        GL11.glDisable((int)2848);
    }

    public static void drawFadingOutline(AxisAlignedBB axisAlignedBB, Color color, Color color2, float f, double d) {
        float f2 = (float)color.getRed() / 255.0f;
        float f3 = (float)color.getGreen() / 255.0f;
        float f4 = (float)color.getBlue() / 255.0f;
        float f5 = (float)color.getAlpha() / 255.0f;
        float f6 = (float)color2.getRed() / 255.0f;
        float f7 = (float)color2.getGreen() / 255.0f;
        float f8 = (float)color2.getBlue() / 255.0f;
        float f9 = (float)color2.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e + d, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void drawBlockOutline(AxisAlignedBB axisAlignedBB, Color color, float f, boolean bl) {
        float f2 = (float)color.getRed() / 255.0f;
        float f3 = (float)color.getGreen() / 255.0f;
        float f4 = (float)color.getBlue() / 255.0f;
        float f5 = (float)color.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        if (bl) {
            GlStateManager.func_179126_j();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)true);
        } else {
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
        }
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    public static void releaseGL3D() {
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179145_e();
        GlStateManager.func_179098_w();
        GL11.glDisable((int)2848);
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179141_d();
        GlStateManager.func_179089_o();
        GlStateManager.func_179126_j();
        GlStateManager.func_179084_k();
        GlStateManager.func_187441_d((float)1.0f);
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.func_179121_F();
    }

    private static void setupFBO(Framebuffer framebuffer) {
        EXTFramebufferObject.glDeleteRenderbuffersEXT((int)framebuffer.field_147624_h);
        int n = EXTFramebufferObject.glGenRenderbuffersEXT();
        EXTFramebufferObject.glBindRenderbufferEXT((int)36161, (int)n);
        EXTFramebufferObject.glRenderbufferStorageEXT((int)36161, (int)34041, (int)RenderUtil.mc.field_71443_c, (int)RenderUtil.mc.field_71440_d);
        EXTFramebufferObject.glFramebufferRenderbufferEXT((int)36160, (int)36128, (int)36161, (int)n);
        EXTFramebufferObject.glFramebufferRenderbufferEXT((int)36160, (int)36096, (int)36161, (int)n);
    }

    public static void renderOne(float f) {
        RenderUtil.checkSetupFBO();
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3008);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glLineWidth((float)f);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2960);
        GL11.glClear((int)1024);
        GL11.glClearStencil((int)15);
        GL11.glStencilFunc((int)512, (int)1, (int)15);
        GL11.glStencilOp((int)7681, (int)7681, (int)7681);
        GL11.glPolygonMode((int)1032, (int)6913);
    }

    public static void drawVGradientRect(float f, float f2, float f3, float f4, int n, int n2) {
        float f5 = (float)(n >> 24 & 0xFF) / 255.0f;
        float f6 = (float)(n >> 16 & 0xFF) / 255.0f;
        float f7 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f8 = (float)(n & 0xFF) / 255.0f;
        float f9 = (float)(n2 >> 24 & 0xFF) / 255.0f;
        float f10 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f11 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f12 = (float)(n2 & 0xFF) / 255.0f;
        GlStateManager.func_179090_x();
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_187428_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.func_179103_j((int)7425);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b((double)f3, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f2, 0.0).func_181666_a(f6, f7, f8, f5).func_181675_d();
        bufferBuilder.func_181662_b((double)f, (double)f4, 0.0).func_181666_a(f10, f11, f12, f9).func_181675_d();
        bufferBuilder.func_181662_b((double)f3, (double)f4, 0.0).func_181666_a(f10, f11, f12, f9).func_181675_d();
        tessellator.func_78381_a();
        GlStateManager.func_179103_j((int)7424);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
    }

    public static void drawFadingOutline(BlockPos blockPos, Color color, Color color2, float f, double d) {
        IBlockState iBlockState = RenderUtil.mc.field_71441_e.func_180495_p(blockPos);
        Vec3d vec3d = RenderUtil.getInterpolatedPos((Entity)RenderUtil.mc.field_71439_g, mc.func_184121_ak(), false);
        RenderUtil.drawFadingOutline(iBlockState.func_185918_c((World)RenderUtil.mc.field_71441_e, blockPos).func_186662_g((double)0.002f).func_72317_d(-vec3d.field_72450_a, -vec3d.field_72448_b, -vec3d.field_72449_c).func_72321_a(0.0, 0.0, 0.0), color, color2, f, d);
    }

    public static void drawTexturedRect(int n, int n2, int n3, int n4, int n5, int n6, int n7) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferBuilder.func_181662_b((double)n, (double)(n2 + n6), (double)n7).func_187315_a((double)((float)n3 * 0.00390625f), (double)((float)(n4 + n6) * 0.00390625f)).func_181675_d();
        bufferBuilder.func_181662_b((double)(n + n5), (double)(n2 + n6), (double)n7).func_187315_a((double)((float)(n3 + n5) * 0.00390625f), (double)((float)(n4 + n6) * 0.00390625f)).func_181675_d();
        bufferBuilder.func_181662_b((double)(n + n5), (double)n2, (double)n7).func_187315_a((double)((float)(n3 + n5) * 0.00390625f), (double)((float)n4 * 0.00390625f)).func_181675_d();
        bufferBuilder.func_181662_b((double)n, (double)n2, (double)n7).func_187315_a((double)((float)n3 * 0.00390625f), (double)((float)n4 * 0.00390625f)).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void drawGradientBlockOutline(AxisAlignedBB axisAlignedBB, Color color, Color color2, float f) {
        float f2 = (float)color.getRed() / 255.0f;
        float f3 = (float)color.getGreen() / 255.0f;
        float f4 = (float)color.getBlue() / 255.0f;
        float f5 = (float)color.getAlpha() / 255.0f;
        float f6 = (float)color2.getRed() / 255.0f;
        float f7 = (float)color2.getGreen() / 255.0f;
        float f8 = (float)color2.getBlue() / 255.0f;
        float f9 = (float)color2.getAlpha() / 255.0f;
        GlStateManager.func_179094_E();
        GlStateManager.func_179147_l();
        GlStateManager.func_179097_i();
        GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)f);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181666_a(f6, f7, f8, f9).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181666_a(f2, f3, f4, f5).func_181675_d();
        tessellator.func_78381_a();
        GL11.glDisable((int)2848);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179126_j();
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179121_F();
    }

    private static void GLPre(boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, float f) {
        if (bl) {
            GL11.glDisable((int)2896);
        }
        if (!bl2) {
            GL11.glEnable((int)3042);
        }
        GL11.glLineWidth((float)f);
        if (bl3) {
            GL11.glDisable((int)3553);
        }
        if (bl4) {
            GL11.glDisable((int)2929);
        }
        if (!bl5) {
            GL11.glEnable((int)2848);
        }
        GlStateManager.func_187401_a((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GL11.glHint((int)3154, (int)4354);
        GlStateManager.func_179132_a((boolean)false);
    }

    public static void drawCircle(float f, float f2, float f3, int n, int n2, int n3) {
        RenderUtil.drawArc(f, f2, f3, n, n2, n3);
    }

    public static void drawSelectionBoundingBox(AxisAlignedBB axisAlignedBB) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        tessellator.func_78381_a();
        bufferBuilder.func_181668_a(1, DefaultVertexFormats.field_181705_e);
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f).func_181675_d();
        bufferBuilder.func_181662_b(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f).func_181675_d();
        tessellator.func_78381_a();
    }

    public static void drawBoxESP(AxisAlignedBB axisAlignedBB, Color color, boolean bl, Color color2, float f, boolean bl2, boolean bl3, int n, boolean bl4) {
        AxisAlignedBB axisAlignedBB2 = axisAlignedBB.func_72317_d(-RenderUtil.mc.func_175598_ae().field_78730_l, -RenderUtil.mc.func_175598_ae().field_78731_m, -RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(axisAlignedBB)) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            if (bl4) {
                GlStateManager.func_179126_j();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)true);
            } else {
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)false);
            }
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLineWidth((float)f);
            if (bl3) {
                RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB2, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)n / 255.0f));
            }
            if (bl2) {
                RenderUtil.drawBlockOutline(axisAlignedBB2, bl ? color2 : color, f, bl4);
            }
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void renderFour(Color color) {
        RenderUtil.setColor(color);
        GL11.glDepthMask((boolean)false);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)10754);
        GL11.glPolygonOffset((float)1.0f, (float)-2000000.0f);
        OpenGlHelper.func_77475_a((int)OpenGlHelper.field_77476_b, (float)240.0f, (float)240.0f);
    }

    public static void drawArcOutline(float f, float f2, float f3, float f4, float f5, int n) {
        GL11.glBegin((int)2);
        int n2 = (int)((float)n / (360.0f / f4)) + 1;
        while ((float)n2 <= (float)n / (360.0f / f5)) {
            double d = Math.PI * 2 * (double)n2 / (double)n;
            GL11.glVertex2d((double)((double)f + Math.cos(d) * (double)f3), (double)((double)f2 + Math.sin(d) * (double)f3));
            ++n2;
        }
        RenderUtil.glEnd();
    }

    private static void doVerticies(AxisAlignedBB axisAlignedBB, Color color, int n, BufferBuilder bufferBuilder, int n2, boolean bl) {
        if ((n2 & 0x20) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            }
        }
        if ((n2 & 0x10) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            }
        }
        if ((n2 & 4) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            }
        }
        if ((n2 & 8) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            }
        }
        if ((n2 & 2) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
            }
        }
        if ((n2 & 1) != 0) {
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
            RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            if (bl) {
                RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
            }
        }
    }

    public static void drawBox(BlockPos blockPos, Color color, double d, boolean bl, boolean bl2, int n) {
        if (bl) {
            Color color2 = new Color(color.getRed(), color.getGreen(), color.getBlue(), n);
            RenderUtil.drawOpenGradientBox(blockPos, bl2 ? color2 : color, bl2 ? color : color2, d);
            return;
        }
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB((double)blockPos.func_177958_n() - RenderUtil.mc.func_175598_ae().field_78730_l, (double)blockPos.func_177956_o() - RenderUtil.mc.func_175598_ae().field_78731_m, (double)blockPos.func_177952_p() - RenderUtil.mc.func_175598_ae().field_78728_n, (double)(blockPos.func_177958_n() + 1) - RenderUtil.mc.func_175598_ae().field_78730_l, (double)(blockPos.func_177956_o() + 1) - RenderUtil.mc.func_175598_ae().field_78731_m + d, (double)(blockPos.func_177952_p() + 1) - RenderUtil.mc.func_175598_ae().field_78728_n);
        camera.func_78547_a(Objects.requireNonNull(RenderUtil.mc.func_175606_aa()).field_70165_t, RenderUtil.mc.func_175606_aa().field_70163_u, RenderUtil.mc.func_175606_aa().field_70161_v);
        if (camera.func_78546_a(new AxisAlignedBB(axisAlignedBB.field_72340_a + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72338_b + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72339_c + RenderUtil.mc.func_175598_ae().field_78728_n, axisAlignedBB.field_72336_d + RenderUtil.mc.func_175598_ae().field_78730_l, axisAlignedBB.field_72337_e + RenderUtil.mc.func_175598_ae().field_78731_m, axisAlignedBB.field_72334_f + RenderUtil.mc.func_175598_ae().field_78728_n))) {
            GlStateManager.func_179094_E();
            GlStateManager.func_179147_l();
            GlStateManager.func_179097_i();
            GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
            GlStateManager.func_179090_x();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glEnable((int)2848);
            GL11.glHint((int)3154, (int)4354);
            RenderGlobal.func_189696_b((AxisAlignedBB)axisAlignedBB, (float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)((float)color.getAlpha() / 255.0f));
            GL11.glDisable((int)2848);
            GlStateManager.func_179132_a((boolean)true);
            GlStateManager.func_179126_j();
            GlStateManager.func_179098_w();
            GlStateManager.func_179084_k();
            GlStateManager.func_179121_F();
        }
    }

    public static void drawCircle(float f, float f2, float f3) {
        RenderUtil.drawCircle(f, f2, f3, 0, 360, 64);
    }

    public static void drawRoundedRectangle(float f, float f2, float f3, float f4, float f5) {
        GL11.glEnable((int)3042);
        RenderUtil.drawArc(f + f3 - f5, f2 + f4 - f5, f5, 0.0f, 90.0f, 16);
        RenderUtil.drawArc(f + f5, f2 + f4 - f5, f5, 90.0f, 180.0f, 16);
        RenderUtil.drawArc(f + f5, f2 + f5, f5, 180.0f, 270.0f, 16);
        RenderUtil.drawArc(f + f3 - f5, f2 + f5, f5, 270.0f, 360.0f, 16);
        GL11.glBegin((int)4);
        GL11.glVertex2d((double)(f + f3 - f5), (double)f2);
        GL11.glVertex2d((double)(f + f5), (double)f2);
        GL11.glVertex2d((double)(f + f3 - f5), (double)(f2 + f5));
        GL11.glVertex2d((double)(f + f3 - f5), (double)(f2 + f5));
        GL11.glVertex2d((double)(f + f5), (double)f2);
        GL11.glVertex2d((double)(f + f5), (double)(f2 + f5));
        GL11.glVertex2d((double)(f + f3), (double)(f2 + f5));
        GL11.glVertex2d((double)f, (double)(f2 + f5));
        GL11.glVertex2d((double)f, (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f3), (double)(f2 + f5));
        GL11.glVertex2d((double)f, (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f3), (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f3 - f5), (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f5), (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f3 - f5), (double)(f2 + f4));
        GL11.glVertex2d((double)(f + f3 - f5), (double)(f2 + f4));
        GL11.glVertex2d((double)(f + f5), (double)(f2 + f4 - f5));
        GL11.glVertex2d((double)(f + f5), (double)(f2 + f4));
        RenderUtil.glEnd();
    }

    public static void hexColor(int n) {
        float f = (float)(n >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(n >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(n & 0xFF) / 255.0f;
        float f4 = (float)(n >> 24 & 0xFF) / 255.0f;
        GL11.glColor4f((float)f, (float)f2, (float)f3, (float)f4);
    }

    public static void drawBoundingBox(AxisAlignedBB axisAlignedBB, double d, Color color, int n) {
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferBuilder = tessellator.func_178180_c();
        GlStateManager.func_187441_d((float)((float)d));
        bufferBuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c, color, color.getAlpha(), bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
        RenderUtil.colorVertex(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c, color, n, bufferBuilder);
        tessellator.func_78381_a();
    }

    public static int rainbowInteger(int max, int min, int now) {
        if (now <= max && now > min) {
            ++now;
        } else if (now >= max) {
            --now;
        }
        return now;
    }

    public static void drawText1(BlockPos pos, String text, int color) {
        GlStateManager.func_179094_E();
        RenderUtil.glBillboardDistanceScaled((float)pos.func_177958_n() + 0.5f, (float)pos.func_177956_o() + 0.5f, (float)pos.func_177952_p() + 0.5f, (EntityPlayer)RenderUtil.mc.field_71439_g, 1.0f);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b((double)(-((double)Client.textManager.getStringWidth(text) / 2.0)), (double)0.0, (double)0.0);
        Client.textManager.drawStringWithShadow(text, 0.0f, 0.0f, color);
        GlStateManager.func_179121_F();
    }

    static {
        $assertionsDisabled = !RenderUtil.class.desiredAssertionStatus();
        itemRender = mc.func_175599_af();
        camera = new Frustum();
        frustrum = new Frustum();
        depth = GL11.glIsEnabled((int)2896);
        texture = GL11.glIsEnabled((int)3042);
        clean = GL11.glIsEnabled((int)3553);
        bind = GL11.glIsEnabled((int)2929);
        override = GL11.glIsEnabled((int)2848);
        screenCoords = BufferUtils.createFloatBuffer((int)3);
        viewport = BufferUtils.createIntBuffer((int)16);
        modelView = BufferUtils.createFloatBuffer((int)16);
        projection = BufferUtils.createFloatBuffer((int)16);
    }
}

