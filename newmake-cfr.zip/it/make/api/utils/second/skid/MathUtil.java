/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 */
package it.make.api.utils.second.skid;

import it.make.api.Wrapper;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class MathUtil
implements Wrapper {
    public static double normalize(double d, double d2, double d3) {
        return (d - d2) / (d3 - d2);
    }

    public static double[] directionSpeed(double d) {
        float f = MathUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float f2 = MathUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float f3 = MathUtil.mc.field_71439_g.field_70126_B + (MathUtil.mc.field_71439_g.field_70177_z - MathUtil.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        double d4 = (double)f * d * d3 + (double)f2 * d * d2;
        double d5 = (double)f * d * d2 - (double)f2 * d * d3;
        return new double[]{d4, d5};
    }

    public static Vec3d calculateLine(Vec3d vec3d, Vec3d vec3d2, double d) {
        double d2 = Math.sqrt(MathUtil.multiply(vec3d2.field_72450_a - vec3d.field_72450_a) + MathUtil.multiply(vec3d2.field_72448_b - vec3d.field_72448_b) + MathUtil.multiply(vec3d2.field_72449_c - vec3d.field_72449_c));
        double d3 = (vec3d2.field_72450_a - vec3d.field_72450_a) / d2;
        double d4 = (vec3d2.field_72448_b - vec3d.field_72448_b) / d2;
        double d5 = (vec3d2.field_72449_c - vec3d.field_72449_c) / d2;
        double d6 = vec3d.field_72450_a + d3 * d;
        double d7 = vec3d.field_72448_b + d4 * d;
        double d8 = vec3d.field_72449_c + d5 * d;
        return new Vec3d(d6, d7, d8);
    }

    public static <K, V extends Comparable<? super V>> LinkedHashMap sortByValue(Map<K, V> map, boolean bl) {
        LinkedList<Map.Entry<K, V>> linkedList = new LinkedList<Map.Entry<K, V>>(map.entrySet());
        if (bl) {
            linkedList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        } else {
            linkedList.sort(Map.Entry.comparingByValue());
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Map.Entry entry : linkedList) {
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }
        return linkedHashMap;
    }

    public static Vec3d direction(float f) {
        return new Vec3d(Math.cos(MathUtil.degToRad(f + 90.0f)), 0.0, Math.sin(MathUtil.degToRad(f + 90.0f)));
    }

    public static int clamp(int n, int n2, int n3) {
        return n < n2 ? n2 : Math.min(n, n3);
    }

    public static Integer increaseNumber(int n, int n2, int n3) {
        if (n < n2) {
            return n + n3;
        }
        return n2;
    }

    public static float[] calcAngle(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d2.field_72450_a - vec3d.field_72450_a;
        double d2 = (vec3d2.field_72448_b - vec3d.field_72448_b) * -1.0;
        double d3 = vec3d2.field_72449_c - vec3d.field_72449_c;
        double d4 = MathHelper.func_76133_a((double)(d * d + d3 * d3));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(d3, d)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(d2, d4)))};
    }

    public static double multiply(double d) {
        return d * d;
    }

    public static String getTimeOfDay() {
        Calendar calendar = Calendar.getInstance();
        int n = calendar.get(11);
        if (n < 12) {
            return "Good Morning ";
        }
        if (n < 16) {
            return "Good Afternoon ";
        }
        if (n < 21) {
            return "Good Evening ";
        }
        return "Good Night ";
    }

    public static List<Vec3d> getBlockBlocks(Entity entity) {
        ArrayList<Vec3d> arrayList = new ArrayList<Vec3d>();
        AxisAlignedBB axisAlignedBB = entity.func_174813_aQ();
        double d = entity.field_70163_u;
        double d2 = MathUtil.round(axisAlignedBB.field_72340_a, 0);
        double d3 = MathUtil.round(axisAlignedBB.field_72339_c, 0);
        double d4 = MathUtil.round(axisAlignedBB.field_72336_d, 0);
        double d5 = MathUtil.round(axisAlignedBB.field_72334_f, 0);
        if (d2 != d4) {
            arrayList.add(new Vec3d(d2, d, d3));
            arrayList.add(new Vec3d(d4, d, d3));
            if (d3 != d5) {
                arrayList.add(new Vec3d(d2, d, d5));
                arrayList.add(new Vec3d(d4, d, d5));
                return arrayList;
            }
        } else if (d3 != d5) {
            arrayList.add(new Vec3d(d2, d, d3));
            arrayList.add(new Vec3d(d2, d, d5));
            return arrayList;
        }
        arrayList.add(entity.func_174791_d());
        return arrayList;
    }

    public static Float decreaseNumber(float f, float f2, float f3) {
        if (f > f2) {
            return Float.valueOf(f - f3);
        }
        return Float.valueOf(f2);
    }

    public static Float increaseNumber(float f, float f2, float f3) {
        if (f < f2) {
            return Float.valueOf(f + f3);
        }
        return Float.valueOf(f2);
    }

    public static float[] calcAngleNoY(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d2.field_72450_a - vec3d.field_72450_a;
        double d2 = vec3d2.field_72449_c - vec3d.field_72449_c;
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(d2, d)) - 90.0))};
    }

    public static Vec3d interpolateEntity(Entity entity, float f) {
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)f, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)f, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)f);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static double animate(double d, double d2, double d3) {
        boolean bl;
        boolean bl2 = false;
        if (!(d > d2)) {
            bl2 = false;
            bl = false;
        } else {
            boolean bl22;
            bl = bl22 = true;
        }
        if (d3 < 0.0) {
            d3 = 0.0;
        } else if (d3 > 1.0) {
            d3 = 1.0;
        }
        double d4 = Math.max(d, d2) - Math.min(d, d2);
        double d5 = d4 * d3;
        if (d5 < 0.1) {
            d5 = 0.1;
        }
        return bl2 ? d2 + d5 : d2 - d5;
    }

    public static Vec3d roundVec(Vec3d vec3d, int n) {
        return new Vec3d(MathUtil.round(vec3d.field_72450_a, n), MathUtil.round(vec3d.field_72448_b, n), MathUtil.round(vec3d.field_72449_c, n));
    }

    public static float wrap(float f) {
        float f2 = f % 360.0f;
        if (f2 >= 180.0f) {
            f2 -= 360.0f;
        }
        if (f2 < -180.0f) {
            f2 += 360.0f;
        }
        return f2;
    }

    public static double round(double d, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bigDecimal = BigDecimal.valueOf(d);
        bigDecimal = bigDecimal.setScale(n, RoundingMode.FLOOR);
        return bigDecimal.doubleValue();
    }

    public static Vec3d[] convertVectors(Vec3d vec3d, Vec3d[] vec3dArray) {
        Vec3d[] vec3dArray2 = new Vec3d[vec3dArray.length];
        for (int i = 0; i < vec3dArray.length; ++i) {
            vec3dArray2[i] = vec3d.func_178787_e(vec3dArray[i]);
        }
        return vec3dArray2;
    }

    public static double square(double d) {
        return d * d;
    }

    public static float animate(float f, float f2, float f3) {
        float f4 = (f2 - f) / Math.max((float)Minecraft.func_175610_ah(), 5.0f) * 15.0f;
        if (f4 > 0.0f) {
            f4 = Math.max(f3, f4);
            f4 = Math.min(f2 - f, f4);
        } else if (f4 < 0.0f) {
            f4 = Math.min(-f3, f4);
            f4 = Math.max(f2 - f, f4);
        }
        return f + f4;
    }

    public static float getInterpolatedFloat(float f, float f2, float f3) {
        return f + (f2 - f) * f3;
    }

    public static float round(float f, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bigDecimal = BigDecimal.valueOf(f);
        bigDecimal = bigDecimal.setScale(n, RoundingMode.FLOOR);
        return bigDecimal.floatValue();
    }

    public static float clamp(float f, float f2, float f3) {
        return f < f2 ? f2 : Math.min(f, f3);
    }

    public static Vec3d extrapolatePlayerPosition(EntityPlayer entityPlayer, int n) {
        Vec3d vec3d = new Vec3d(entityPlayer.field_70142_S, entityPlayer.field_70137_T, entityPlayer.field_70136_U);
        Vec3d vec3d2 = new Vec3d(entityPlayer.field_70165_t, entityPlayer.field_70163_u, entityPlayer.field_70161_v);
        double d = MathUtil.multiply(entityPlayer.field_70159_w) + MathUtil.multiply(entityPlayer.field_70181_x) + MathUtil.multiply(entityPlayer.field_70179_y);
        Vec3d vec3d3 = MathUtil.calculateLine(vec3d, vec3d2, d * (double)n);
        return new Vec3d(vec3d3.field_72450_a, entityPlayer.field_70163_u, vec3d3.field_72449_c);
    }

    public static Integer decreaseNumber(int n, int n2, int n3) {
        if (n > n2) {
            return n - n3;
        }
        return n2;
    }

    public static double degToRad(double d) {
        return d * 0.01745329238474369;
    }
}

