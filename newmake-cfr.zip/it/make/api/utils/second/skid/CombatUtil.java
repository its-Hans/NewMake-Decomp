/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.client.Minecraft
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.init.MobEffects
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.util.CombatRules
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.World
 */
package it.make.api.utils.second.skid;

import it.make.Client;
import it.make.modules.render.PlaceRender;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class CombatUtil {
    public static final List<Block> blackList = Arrays.asList(Blocks.field_150329_H, Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z, Blocks.field_150415_aT);
    public static final List<Block> shulkerList = Arrays.asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
    private static Minecraft mc = Minecraft.func_71410_x();
    public static final Vec3d[] cityOffsets = new Vec3d[]{new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 2.0), new Vec3d(-2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -2.0)};
    private static final List<Integer> invalidSlots = Arrays.asList(0, 5, 6, 7, 8);

    public static int findCrapple() {
        if (CombatUtil.mc.field_71439_g == null) {
            return -1;
        }
        for (int x = 0; x < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++x) {
            ItemStack stack;
            if (invalidSlots.contains(x) || (stack = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(x)).func_190926_b() || !stack.func_77973_b().equals(Items.field_151153_ao) || stack.func_77952_i() == 1) continue;
            return x;
        }
        return -1;
    }

    public static int findItemSlotDamage1(Item i) {
        if (CombatUtil.mc.field_71439_g == null) {
            return -1;
        }
        for (int x = 0; x < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++x) {
            ItemStack stack;
            if (invalidSlots.contains(x) || (stack = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(x)).func_190926_b() || !stack.func_77973_b().equals(i) || stack.func_77952_i() != 1) continue;
            return x;
        }
        return -1;
    }

    public static int findItemSlot(Item i) {
        if (CombatUtil.mc.field_71439_g == null) {
            return -1;
        }
        for (int x = 0; x < CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().size(); ++x) {
            ItemStack stack;
            if (invalidSlots.contains(x) || (stack = (ItemStack)CombatUtil.mc.field_71439_g.field_71069_bz.func_75138_a().get(x)).func_190926_b() || !stack.func_77973_b().equals(i)) continue;
            return x;
        }
        return -1;
    }

    public static boolean isHoldingCrystal(boolean onlyMainHand) {
        if (onlyMainHand) {
            return CombatUtil.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP;
        }
        return CombatUtil.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP || CombatUtil.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP;
    }

    public static boolean requiredDangerSwitch(double dangerRange) {
        int dangerousCrystals = (int)CombatUtil.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity instanceof EntityEnderCrystal).filter(entity -> (double)CombatUtil.mc.field_71439_g.func_70032_d(entity) <= dangerRange).filter(entity -> CombatUtil.calculateDamage(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, (Entity)CombatUtil.mc.field_71439_g) >= CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj()).count();
        return dangerousCrystals > 0;
    }

    public static boolean passesOffhandCheck(double requiredHealth, Item item, boolean isCrapple) {
        double totalPlayerHealth = CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        if (!isCrapple ? CombatUtil.findItemSlot(item) == -1 : CombatUtil.findCrapple() == -1) {
            return false;
        }
        return !(totalPlayerHealth < requiredHealth);
    }

    public static void switchOffhandStrict(int targetSlot, int step) {
        switch (step) {
            case 0: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                break;
            }
            case 1: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, 45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                break;
            }
            case 2: {
                CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
                CombatUtil.mc.field_71442_b.func_78765_e();
            }
        }
    }

    public static void switchOffhandTotemNotStrict() {
        int targetSlot = CombatUtil.findItemSlot(Items.field_190929_cY);
        if (targetSlot != -1) {
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, 45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
            CombatUtil.mc.field_71442_b.func_78765_e();
        }
    }

    public static void switchOffhandNonStrict(int targetSlot) {
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, 45, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_187098_a(CombatUtil.mc.field_71439_g.field_71069_bz.field_75152_c, targetSlot, 0, ClickType.PICKUP, (EntityPlayer)CombatUtil.mc.field_71439_g);
        CombatUtil.mc.field_71442_b.func_78765_e();
    }

    public static boolean canSeeBlock(BlockPos pos) {
        return CombatUtil.mc.field_71441_e.func_147447_a(new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + (double)CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n(), (double)((float)pos.func_177956_o() + 1.0f), (double)pos.func_177952_p()), false, true, false) == null;
    }

    public static boolean placeBlock(BlockPos blockPos, boolean offhand, boolean rotate, boolean packetRotate, boolean doSwitch, boolean silentSwitch, int toSwitch) {
        if (!CombatUtil.checkCanPlace(blockPos)) {
            return false;
        }
        EnumFacing placeSide = CombatUtil.getPlaceSide(blockPos);
        BlockPos adjacentBlock = blockPos.func_177972_a(placeSide);
        EnumFacing opposingSide = placeSide.func_176734_d();
        if (!CombatUtil.mc.field_71441_e.func_180495_p(adjacentBlock).func_177230_c().func_176209_a(CombatUtil.mc.field_71441_e.func_180495_p(adjacentBlock), false)) {
            return false;
        }
        if (doSwitch) {
            if (silentSwitch) {
                CombatUtil.mc.field_71439_g.field_71071_by.field_70461_c = toSwitch;
                CombatUtil.mc.field_71442_b.func_78765_e();
            } else if (CombatUtil.mc.field_71439_g.field_71071_by.field_70461_c != toSwitch) {
                CombatUtil.mc.field_71439_g.field_71071_by.field_70461_c = toSwitch;
            }
        }
        boolean isSneak = false;
        if (blackList.contains(CombatUtil.mc.field_71441_e.func_180495_p(adjacentBlock).func_177230_c()) || shulkerList.contains(CombatUtil.mc.field_71441_e.func_180495_p(adjacentBlock).func_177230_c())) {
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)CombatUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            isSneak = true;
        }
        Vec3d hitVector = CombatUtil.getHitVector(adjacentBlock, opposingSide);
        if (rotate) {
            float[] angle = CombatUtil.getLegitRotations(hitVector);
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(angle[0], angle[1], CombatUtil.mc.field_71439_g.field_70122_E));
        }
        EnumHand actionHand = offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
        CombatUtil.mc.field_71442_b.func_187099_a(CombatUtil.mc.field_71439_g, CombatUtil.mc.field_71441_e, adjacentBlock, opposingSide, hitVector, actionHand);
        CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(actionHand));
        PlaceRender.putMap(blockPos);
        if (isSneak) {
            CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)CombatUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        }
        return true;
    }

    private static Vec3d getHitVector(BlockPos pos, EnumFacing opposingSide) {
        return new Vec3d((Vec3i)pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(opposingSide.func_176730_m()).func_186678_a(0.5));
    }

    public static Vec3d getHitAddition(double x, double y, double z, BlockPos pos, EnumFacing opposingSide) {
        return new Vec3d((Vec3i)pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(opposingSide.func_176730_m()).func_186678_a(0.5));
    }

    public static void betterRotate(BlockPos blockPos, EnumFacing opposite, boolean packetRotate) {
        float offsetZ = 0.0f;
        float offsetY = 0.0f;
        float offsetX = 0.0f;
        switch (CombatUtil.getPlaceSide(blockPos)) {
            case UP: {
                offsetZ = 0.5f;
                offsetX = 0.5f;
                offsetY = 0.0f;
                break;
            }
            case DOWN: {
                offsetZ = 0.5f;
                offsetX = 0.5f;
                offsetY = -0.5f;
                break;
            }
            case NORTH: {
                offsetX = 0.5f;
                offsetY = -0.5f;
                offsetZ = -0.5f;
                break;
            }
            case EAST: {
                offsetX = 0.5f;
                offsetY = -0.5f;
                offsetZ = 0.5f;
                break;
            }
            case SOUTH: {
                offsetX = 0.5f;
                offsetY = -0.5f;
                offsetZ = 0.5f;
                break;
            }
            case WEST: {
                offsetX = -0.5f;
                offsetY = -0.5f;
                offsetZ = 0.5f;
            }
        }
        float[] angle = CombatUtil.getLegitRotations(CombatUtil.getHitAddition(offsetX, offsetY, offsetZ, blockPos, opposite));
        CombatUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(angle[0], angle[1], CombatUtil.mc.field_71439_g.field_70122_E));
    }

    private static EnumFacing getPlaceSide(BlockPos blockPos) {
        EnumFacing placeableSide = null;
        for (EnumFacing side : EnumFacing.values()) {
            BlockPos adjacent = blockPos.func_177972_a(side);
            if (!CombatUtil.mc.field_71441_e.func_180495_p(adjacent).func_177230_c().func_176209_a(CombatUtil.mc.field_71441_e.func_180495_p(adjacent), false) || CombatUtil.mc.field_71441_e.func_180495_p(adjacent).func_185904_a().func_76222_j()) continue;
            placeableSide = side;
        }
        return placeableSide;
    }

    public static boolean checkCanPlace(BlockPos pos) {
        if (!(CombatUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockAir) && !(CombatUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof BlockLiquid)) {
            return false;
        }
        for (Entity entity : CombatUtil.mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(pos))) {
            if (entity instanceof EntityItem || entity instanceof EntityXPOrb || entity instanceof EntityArrow) continue;
            return false;
        }
        return CombatUtil.getPlaceSide(pos) != null;
    }

    public static boolean isInCity(EntityPlayer player, double range, double placeRange, boolean checkFace, boolean topBlock, boolean checkPlace, boolean checkRange) {
        BlockPos pos = new BlockPos(player.func_174791_d());
        for (EnumFacing face : EnumFacing.values()) {
            if (face == EnumFacing.UP || face == EnumFacing.DOWN) continue;
            BlockPos pos1 = pos.func_177972_a(face);
            BlockPos pos2 = pos1.func_177972_a(face);
            if (!(CombatUtil.mc.field_71441_e.func_180495_p(pos1).func_177230_c() == Blocks.field_150350_a && (CombatUtil.mc.field_71441_e.func_180495_p(pos2).func_177230_c() == Blocks.field_150350_a && CombatUtil.isHard(CombatUtil.mc.field_71441_e.func_180495_p(pos2.func_177984_a()).func_177230_c()) || !checkFace) && !checkRange || CombatUtil.mc.field_71439_g.func_174818_b(pos2) <= placeRange * placeRange && CombatUtil.mc.field_71439_g.func_70068_e((Entity)player) <= range * range && CombatUtil.isHard(CombatUtil.mc.field_71441_e.func_180495_p(pos.func_177981_b(3)).func_177230_c())) && topBlock) continue;
            return true;
        }
        return false;
    }

    public static boolean isHard(Block block) {
        return block == Blocks.field_150343_Z || block == Blocks.field_150357_h;
    }

    public static int getSafetyFactor(BlockPos pos) {
        return 0;
    }

    public static boolean canPlaceCrystal(BlockPos pos, double range, double wallsRange, boolean raytraceCheck) {
        BlockPos up = pos.func_177984_a();
        BlockPos up1 = up.func_177984_a();
        AxisAlignedBB bb = new AxisAlignedBB(up).func_72321_a(0.0, 1.0, 0.0);
        return (CombatUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150343_Z || CombatUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150357_h) && CombatUtil.mc.field_71441_e.func_180495_p(up).func_177230_c() == Blocks.field_150350_a && CombatUtil.mc.field_71441_e.func_180495_p(up1).func_177230_c() == Blocks.field_150350_a && CombatUtil.mc.field_71441_e.func_72872_a(Entity.class, bb).isEmpty() && CombatUtil.mc.field_71439_g.func_174818_b(pos) <= range * range && !raytraceCheck || CombatUtil.rayTraceRangeCheck(pos, wallsRange, 0.0);
    }

    public static int getVulnerability(EntityPlayer player, double range, double placeRange, double wallsRange, double maxSelfDamage, double maxFriendDamage, double minDamage, double friendRange, double facePlaceHP, int minArmor, boolean cityCheck, boolean rayTrace, boolean lowArmorCheck, boolean antiSuicide, boolean antiFriendPop) {
        if (CombatUtil.isInCity(player, range, placeRange, true, true, true, false) && cityCheck) {
            return 5;
        }
        if (CombatUtil.getClosestValidPos(player, maxSelfDamage, maxFriendDamage, minDamage, placeRange, wallsRange, friendRange, rayTrace, antiSuicide, antiFriendPop, true) != null) {
            return 4;
        }
        if ((double)(player.func_110143_aJ() + player.func_110139_bj()) <= facePlaceHP) {
            return 3;
        }
        if (CombatUtil.isArmorLow(player, minArmor, true) && lowArmorCheck) {
            return 2;
        }
        return 0;
    }

    public static Map<BlockPos, Double> mapBlockDamage(EntityPlayer player, double maxSelfDamage, double maxFriendDamage, double minDamage, double placeRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop) {
        HashMap<BlockPos, Double> damageMap = new HashMap<BlockPos, Double>();
        for (BlockPos pos : CombatUtil.getSphere(new BlockPos((Vec3i)CombatUtil.getFlooredPosition((Entity)CombatUtil.mc.field_71439_g)), (float)placeRange, (int)placeRange, false, true, 0)) {
            double damage;
            if (!CombatUtil.canPlaceCrystal(pos, placeRange, wallsRange, rayTrace) || !CombatUtil.checkFriends(pos, maxFriendDamage, friendRange, antiFriendPop) || !CombatUtil.checkSelf(pos, maxSelfDamage, antiSuicide) || rayTrace && !CombatUtil.rayTraceRangeCheck(pos, wallsRange, 0.0) || (damage = (double)CombatUtil.calculateDamage(pos, (Entity)player)) < minDamage) continue;
            damageMap.put(pos, damage);
        }
        return damageMap;
    }

    public static boolean checkFriends(BlockPos pos, double maxFriendDamage, double friendRange, boolean antiFriendPop) {
        for (EntityPlayer player : CombatUtil.mc.field_71441_e.field_73010_i) {
            if (CombatUtil.mc.field_71439_g.func_70068_e((Entity)player) > friendRange * friendRange) continue;
            if ((double)CombatUtil.calculateDamage(pos, (Entity)player) > maxFriendDamage) {
                return false;
            }
            if (!(CombatUtil.calculateDamage(pos, (Entity)player) > player.func_110143_aJ() + player.func_110139_bj()) || !antiFriendPop) continue;
            return false;
        }
        return true;
    }

    public static boolean checkFriends(EntityEnderCrystal crystal, double maxFriendDamage, double friendRange, boolean antiFriendPop) {
        for (EntityPlayer player : CombatUtil.mc.field_71441_e.field_73010_i) {
            if (CombatUtil.mc.field_71439_g.func_70068_e((Entity)player) > friendRange * friendRange) continue;
            if ((double)CombatUtil.calculateDamage((Entity)crystal, (Entity)player) > maxFriendDamage) {
                return false;
            }
            if (!(CombatUtil.calculateDamage((Entity)crystal, (Entity)player) > player.func_110143_aJ() + player.func_110139_bj()) || !antiFriendPop) continue;
            return false;
        }
        return true;
    }

    public static boolean checkSelf(BlockPos pos, double maxSelfDamage, boolean antiSuicide) {
        boolean willPopSelf = CombatUtil.calculateDamage(pos, (Entity)CombatUtil.mc.field_71439_g) > CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        boolean willDamageSelf = (double)CombatUtil.calculateDamage(pos, (Entity)CombatUtil.mc.field_71439_g) > maxSelfDamage;
        return (!antiSuicide || !willPopSelf) && !willDamageSelf;
    }

    public static boolean checkSelf(EntityEnderCrystal crystal, double maxSelfDamage, boolean antiSuicide) {
        boolean willPopSelf = CombatUtil.calculateDamage((Entity)crystal, (Entity)CombatUtil.mc.field_71439_g) > CombatUtil.mc.field_71439_g.func_110143_aJ() + CombatUtil.mc.field_71439_g.func_110139_bj();
        boolean willDamageSelf = (double)CombatUtil.calculateDamage((Entity)crystal, (Entity)CombatUtil.mc.field_71439_g) > maxSelfDamage;
        return (!antiSuicide || !willPopSelf) && !willDamageSelf;
    }

    public static boolean isPosValid(EntityPlayer player, BlockPos pos, double maxSelfDamage, double maxFriendDamage, double minDamage, double placeRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop) {
        if (pos == null) {
            return false;
        }
        if (!CombatUtil.isHard(CombatUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c())) {
            return false;
        }
        if (!CombatUtil.canPlaceCrystal(pos, placeRange, wallsRange, rayTrace)) {
            return false;
        }
        if (!CombatUtil.checkFriends(pos, maxFriendDamage, friendRange, antiFriendPop)) {
            return false;
        }
        if (!CombatUtil.checkSelf(pos, maxSelfDamage, antiSuicide)) {
            return false;
        }
        double damage = CombatUtil.calculateDamage(pos, (Entity)player);
        if (damage < minDamage) {
            return false;
        }
        return !rayTrace || CombatUtil.rayTraceRangeCheck(pos, wallsRange, 0.0);
    }

    public static BlockPos getClosestValidPos(EntityPlayer player, double maxSelfDamage, double maxFriendDamage, double minDamage, double placeRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop, boolean multiplace) {
        double highestDamage = -1.0;
        BlockPos finalPos = null;
        if (player == null) {
            return null;
        }
        List<BlockPos> placeLocations = CombatUtil.getSphere(new BlockPos((Vec3i)CombatUtil.getFlooredPosition((Entity)CombatUtil.mc.field_71439_g)), (float)placeRange, (int)placeRange, false, true, 0);
        placeLocations.sort(Comparator.comparing(blockPos -> CombatUtil.mc.field_71439_g.func_174818_b(blockPos)));
        for (BlockPos pos : placeLocations) {
            double damage;
            if (!CombatUtil.canPlaceCrystal(pos, placeRange, wallsRange, rayTrace) || rayTrace && !CombatUtil.rayTraceRangeCheck(pos, wallsRange, 0.0) || (damage = (double)CombatUtil.calculateDamage(pos, (Entity)player)) < minDamage || !CombatUtil.checkFriends(pos, maxFriendDamage, friendRange, antiFriendPop) || !CombatUtil.checkSelf(pos, maxSelfDamage, antiSuicide)) continue;
            if (damage > 15.0) {
                return pos;
            }
            if (!(damage > highestDamage)) continue;
            highestDamage = damage;
            finalPos = pos;
        }
        return finalPos;
    }

    public static BlockPos getClosestValidPosMultiThread(EntityPlayer player, double maxSelfDamage, double maxFriendDamage, double minDamage, double placeRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop) {
        CopyOnWriteArrayList<ValidPosThread> threads = new CopyOnWriteArrayList<ValidPosThread>();
        BlockPos finalPos = null;
        for (BlockPos pos : CombatUtil.getSphere(new BlockPos(player.func_174791_d()), 13.0f, 13, false, true, 0)) {
            ValidPosThread thread3 = new ValidPosThread(player, pos, maxSelfDamage, maxFriendDamage, minDamage, placeRange, wallsRange, friendRange, rayTrace, antiSuicide, antiFriendPop);
            threads.add(thread3);
            thread3.start();
        }
        boolean areAllInvalid = false;
        do {
            for (ValidPosThread thread3 : threads) {
                if (!thread3.isInterrupted() || !thread3.isValid) continue;
                finalPos = thread3.pos;
            }
            areAllInvalid = threads.stream().noneMatch(thread2 -> thread2.isValid && thread2.isInterrupted());
        } while (finalPos == null && !areAllInvalid);
        Client.LOGGER.info(finalPos == null ? "pos was null" : finalPos.toString());
        return finalPos;
    }

    public static List<BlockPos> getSphere(BlockPos pos, float r, int h, boolean hollow, boolean sphere, int plus_y) {
        ArrayList<BlockPos> circleblocks = new ArrayList<BlockPos>();
        int cx = pos.func_177958_n();
        int cy = pos.func_177956_o();
        int cz = pos.func_177952_p();
        int x = cx - (int)r;
        while ((float)x <= (float)cx + r) {
            int z = cz - (int)r;
            while ((float)z <= (float)cz + r) {
                int y = sphere ? cy - (int)r : cy;
                while (true) {
                    float f = y;
                    float f2 = sphere ? (float)cy + r : (float)(cy + h);
                    if (!(f < f2)) break;
                    double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0);
                    if (!(!(dist < (double)(r * r)) || hollow && dist < (double)((r - 1.0f) * (r - 1.0f)))) {
                        BlockPos l = new BlockPos(x, y + plus_y, z);
                        circleblocks.add(l);
                    }
                    ++y;
                }
                ++z;
            }
            ++x;
        }
        return circleblocks;
    }

    public static boolean isArmorLow(EntityPlayer player, int durability, boolean checkDurability) {
        for (ItemStack piece : player.field_71071_by.field_70460_b) {
            if (piece == null) {
                return true;
            }
            if (!checkDurability || CombatUtil.getItemDamage(piece) >= durability) continue;
            return true;
        }
        return false;
    }

    public static int getItemDamage(ItemStack stack) {
        return stack.func_77958_k() - stack.func_77952_i();
    }

    public static boolean rayTraceRangeCheck(Entity target, double range) {
        boolean isVisible = CombatUtil.mc.field_71439_g.func_70685_l(target);
        return !isVisible || CombatUtil.mc.field_71439_g.func_70068_e(target) <= range * range;
    }

    public static boolean rayTraceRangeCheck(BlockPos pos, double range, double height) {
        RayTraceResult result = CombatUtil.mc.field_71441_e.func_147447_a(new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + (double)CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v), new Vec3d((double)pos.func_177958_n(), (double)pos.func_177956_o() + height, (double)pos.func_177952_p()), false, true, false);
        return result == null || CombatUtil.mc.field_71439_g.func_174818_b(pos) <= range * range;
    }

    public static EntityEnderCrystal getClosestValidCrystal(EntityPlayer player, double maxSelfDamage, double maxFriendDamage, double minDamage, double breakRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop) {
        if (player == null) {
            return null;
        }
        List crystals = CombatUtil.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity instanceof EntityEnderCrystal).filter(entity -> CombatUtil.mc.field_71439_g.func_70068_e(entity) <= breakRange * breakRange).sorted(Comparator.comparingDouble(entity -> CombatUtil.mc.field_71439_g.func_70068_e(entity))).map(entity -> (EntityEnderCrystal)entity).collect(Collectors.toList());
        for (EntityEnderCrystal crystal : crystals) {
            if (rayTrace && !CombatUtil.rayTraceRangeCheck((Entity)crystal, wallsRange) || (double)CombatUtil.calculateDamage((Entity)crystal, (Entity)player) < minDamage || !CombatUtil.checkSelf(crystal, maxSelfDamage, antiSuicide) || !CombatUtil.checkFriends(crystal, maxFriendDamage, friendRange, antiFriendPop)) continue;
            return crystal;
        }
        return null;
    }

    public static List<BlockPos> getDisc(BlockPos pos, float r) {
        ArrayList<BlockPos> circleblocks = new ArrayList<BlockPos>();
        int cx = pos.func_177958_n();
        int cy = pos.func_177956_o();
        int cz = pos.func_177952_p();
        int x = cx - (int)r;
        while ((float)x <= (float)cx + r) {
            int z = cz - (int)r;
            while ((float)z <= (float)cz + r) {
                double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z);
                if (dist < (double)(r * r)) {
                    BlockPos position = new BlockPos(x, cy, z);
                    circleblocks.add(position);
                }
                ++z;
            }
            ++x;
        }
        return circleblocks;
    }

    public static BlockPos getFlooredPosition(Entity entity) {
        return new BlockPos(Math.floor(entity.field_70165_t), Math.floor(entity.field_70163_u), Math.floor(entity.field_70161_v));
    }

    public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
        float doubleExplosionSize = 12.0f;
        double distancedsize = entity.func_70011_f(posX, posY, posZ) / (double)doubleExplosionSize;
        Vec3d vec3d = new Vec3d(posX, posY, posZ);
        double blockDensity = 0.0;
        try {
            blockDensity = entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
        }
        catch (Exception exception) {
            // empty catch block
        }
        double v = (1.0 - distancedsize) * blockDensity;
        float damage = (int)((v * v + v) / 2.0 * 7.0 * (double)doubleExplosionSize + 1.0);
        double finald = 1.0;
        if (entity instanceof EntityLivingBase) {
            finald = CombatUtil.getBlastReduction((EntityLivingBase)entity, CombatUtil.getDamageMultiplied(damage), new Explosion((World)Minecraft.func_71410_x().field_71441_e, null, posX, posY, posZ, 6.0f, false, true));
        }
        return (float)finald;
    }

    public static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
        float damage = damageI;
        if (entity instanceof EntityPlayer) {
            EntityPlayer ep = (EntityPlayer)entity;
            DamageSource ds = DamageSource.func_94539_a((Explosion)explosion);
            damage = CombatRules.func_189427_a((float)damage, (float)ep.func_70658_aO(), (float)((float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
            int k = 0;
            try {
                k = EnchantmentHelper.func_77508_a((Iterable)ep.func_184193_aE(), (DamageSource)ds);
            }
            catch (Exception exception) {
                // empty catch block
            }
            float f = MathHelper.func_76131_a((float)k, (float)0.0f, (float)20.0f);
            damage *= 1.0f - f / 25.0f;
            if (entity.func_70644_a(MobEffects.field_76429_m)) {
                damage -= damage / 4.0f;
            }
            damage = Math.max(damage, 0.0f);
            return damage;
        }
        damage = CombatRules.func_189427_a((float)damage, (float)entity.func_70658_aO(), (float)((float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
        return damage;
    }

    public static float getDamageMultiplied(float damage) {
        int diff = Minecraft.func_71410_x().field_71441_e.func_175659_aa().func_151525_a();
        return damage * (diff == 0 ? 0.0f : (diff == 2 ? 1.0f : (diff == 1 ? 0.5f : 1.5f)));
    }

    public static float calculateDamage(Entity crystal, Entity entity) {
        return CombatUtil.calculateDamage(crystal.field_70165_t, crystal.field_70163_u, crystal.field_70161_v, entity);
    }

    public static float calculateDamage(BlockPos pos, Entity entity) {
        return CombatUtil.calculateDamage((double)pos.func_177958_n() + 0.5, pos.func_177956_o() + 1, (double)pos.func_177952_p() + 0.5, entity);
    }

    public static Vec3d interpolateEntity(Entity entity) {
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)mc.func_184121_ak(), entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)mc.func_184121_ak(), entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)mc.func_184121_ak());
    }

    public static float[] calcAngle(Vec3d from, Vec3d to) {
        double difX = to.field_72450_a - from.field_72450_a;
        double difY = (to.field_72448_b - from.field_72448_b) * -1.0;
        double difZ = to.field_72449_c - from.field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static float[] getLegitRotations(Vec3d vec) {
        Vec3d eyesPos = new Vec3d(CombatUtil.mc.field_71439_g.field_70165_t, CombatUtil.mc.field_71439_g.field_70163_u + (double)CombatUtil.mc.field_71439_g.func_70047_e(), CombatUtil.mc.field_71439_g.field_70161_v);
        double diffX = vec.field_72450_a - eyesPos.field_72450_a;
        double diffY = vec.field_72448_b - eyesPos.field_72448_b;
        double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{CombatUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(yaw - CombatUtil.mc.field_71439_g.field_70177_z)), CombatUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(pitch - CombatUtil.mc.field_71439_g.field_70125_A))};
    }

    public static class CombatPosInfo {
        public EntityPlayer player;
        public BlockPos pos;
        public float damage;

        public CombatPosInfo(EntityPlayer player, BlockPos pos, float damage) {
            this.pos = pos;
            this.damage = damage;
            this.player = player;
        }
    }

    public static class ValidPosThread
    extends Thread {
        BlockPos pos;
        EntityPlayer player;
        double maxSelfDamage;
        double maxFriendDamage;
        double minDamage;
        double placeRange;
        double wallsRange;
        double friendRange;
        boolean rayTrace;
        boolean antiSuicide;
        boolean antiFriendPop;
        public float damage;
        public boolean isValid;
        public CombatPosInfo info;

        public ValidPosThread(EntityPlayer player, BlockPos pos, double maxSelfDamage, double maxFriendDamage, double minDamage, double placeRange, double wallsRange, double friendRange, boolean rayTrace, boolean antiSuicide, boolean antiFriendPop) {
            super("Break");
            this.pos = pos;
            this.maxSelfDamage = maxSelfDamage;
            this.maxFriendDamage = maxFriendDamage;
            this.minDamage = minDamage;
            this.placeRange = placeRange;
            this.wallsRange = wallsRange;
            this.friendRange = friendRange;
            this.rayTrace = rayTrace;
            this.antiSuicide = antiSuicide;
            this.antiFriendPop = antiFriendPop;
            this.player = player;
        }

        @Override
        public void run() {
            if (!(mc.field_71439_g.func_174818_b(this.pos) > this.placeRange * this.placeRange) && CombatUtil.canPlaceCrystal(this.pos, this.placeRange, this.wallsRange, this.rayTrace) && CombatUtil.checkFriends(this.pos, this.maxFriendDamage, this.friendRange, this.antiFriendPop) && CombatUtil.checkSelf(this.pos, this.maxSelfDamage, this.antiSuicide)) {
                this.damage = CombatUtil.calculateDamage(this.pos, (Entity)this.player);
                if ((double)this.damage >= this.minDamage && (!this.rayTrace || CombatUtil.rayTraceRangeCheck(this.pos, this.wallsRange, 0.0))) {
                    this.isValid = true;
                    this.info = new CombatPosInfo(this.player, this.pos, this.damage);
                    Client.LOGGER.info("Pos was valid.");
                    return;
                }
            }
            this.isValid = false;
            this.info = new CombatPosInfo(this.player, this.pos, -1.0f);
            Client.LOGGER.info("Pos was invalid.");
        }
    }
}

