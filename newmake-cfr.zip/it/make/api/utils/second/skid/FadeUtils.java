/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.utils.second.skid;

public class FadeUtils {
    protected long start;
    protected long length;

    public FadeUtils(long length) {
        this.length = length;
        this.reset();
    }

    public void reset() {
        this.start = System.currentTimeMillis();
    }

    private double getFadeOne() {
        return this.isEnd() ? 1.0 : (double)this.getTime() / (double)this.length;
    }

    public double easeOutQuad() {
        return this.length == 0L ? 1.0 : 1.0 - (1.0 - this.getFadeOne()) * (1.0 - this.getFadeOne());
    }

    public boolean isEnd() {
        return this.getTime() >= this.length;
    }

    public void setLength(long length) {
        this.length = length;
    }

    public double easeInQuad() {
        return this.getFadeOne() * this.getFadeOne();
    }

    protected long getTime() {
        return System.currentTimeMillis() - this.start;
    }
}

