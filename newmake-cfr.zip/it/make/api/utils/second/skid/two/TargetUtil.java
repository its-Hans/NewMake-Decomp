/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 */
package it.make.api.utils.second.skid.two;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;

public class TargetUtil {
    Minecraft mc = Minecraft.func_71410_x();

    public static byte getArmorPieces(EntityPlayer target) {
        byte i = 0;
        if (target.field_71069_bz.func_75139_a(5).func_75211_c().func_77973_b().equals(Items.field_151161_ac)) {
            i = (byte)(i + 1);
        }
        if (target.field_71069_bz.func_75139_a(6).func_75211_c().func_77973_b().equals(Items.field_151163_ad)) {
            i = (byte)(i + 1);
        }
        if (target.field_71069_bz.func_75139_a(7).func_75211_c().func_77973_b().equals(Items.field_151173_ae)) {
            i = (byte)(i + 1);
        }
        if (target.field_71069_bz.func_75139_a(8).func_75211_c().func_77973_b().equals(Items.field_151175_af)) {
            i = (byte)(i + 1);
        }
        return i;
    }
}

