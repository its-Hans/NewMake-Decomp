/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  net.minecraft.block.Block
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.entity.projectile.EntityTippedArrow
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.api.utils.second.skid.two;

import com.google.common.collect.ImmutableMap;
import it.make.api.utils.second.skid.CombatUtil;
import it.make.api.utils.second.skid.RotationUtil;
import it.make.api.utils.second.skid.two.BlockUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class SeijaBlockUtil {
    private static Minecraft mc = Minecraft.func_71410_x();

    public static ArrayList<BlockPos> haveNeighborBlock(BlockPos pos, Block neighbor) {
        ArrayList<BlockPos> blockList = new ArrayList<BlockPos>();
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(1, 0, 0)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(1, 0, 0));
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(-1, 0, 0)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(-1, 0, 0));
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(0, 1, 0));
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, -1, 0)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(0, -1, 0));
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 0, 1)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(0, 0, 1));
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 0, -1)).func_177230_c().equals(neighbor)) {
            blockList.add(pos.func_177982_a(0, 0, -1));
        }
        return blockList;
    }

    public static boolean isPlaceable(BlockPos pos, boolean helpBlock, boolean bBoxCheck) {
        return !(!SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) || helpBlock && SeijaBlockUtil.haveNeighborBlock(pos, Blocks.field_150350_a).size() >= 6 || bBoxCheck && !SeijaBlockUtil.isNoBBoxBlocked(pos));
    }

    public static boolean isFacing(BlockPos pos, EnumFacing enumFacing) {
        ImmutableMap properties = SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos).func_177228_b();
        for (IProperty prop : properties.keySet()) {
            if (prop.func_177699_b() != EnumFacing.class || !prop.func_177701_a().equals("facing") && !prop.func_177701_a().equals("rotation") || properties.get((Object)prop) != enumFacing) continue;
            return true;
        }
        return false;
    }

    public static EnumFacing getFacing(BlockPos pos) {
        ImmutableMap properties = SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos).func_177228_b();
        for (IProperty prop : properties.keySet()) {
            if (prop.func_177699_b() != EnumFacing.class || !prop.func_177701_a().equals("facing") && !prop.func_177701_a().equals("rotation")) continue;
            return (EnumFacing)properties.get((Object)prop);
        }
        return null;
    }

    public static boolean isNoBBoxBlocked(BlockPos pos) {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(pos);
        List l = SeijaBlockUtil.mc.field_71441_e.func_72839_b((Entity)null, axisAlignedBB);
        return l.size() == 0;
    }

    public static BlockPos getFlooredPosition(Entity entity) {
        return new BlockPos(Math.floor(entity.field_70165_t), (double)Math.round(entity.field_70163_u), Math.floor(entity.field_70161_v));
    }

    public static boolean isNoBBoxBlocked(BlockPos pos, boolean ignoreSomeEnt) {
        AxisAlignedBB axisAlignedBB = new AxisAlignedBB(pos);
        List l = SeijaBlockUtil.mc.field_71441_e.func_72839_b((Entity)null, axisAlignedBB);
        if (ignoreSomeEnt) {
            for (Entity entity : l) {
                if (entity instanceof EntityEnderCrystal || entity instanceof EntityItem || entity instanceof EntityArrow || entity instanceof EntityTippedArrow || entity instanceof EntityArrow || entity instanceof EntityXPOrb) continue;
                return false;
            }
            return true;
        }
        return l.size() == 0;
    }

    public static boolean isPlaceable(BlockPos pos, ArrayList<Block> ignoreBlock, boolean bBoxCheck, boolean helpBlockCheck, boolean rayTrace) {
        boolean placeable = false;
        for (Block iGB : ignoreBlock) {
            if (!SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(iGB) && !SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a)) continue;
            placeable = true;
            break;
        }
        if (bBoxCheck && !SeijaBlockUtil.isNoBBoxBlocked(pos, true)) {
            placeable = false;
        }
        if (helpBlockCheck && SeijaBlockUtil.haveNeighborBlock(pos, Blocks.field_150350_a).size() >= 6) {
            placeable = false;
        }
        if (rayTrace && !CombatUtil.rayTraceRangeCheck(pos, 0.0, 0.0)) {
            placeable = false;
        }
        return placeable;
    }

    public static void placeBlock(BlockPos pos, EnumHand hand, boolean rotate, boolean packet, EnumFacing placeFac) {
        EnumFacing side = placeFac;
        HashMap<EnumFacing, Double> distanceMap = new HashMap<EnumFacing, Double>();
        for (EnumFacing fac : EnumFacing.values()) {
            BlockPos offsetBlock = pos.func_177972_a(fac);
            if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(offsetBlock).func_177230_c().equals(Blocks.field_150350_a)) continue;
            distanceMap.put(fac, Math.sqrt(SeijaBlockUtil.mc.field_71439_g.func_174818_b(offsetBlock)));
        }
        if (distanceMap.size() != 0) {
            ArrayList list = new ArrayList(distanceMap.entrySet());
            side = (EnumFacing)((Map.Entry)list.get(0)).getKey();
        }
        if (SeijaBlockUtil.mc.field_71441_e.func_180495_p(pos.func_177967_a(side, 1)).func_177230_c().equals(Blocks.field_150350_a) && placeFac == null) {
            return;
        }
        if (side == null) {
            return;
        }
        BlockPos neighbour = pos.func_177972_a(side);
        EnumFacing opposite = side.func_176734_d();
        Vec3d hitVec = new Vec3d((Vec3i)neighbour).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(opposite.func_176730_m()).func_186678_a(0.5));
        Block neighbourBlock = BlockUtil.mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
        if (!BlockUtil.mc.field_71439_g.func_70093_af() && (BlockUtil.blackList.contains(neighbourBlock) || BlockUtil.shulkerList.contains(neighbourBlock))) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            BlockUtil.mc.field_71439_g.func_70095_a(true);
        }
        if (rotate) {
            RotationUtil.faceVector(hitVec, true);
        }
        BlockUtil.rightClickBlock(neighbour, hitVec, hand, opposite, packet);
        BlockUtil.mc.field_71467_ac = 4;
    }

    public static void sneak(BlockPos pos) {
        if (!BlockUtil.mc.field_71439_g.func_70093_af() && (BlockUtil.blackList.contains(pos) || BlockUtil.shulkerList.contains(pos))) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            BlockUtil.mc.field_71439_g.func_70095_a(true);
        }
    }

    public static BlockPos vec3toBlockPos(Vec3d vec3d, boolean Yfloor) {
        if (Yfloor) {
            return new BlockPos(Math.floor(vec3d.field_72450_a), Math.floor(vec3d.field_72448_b), Math.floor(vec3d.field_72449_c));
        }
        return new BlockPos(Math.floor(vec3d.field_72450_a), (double)Math.round(vec3d.field_72448_b), Math.floor(vec3d.field_72449_c));
    }

    public static BlockPos vec3toBlockPos(Vec3d vec3d) {
        return new BlockPos(Math.floor(vec3d.field_72450_a), (double)Math.round(vec3d.field_72448_b), Math.floor(vec3d.field_72449_c));
    }

    public static boolean fakeBBoxCheck(EntityPlayer player, Vec3d offset, boolean headcheck) {
        Vec3d actualPos = player.func_174791_d().func_178787_e(offset);
        if (headcheck) {
            Vec3d playerPos = player.func_174791_d();
            return SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 0.0, -0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 1.8, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 1.8, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 1.8, -0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 1.8, 0.3)) && SeijaBlockUtil.isAir(playerPos.func_72441_c(0.3, 2.8, 0.3)) && SeijaBlockUtil.isAir(playerPos.func_72441_c(-0.3, 2.8, 0.3)) && SeijaBlockUtil.isAir(playerPos.func_72441_c(-0.3, 2.8, -0.3)) && SeijaBlockUtil.isAir(playerPos.func_72441_c(0.3, 2.8, -0.3));
        }
        return SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 0.0, -0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 0.0, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 1.8, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 1.8, 0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(0.3, 1.8, -0.3)) && SeijaBlockUtil.isAir(actualPos.func_72441_c(-0.3, 1.8, 0.3));
    }

    public static boolean isAir(Vec3d vec3d) {
        return SeijaBlockUtil.mc.field_71441_e.func_180495_p(SeijaBlockUtil.vec3toBlockPos(vec3d, true)).func_177230_c().equals(Blocks.field_150350_a);
    }

    public static void placeBlock(Vec3d vec3d, EnumHand hand, boolean rotate, boolean packet) {
        BlockPos pos = SeijaBlockUtil.vec3toBlockPos(vec3d);
        EnumFacing side = BlockUtil.getFirstFacing(pos);
        if (side == null) {
            return;
        }
        BlockPos neighbour = pos.func_177972_a(side);
        EnumFacing opposite = side.func_176734_d();
        Vec3d hitVec = new Vec3d((Vec3i)neighbour).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(opposite.func_176730_m()).func_186678_a(0.5));
        Block neighbourBlock = BlockUtil.mc.field_71441_e.func_180495_p(neighbour).func_177230_c();
        if (!BlockUtil.mc.field_71439_g.func_70093_af() && (BlockUtil.blackList.contains(neighbourBlock) || BlockUtil.shulkerList.contains(neighbourBlock))) {
            BlockUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)BlockUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            BlockUtil.mc.field_71439_g.func_70095_a(true);
        }
        if (rotate) {
            RotationUtil.faceVector(hitVec, true);
        }
        BlockUtil.rightClickBlock(neighbour, hitVec, hand, opposite, packet);
        BlockUtil.mc.field_71467_ac = 4;
    }
}

