/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.api.utils.second.skid;

import it.make.api.Wrapper;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class SilentRotationUtil
implements Wrapper {
    public static void lookAtVector(Vec3d vec) {
        float[] angle = SilentRotationUtil.calcAngle(SilentRotationUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), vec);
        SilentRotationUtil.setPlayerRotations(angle[0], angle[1]);
        SilentRotationUtil.mc.field_71439_g.field_70761_aq = angle[0];
        SilentRotationUtil.mc.field_71439_g.field_70759_as = angle[0];
    }

    public static void lookAtVec3d(Vec3d vec3d) {
        float[] angle = SilentRotationUtil.calculateAngle(SilentRotationUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c));
        SilentRotationUtil.mc.field_71439_g.field_70125_A = angle[1];
        SilentRotationUtil.mc.field_71439_g.field_70177_z = angle[0];
    }

    public static void lookAtXYZ(double x, double y, double z) {
        Vec3d vec3d = new Vec3d(x, y, z);
        SilentRotationUtil.lookAtVec3d(vec3d);
    }

    public static void lookAtEntity(Entity entity) {
        float[] angle = SilentRotationUtil.calcAngle(SilentRotationUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174824_e(mc.func_184121_ak()));
        SilentRotationUtil.lookAtAngles(angle[0], angle[1]);
    }

    public static void lookAtAngles(float yaw, float pitch) {
        SilentRotationUtil.setPlayerRotations(yaw, pitch);
        SilentRotationUtil.mc.field_71439_g.field_70759_as = yaw;
    }

    public static void lookAtBlock(BlockPos blockPos) {
        float[] angle = SilentRotationUtil.calcAngle(SilentRotationUtil.mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d((Vec3i)blockPos));
        SilentRotationUtil.setPlayerRotations(angle[0], angle[1]);
        SilentRotationUtil.mc.field_71439_g.field_70761_aq = angle[0];
        SilentRotationUtil.mc.field_71439_g.field_70759_as = angle[0];
    }

    public static void setPlayerRotations(float yaw, float pitch) {
        SilentRotationUtil.mc.field_71439_g.field_70177_z = yaw;
        SilentRotationUtil.mc.field_71439_g.field_70759_as = yaw;
        SilentRotationUtil.mc.field_71439_g.field_70125_A = pitch;
    }

    public static float[] calcAngle(Vec3d to) {
        if (to == null) {
            return null;
        }
        double difX = to.field_72450_a - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72450_a;
        double difY = (to.field_72448_b - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72448_b) * -1.0;
        double difZ = to.field_72449_c - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static float[] calcAngle(BlockPos to) {
        if (to == null) {
            return null;
        }
        double difX = (double)to.func_177958_n() - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72450_a;
        double difY = ((double)to.func_177956_o() - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72448_b) * -1.0;
        double difZ = (double)to.func_177952_p() - SilentRotationUtil.mc.field_71439_g.func_174824_e((float)1.0f).field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static float[] calcAngle(Vec3d from, Vec3d to) {
        double difX = to.field_72450_a - from.field_72450_a;
        double difY = (to.field_72448_b - from.field_72448_b) * -1.0;
        double difZ = to.field_72449_c - from.field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static float[] calculateAngle(Vec3d from, Vec3d to) {
        double difX = to.field_72450_a - from.field_72450_a;
        double difY = (to.field_72448_b - from.field_72448_b) * -1.0;
        double difZ = to.field_72449_c - from.field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        float yD = (float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0));
        float pD = (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)));
        if (pD > 90.0f) {
            pD = 90.0f;
        } else if (pD < -90.0f) {
            pD = -90.0f;
        }
        return new float[]{yD, pD};
    }
}

