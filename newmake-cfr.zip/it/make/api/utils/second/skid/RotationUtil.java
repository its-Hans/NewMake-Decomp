/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 */
package it.make.api.utils.second.skid;

import it.make.api.Wrapper;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtil
implements Wrapper {
    public static void faceYawAndPitch(float f, float f2) {
        RotationUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(f, f2, RotationUtil.mc.field_71439_g.field_70122_E));
    }

    public static int getDirection4D() {
        return MathHelper.func_76128_c((double)((double)(RotationUtil.mc.field_71439_g.field_70177_z * 4.0f / 360.0f) + 0.5)) & 3;
    }

    public static String getDirection4D(boolean bl) {
        int n = RotationUtil.getDirection4D();
        if (n == 0) {
            return "South (+Z)";
        }
        if (n == 1) {
            return "West (-X)";
        }
        if (n == 2) {
            return (bl ? "\u8117\u6402c" : "") + "North (-Z)";
        }
        if (n == 3) {
            return "East (+X)";
        }
        return "Loading...";
    }

    public static float[] getLegitRotations(Vec3d vec3d) {
        Vec3d vec3d2 = RotationUtil.getEyesPos();
        double d = vec3d.field_72450_a - vec3d2.field_72450_a;
        double d2 = vec3d.field_72448_b - vec3d2.field_72448_b;
        double d3 = vec3d.field_72449_c - vec3d2.field_72449_c;
        double d4 = Math.sqrt(d * d + d3 * d3);
        float f = (float)Math.toDegrees(Math.atan2(d3, d)) - 90.0f;
        float f2 = (float)(-Math.toDegrees(Math.atan2(d2, d4)));
        return new float[]{RotationUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(f - RotationUtil.mc.field_71439_g.field_70177_z)), RotationUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(f2 - RotationUtil.mc.field_71439_g.field_70125_A))};
    }

    public static Vec3d getEyesPos() {
        return new Vec3d(RotationUtil.mc.field_71439_g.field_70165_t, RotationUtil.mc.field_71439_g.field_70163_u + (double)RotationUtil.mc.field_71439_g.func_70047_e(), RotationUtil.mc.field_71439_g.field_70161_v);
    }

    public static void faceVector(Vec3d vec3d, boolean bl) {
        float[] fArray = RotationUtil.getLegitRotations(vec3d);
        RotationUtil.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(fArray[0], bl ? (float)MathHelper.func_180184_b((int)((int)fArray[1]), (int)360) : fArray[1], RotationUtil.mc.field_71439_g.field_70122_E));
    }
}

