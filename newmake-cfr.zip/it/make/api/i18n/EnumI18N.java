/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.i18n;

public enum EnumI18N {
    English("EN"),
    Chinese("CN");

    public final String name;
    public static final EnumI18N DEFAULT;

    private EnumI18N(String name) {
        this.name = name;
    }

    static {
        DEFAULT = English;
    }
}

