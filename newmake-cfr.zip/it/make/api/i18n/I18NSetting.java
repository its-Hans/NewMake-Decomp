/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.i18n;

import it.make.Client;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import it.make.modules.client.ClickGui;

public class I18NSetting
extends Module {
    Setting<EnumI18N> I18N = this.rother("I18N", EnumI18N.DEFAULT);
    Setting<Boolean> reloadClickGui = this.rbool("ReloadClickGui", true);

    public I18NSetting() {
        super(new I18NInfo("I18NSetting").bind(EnumI18N.Chinese, "\u56fd\u9645\u5316"), "", Module.Category.CLIENT);
    }

    @Override
    public void onEnable() {
        this.refresh();
        this.disable();
    }

    @Override
    public void onLoad() {
        this.refresh();
    }

    public void refresh() {
        Client.i18NManager.current = this.I18N.getValue();
        Client.moduleManager.refreshI18N();
        if (this.reloadClickGui.getValue().booleanValue()) {
            ClickGui.getInstance().refreshGui();
        }
    }
}

