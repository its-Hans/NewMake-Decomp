/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.i18n;

import it.make.api.i18n.EnumI18N;
import java.util.Map;
import java.util.TreeMap;

public class I18NInfo {
    public final String defaultName;
    public final Map<EnumI18N, String> i18ns;

    public I18NInfo(String defaultName) {
        this.defaultName = defaultName;
        this.i18ns = new TreeMap<EnumI18N, String>();
        this.i18ns.put(EnumI18N.DEFAULT, defaultName);
    }

    public I18NInfo bind(EnumI18N type, String i18n) {
        this.i18ns.put(type, i18n);
        return this;
    }

    public String getI18N(EnumI18N ENUMI18N) {
        if (this.i18ns.containsKey((Object)ENUMI18N)) {
            return this.i18ns.get((Object)ENUMI18N);
        }
        return this.defaultName;
    }
}

