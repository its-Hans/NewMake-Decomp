/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.i18n;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import java.util.ArrayList;
import java.util.List;

public class I18N {
    public final List<I18NInfo> i18nlist;
    public EnumI18N current = EnumI18N.DEFAULT;

    public I18N() {
        this.i18nlist = new ArrayList<I18NInfo>();
    }

    public I18NInfo findModuleI18Ns(String defaultName) {
        for (I18NInfo info : this.i18nlist) {
            if (!info.defaultName.equals(defaultName)) continue;
            return info;
        }
        return null;
    }

    public String addI18N(I18NInfo info) {
        this.i18nlist.add(info);
        return info.defaultName;
    }

    public String getModuleI18N(EnumI18N ENUMI18N, String defaultName) {
        I18NInfo info = this.findModuleI18Ns(defaultName);
        return info.getI18N(ENUMI18N);
    }
}

