/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.network.NetHandlerPlayClient
 */
package it.make.api;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;

public interface Wrapper {
    public static final Minecraft mc = Minecraft.func_71410_x();

    default public WorldClient getClientWorld() {
        return Wrapper.mc.field_71441_e;
    }

    default public EntityPlayerSP getClientPlayer() {
        return Wrapper.mc.field_71439_g;
    }

    default public NetHandlerPlayClient getClientConnection() {
        return mc.func_147114_u();
    }
}

