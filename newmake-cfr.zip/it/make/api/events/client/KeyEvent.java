/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.events.client;

import it.make.api.events.EventStage;

public class KeyEvent
extends EventStage {
    private final int key;

    public KeyEvent(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }
}

