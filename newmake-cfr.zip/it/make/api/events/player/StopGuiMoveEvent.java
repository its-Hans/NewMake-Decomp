/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.Cancelable
 */
package it.make.api.events.player;

import it.make.api.events.EventStage;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class StopGuiMoveEvent
extends EventStage {
    public final boolean sneak;
    public final boolean chat;

    public StopGuiMoveEvent(boolean sneak, boolean chat) {
        this.sneak = sneak;
        this.chat = chat;
    }

    public void setMoveable() {
        this.setCanceled(true);
    }

    public boolean isNormal() {
        return !this.sneak && !this.chat;
    }
}

