/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.events.player;

import it.make.api.events.EventStage;

public class GayEvent
extends EventStage {
}

