/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.Cancelable
 */
package it.make.api.events.block;

import it.make.api.events.EventStage;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class SelfDamageBlockEvent
extends EventStage {
    public BlockPos pos;
    public EnumFacing facing;

    protected SelfDamageBlockEvent(int stage, BlockPos pos, EnumFacing facing) {
        super(stage);
        this.pos = pos;
        this.facing = facing;
    }

    public static class Port4
    extends SelfDamageBlockEvent {
        public Port4(int stage, BlockPos pos, EnumFacing facing) {
            super(stage, pos, facing);
        }
    }

    public static class Port3
    extends SelfDamageBlockEvent {
        public Port3(int stage, BlockPos pos, EnumFacing facing) {
            super(stage, pos, facing);
        }
    }

    public static class Port2
    extends SelfDamageBlockEvent {
        public Port2(int stage, BlockPos pos, EnumFacing facing) {
            super(stage, pos, facing);
        }
    }

    public static class Port1
    extends SelfDamageBlockEvent {
        public Port1(int stage, BlockPos pos, EnumFacing facing) {
            super(stage, pos, facing);
        }
    }
}

