/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.Cancelable
 */
package it.make.api.events.render;

import it.make.api.events.EventStage;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class RenderGuiEvent
extends EventStage {
    public final Guis gui;

    public RenderGuiEvent(Guis gui) {
        this.gui = gui;
    }

    public static enum Guis {
        PotionEffect,
        DrawWorldBackground;

    }
}

