/*
 * Decompiled with CFR 0.152.
 */
package it.make.api.exceptions;

import java.util.List;

public class GayException
extends RuntimeException {
    public GayException(GayError e) {
        super(String.join((CharSequence)",", e.gayIGNs), e);
    }

    public static class GayError
    extends Error {
        public final List<String> gayIGNs;

        public GayError(List<String> gayIGNs) {
            this.gayIGNs = gayIGNs;
        }
    }
}

