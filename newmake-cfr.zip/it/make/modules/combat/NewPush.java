/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDirectional
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package it.make.modules.combat;

import it.make.Client;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import it.make.modules.combat.AutoPush;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class NewPush
extends Module {
    public static final List<Block> canPushBlock = Arrays.asList(Blocks.field_150350_a, Blocks.field_150477_bB, Blocks.field_150472_an, Blocks.field_150444_as, Blocks.field_150488_af, Blocks.field_150473_bD);
    public static final List<Block> canPushBlock2 = Arrays.asList(Blocks.field_150350_a, Blocks.field_150472_an, Blocks.field_150444_as, Blocks.field_150488_af, Blocks.field_150473_bD);
    public final Setting<Integer> surroundCheck = this.register(new Setting<Integer>("SurroundCheck", 2, 0, 4));
    private final Setting<Integer> updateDelay = this.register(new Setting<Integer>("PlaceDelay", 100, 0, 500));
    private final Setting<Double> range = this.register(new Setting<Double>("TargetRange", 6.0, 0.0, 8.0));
    private final Setting<Double> placeRange = this.register(new Setting<Double>("PlaceRange", 6.0, 0.0, 8.0));
    private final Setting<Double> pistonCheck = this.register(new Setting<Double>("AntiDisturb", 2.6, 0.0, 8.0));
    private final Setting<Boolean> autoDisable = this.register(new Setting<Boolean>("AutoDisable", true));
    private final Setting<Boolean> noEating = this.register(new Setting<Boolean>("NoEating", true));
    private final Setting<Boolean> minePower = this.register(new Setting<Boolean>("MinePower", true));
    private final Setting<Boolean> pullBack = this.register(new Setting<Boolean>("PullBack", true));
    private final Setting<Boolean> onlyBurrow = this.register(new Setting<Boolean>("OnlyBurrow", Boolean.valueOf(true), v -> this.pullBack.getValue()));
    private final Setting<Boolean> preferPower = this.register(new Setting<Boolean>("PreferPower", true));
    private final Setting<Boolean> targetGround = this.register(new Setting<Boolean>("TargetGround", false));
    private final Setting<Boolean> pistonPacket = this.register(new Setting<Boolean>("PistonPacket", false));
    private final Setting<Boolean> powerPacket = this.register(new Setting<Boolean>("PowerPacket", true));
    private final Setting<Boolean> checkCrystal = this.register(new Setting<Boolean>("CheckCrystal", true));
    private final Setting<Boolean> breakCrystal = this.register(new Setting<Boolean>("BreakCrystal", true));
    private final Setting<Boolean> selfGround = this.register(new Setting<Boolean>("SelfGround", true));
    private final Setting<Double> maxSelfSpeed = this.register(new Setting<Double>("MaxSelfSpeed", 6.0, 1.0, 30.0));
    private final Setting<Double> maxTargetSpeed = this.register(new Setting<Double>("MaxTargetSpeed", 4.0, 1.0, 15.0));
    private final Setting<Integer> multiPlace = this.register(new Setting<Integer>("MultiPlace", 2, 1, 8));
    private final Timer timer = new Timer();
    int progress = 0;
    private EntityPlayer displayTarget;

    public NewPush() {
        super("NewPush", "test", Module.Category.COMBAT);
    }

    @Override
    public void onUpdate() {
        this.progress = 0;
        this.displayTarget = null;
        if (RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) != -1 && RebirthUtil.findHotbarClass(BlockPistonBase.class) != -1) {
            if (!(!this.timer.passedMs(this.updateDelay.getValue().intValue()) || this.noEating.getValue().booleanValue() && RebirthUtil.isEating() || Client.speedManager.getPlayerSpeed((EntityPlayer)NewPush.mc.field_71439_g) > this.maxSelfSpeed.getValue() || this.selfGround.getValue().booleanValue() && !NewPush.mc.field_71439_g.field_70122_E)) {
                for (EntityPlayer player : NewPush.mc.field_71441_e.field_73010_i) {
                    if (!this.canPush(player).booleanValue() || !RebirthUtil.isValid((Entity)player, this.range.getValue()) || !player.field_70122_E && this.targetGround.getValue().booleanValue() || Client.speedManager.getPlayerSpeed(player) > this.maxTargetSpeed.getValue()) continue;
                    if (this.progress >= this.multiPlace.getValue()) {
                        return;
                    }
                    this.displayTarget = player;
                    this.doPush(player);
                }
                if ((this.displayTarget == null || this.progress == 0) && this.autoDisable.getValue().booleanValue()) {
                    this.disable();
                }
            }
        } else if (this.autoDisable.getValue().booleanValue()) {
            this.disable();
        }
    }

    private void doPush(EntityPlayer target) {
        BlockPos targetPos = new BlockPos(target.field_70165_t, target.field_70163_u + 0.5, target.field_70161_v);
        if (this.getBlock(targetPos.func_177982_a(0, 2, 0)) != Blocks.field_150350_a) {
            BlockPos pos;
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP || !(this.getBlock(pos = targetPos.func_177972_a(i).func_177984_a()) instanceof BlockPistonBase) || !canPushBlock2.contains(this.getBlock(pos.func_177967_a(i, -2))) || !canPushBlock2.contains(this.getBlock(pos.func_177967_a(i, -2).func_177977_b())) || ((EnumFacing)this.getBlockState(pos).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != i) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!this.placePower(pos, true)) continue;
                return;
            }
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP) continue;
                pos = targetPos.func_177972_a(i).func_177984_a();
                if ((NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() <= -1.0 || NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() >= 2.0) && RebirthUtil.distanceToXZ((double)pos.func_177958_n() + 0.5, (double)pos.func_177952_p() + 0.5) < this.pistonCheck.getValue() || !RebirthUtil.canPlace2(pos, this.placeRange.getValue()) || !canPushBlock2.contains(this.getBlock(pos.func_177967_a(i, -2))) || !canPushBlock2.contains(this.getBlock(pos.func_177967_a(i, -2).func_177977_b()))) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!RebirthUtil.canPlace(pos) || this.progress >= this.multiPlace.getValue() || RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) == -1 || !this.placePiston(i, pos)) continue;
                return;
            }
        } else {
            BlockPos pos;
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP || !(this.getBlock(pos = targetPos.func_177972_a(i).func_177984_a()) instanceof BlockPistonBase) || !canPushBlock.contains(this.getBlock(pos.func_177967_a(i, -2))) || !canPushBlock.contains(this.getBlock(pos.func_177967_a(i, -2).func_177984_a())) || ((EnumFacing)this.getBlockState(pos).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != i) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!this.placePower(pos, true)) continue;
                return;
            }
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP) continue;
                pos = targetPos.func_177972_a(i).func_177984_a();
                if ((NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() <= -1.0 || NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() >= 2.0) && RebirthUtil.distanceToXZ((double)pos.func_177958_n() + 0.5, (double)pos.func_177952_p() + 0.5) < this.pistonCheck.getValue() || !RebirthUtil.canPlace2(pos, this.placeRange.getValue()) || !canPushBlock.contains(this.getBlock(pos.func_177967_a(i, -2))) || !canPushBlock.contains(this.getBlock(pos.func_177967_a(i, -2).func_177984_a()))) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!this.preferPower(pos)) continue;
                if (this.placePiston(i, pos)) {
                    return;
                }
                return;
            }
            if (canPushBlock.contains(this.getBlock(targetPos)) && this.onlyBurrow.getValue().booleanValue() || !this.pullBack.getValue().booleanValue()) {
                return;
            }
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP || !(this.getBlock(pos = targetPos.func_177972_a(i).func_177984_a()) instanceof BlockPistonBase) || !canPushBlock.contains(this.getBlock(pos.func_177984_a())) && this.getBlock(pos.func_177984_a()) != Blocks.field_150451_bX || ((EnumFacing)this.getBlockState(pos).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != i) continue;
                for (EnumFacing i2 : EnumFacing.field_82609_l) {
                    if (this.getBlock(pos.func_177972_a(i2)) != Blocks.field_150451_bX) continue;
                    RebirthUtil.mineBlock(pos.func_177972_a(i2));
                    if (this.autoDisable.getValue().booleanValue()) {
                        this.disable();
                    }
                    return;
                }
            }
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP || !(this.getBlock(pos = targetPos.func_177972_a(i).func_177984_a()) instanceof BlockPistonBase) || !canPushBlock.contains(this.getBlock(pos.func_177984_a())) && this.getBlock(pos.func_177984_a()) != Blocks.field_150451_bX || ((EnumFacing)this.getBlockState(pos).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != i) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!this.placePower(pos, false)) continue;
                return;
            }
            for (EnumFacing i : EnumFacing.field_82609_l) {
                if (i == EnumFacing.DOWN || i == EnumFacing.UP) continue;
                pos = targetPos.func_177972_a(i).func_177984_a();
                if ((NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() <= -1.0 || NewPush.mc.field_71439_g.field_70163_u - (double)targetPos.func_177956_o() >= 2.0) && RebirthUtil.distanceToXZ((double)pos.func_177958_n() + 0.5, (double)pos.func_177952_p() + 0.5) < this.pistonCheck.getValue() || !RebirthUtil.canPlace2(pos, this.placeRange.getValue()) || !canPushBlock.contains(this.getBlock(pos.func_177984_a())) && this.getBlock(pos.func_177984_a()) != Blocks.field_150451_bX) continue;
                if (this.breakCrystal.getValue().booleanValue()) {
                    this.attackCrystal(pos);
                }
                if (!this.preferPower(pos) || !this.placePiston(i, pos)) continue;
                return;
            }
        }
    }

    private boolean placePiston(EnumFacing i, BlockPos pos) {
        if (!RebirthUtil.canPlace(pos, this.placeRange.getValue())) {
            return false;
        }
        if (this.progress >= this.multiPlace.getValue()) {
            return false;
        }
        if (RebirthUtil.findHotbarBlock(BlockPistonBase.class) == -1) {
            return false;
        }
        AutoPush.pistonFacing(i);
        int old = NewPush.mc.field_71439_g.field_71071_by.field_70461_c;
        RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(BlockPistonBase.class));
        RebirthUtil.placeBlock(pos, EnumHand.MAIN_HAND, false, this.pistonPacket.getValue());
        RebirthUtil.doSwap(old);
        ++this.progress;
        this.timer.reset();
        RebirthUtil.facePlacePos(pos);
        this.placePower(pos, true);
        return true;
    }

    private boolean placePower(BlockPos pos, boolean disable) {
        if (this.progress >= this.multiPlace.getValue()) {
            return false;
        }
        for (EnumFacing i2 : EnumFacing.field_82609_l) {
            if (this.getBlock(pos.func_177972_a(i2)) != Blocks.field_150451_bX) continue;
            if (this.minePower.getValue().booleanValue()) {
                RebirthUtil.mineBlock(pos.func_177972_a(i2));
            }
            if (this.autoDisable.getValue().booleanValue() && disable) {
                this.disable();
            }
            return true;
        }
        if (RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) == -1) {
            return true;
        }
        EnumFacing facing = RebirthUtil.getBestNeighboring(pos, null);
        if (facing != null && RebirthUtil.canPlace(pos.func_177972_a(facing), this.placeRange.getValue())) {
            int old = NewPush.mc.field_71439_g.field_71071_by.field_70461_c;
            RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
            RebirthUtil.placeBlock(pos.func_177972_a(facing), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
            RebirthUtil.doSwap(old);
            ++this.progress;
            this.timer.reset();
            return true;
        }
        for (EnumFacing i2 : EnumFacing.field_82609_l) {
            if (!RebirthUtil.canPlace(pos.func_177972_a(i2), this.placeRange.getValue())) continue;
            int old = NewPush.mc.field_71439_g.field_71071_by.field_70461_c;
            RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
            RebirthUtil.placeBlock(pos.func_177972_a(i2), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
            RebirthUtil.doSwap(old);
            ++this.progress;
            this.timer.reset();
            return true;
        }
        return false;
    }

    private boolean preferPower(BlockPos pos) {
        if (this.preferPower.getValue().booleanValue()) {
            for (EnumFacing i2 : EnumFacing.field_82609_l) {
                if (NewPush.mc.field_71441_e.func_180495_p(pos.func_177972_a(i2)).func_177230_c() != Blocks.field_150451_bX) continue;
                return true;
            }
            if (this.progress >= this.multiPlace.getValue()) {
                return false;
            }
            for (EnumFacing i2 : EnumFacing.field_82609_l) {
                if (!RebirthUtil.canPlace(pos.func_177972_a(i2), this.placeRange.getValue())) continue;
                int old = NewPush.mc.field_71439_g.field_71071_by.field_70461_c;
                RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
                RebirthUtil.placeBlock(pos.func_177972_a(i2), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
                RebirthUtil.doSwap(old);
                ++this.progress;
                this.timer.reset();
                return true;
            }
        }
        if (!RebirthUtil.canPlaceEnum(pos)) {
            if (this.progress >= this.multiPlace.getValue()) {
                return false;
            }
            if (!RebirthUtil.canPlace(pos.func_177982_a(0, -1, 0), this.placeRange.getValue())) {
                return false;
            }
            if (RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) == -1) {
                return false;
            }
            int old = NewPush.mc.field_71439_g.field_71071_by.field_70461_c;
            RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
            RebirthUtil.placeBlock(pos.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, true, this.powerPacket.getValue());
            RebirthUtil.doSwap(old);
            ++this.progress;
            this.timer.reset();
        }
        return true;
    }

    public boolean attackCrystal(BlockPos pos) {
        for (Entity crystal : NewPush.mc.field_71441_e.field_72996_f.stream().filter(e -> e instanceof EntityEnderCrystal && !e.field_70128_L).sorted(Comparator.comparing(e -> Float.valueOf(NewPush.mc.field_71439_g.func_70032_d(e)))).collect(Collectors.toList())) {
            if (!(crystal instanceof EntityEnderCrystal)) continue;
            double d = crystal.func_70011_f((double)pos.func_177958_n(), (double)pos.func_177956_o(), (double)pos.func_177952_p());
            int n = this.checkCrystal.getValue() != false ? 4 : 2;
            if (!(d < (double)n)) continue;
            RebirthUtil.attackCrystal(crystal, true, true);
            return true;
        }
        return false;
    }

    private IBlockState getBlockState(BlockPos pos) {
        return NewPush.mc.field_71441_e.func_180495_p(pos);
    }

    private Block getBlock(BlockPos pos) {
        return NewPush.mc.field_71441_e.func_180495_p(pos).func_177230_c();
    }

    @Override
    public String getInfo() {
        return this.displayTarget != null ? this.displayTarget.func_70005_c_() : null;
    }

    private Boolean canPush(EntityPlayer player) {
        int surroundProgress = 0;
        if (!NewPush.mc.field_71441_e.func_175623_d(new BlockPos(player.field_70165_t, player.field_70163_u + 0.5, player.field_70161_v))) {
            return true;
        }
        if (!NewPush.mc.field_71441_e.func_175623_d(new BlockPos(player.field_70165_t + 1.0, player.field_70163_u + 0.5, player.field_70161_v))) {
            ++surroundProgress;
        }
        if (!NewPush.mc.field_71441_e.func_175623_d(new BlockPos(player.field_70165_t - 1.0, player.field_70163_u + 0.5, player.field_70161_v))) {
            ++surroundProgress;
        }
        if (!NewPush.mc.field_71441_e.func_175623_d(new BlockPos(player.field_70165_t, player.field_70163_u + 0.5, player.field_70161_v + 1.0))) {
            ++surroundProgress;
        }
        if (!NewPush.mc.field_71441_e.func_175623_d(new BlockPos(player.field_70165_t, player.field_70163_u + 0.5, player.field_70161_v - 1.0))) {
            ++surroundProgress;
        }
        return surroundProgress > this.surroundCheck.getValue() - 1;
    }
}

