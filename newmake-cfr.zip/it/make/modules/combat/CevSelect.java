/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockObsidian
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.combat;

import it.make.api.events.block.BlockEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.api.utils.second.m4ke.render.BlockAnimationMake;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockObsidian;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CevSelect
extends Module {
    public Setting<Integer> delay = this.rinte("delay", 0, 0, 2000);
    public Setting<Boolean> once = this.rbool("Once", true);
    public Setting<Boolean> stopClick = this.rbool("ResetOnClick", true);
    public Setting<Boolean> render = this.rbool("Render", true);
    public Setting<Integer> red = this.rinte("Red", 0, 0, 255, v -> this.render.getValue());
    public Setting<Integer> green = this.rinte("Green", 0, 0, 255, v -> this.render.getValue());
    public Setting<Integer> blue = this.rinte("Blue", 150, 0, 255, v -> this.render.getValue());
    public Setting<Integer> alpha = this.rinte("Alpha", 240, 0, 255, v -> this.render.getValue());
    public Setting<Double> range = this.rdoub("Range", 4.4, 1.0, 8.0);
    BlockPos dmgPos;
    Timer timer = new Timer();
    BlockAnimationMake ba = BlockAnimationMake.getNormalAnimation();

    public CevSelect() {
        super(new I18NInfo("CevSelect").bind(EnumI18N.Chinese, "\u6d17\u5934\u9009\u4e2d"), "description", Module.Category.COMBAT);
        this.select(null);
    }

    public Color getColor() {
        return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }

    @Override
    public void onEnable() {
        this.resets();
    }

    @Override
    public void onDisable() {
        this.resets();
    }

    @SubscribeEvent
    public void OnDamageBlock(BlockEvent event) {
        if (CevSelect.nullCheck()) {
            return;
        }
        if (event == null) {
            return;
        }
        if (UtilsRewrite.UBlock.getBlock(event.pos) != Blocks.field_150343_Z) {
            return;
        }
        if (this.dmgPos == event.pos) {
            if (this.stopClick.getValue().booleanValue()) {
                this.resets();
            }
            return;
        }
        this.select(event.pos);
    }

    @Override
    public void onUpdate() {
        if (CevSelect.fullNullCheck()) {
            this.resets();
            return;
        }
        if (this.dmgPos == null) {
            return;
        }
        if (UtilsRewrite.UBlock.getRange(this.dmgPos) > this.range.getValue()) {
            return;
        }
        if (UtilsRewrite.UInventory.itemSlot(Items.field_185158_cP) == -1 || UtilsRewrite.UInventory.itemSlot(Item.func_150898_a((Block)Blocks.field_150343_Z)) == -1) {
            this.resets();
            return;
        }
        BlockPos pos = this.dmgPos.func_177984_a();
        if (UtilsRewrite.UBlock.getBlock(this.dmgPos) instanceof BlockAir) {
            this.onAirDoSome(pos);
        }
        if (UtilsRewrite.UBlock.getBlock(this.dmgPos) instanceof BlockObsidian) {
            this.placecrystal(pos);
        }
        if (this.once.getValue().booleanValue()) {
            this.resets();
        }
    }

    synchronized void onAirDoSome(BlockPos pos) {
        if (RebirthUtil.posHasCrystal(pos)) {
            if (this.timer.passedMs(this.delay.getValue().intValue())) {
                this.timer.reset();
                RebirthUtil.attackCrystal(pos, true, true);
            }
        } else {
            UtilsRewrite.UBlock.doPlace2(this.dmgPos, null, true, true, Blocks.field_150343_Z);
        }
    }

    synchronized void placecrystal(BlockPos pos) {
        if (RebirthUtil.canPlaceCrystal(pos)) {
            RebirthUtil.facePosFacing(pos.func_177977_b(), EnumFacing.UP);
            int old = CevSelect.mc.field_71439_g.field_71071_by.field_70461_c;
            UtilsRewrite.UInventory.heldItemChange(UtilsRewrite.UInventory.itemSlot(Items.field_185158_cP), true, false, true);
            RebirthUtil.placeCrystal(pos, true, false);
            UtilsRewrite.UInventory.heldItemChange(old, true, false, true);
        }
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.render.getValue().booleanValue()) {
            return;
        }
        this.ba.doDraw();
    }

    @Override
    public void onTick() {
        this.ba.setColor(this.getColor());
        this.ba.doUpdate();
    }

    public void resets() {
        this.timer.reset();
        this.select(null);
    }

    public void select(BlockPos pos) {
        this.ba.select(pos);
        this.dmgPos = pos;
    }
}

