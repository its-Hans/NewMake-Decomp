/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDirectional
 *  net.minecraft.block.BlockObsidian
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package it.make.modules.combat;

import it.make.Client;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.two.BlockUtil;
import it.make.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.properties.IProperty;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AntiPush
extends Module {
    public static AntiPush INSTANCE;
    public final Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));
    public final Setting<Boolean> packet = this.register(new Setting<Boolean>("Packet", true));
    public final Setting<TrapMode> trap = this.register(new Setting<TrapMode>("Trap", TrapMode.SMART));
    public final Setting<Boolean> helper;
    private final Setting<Boolean> onlyBurrow = this.register(new Setting<Boolean>("OnlyBurrow", Boolean.valueOf(true), v -> this.trap.getValue() != TrapMode.NOTRAP));
    private final Setting<Boolean> whenDouble = this.register(new Setting<Boolean>("WhenDouble", Boolean.valueOf(true), v -> this.onlyBurrow.getValue()));
    private final Setting<Double> maxSelfSpeed = this.register(new Setting<Double>("MaxSelfSpeed", 6.0, 1.0, 30.0));

    public AntiPush() {
        super(new I18NInfo("AntiPush").bind(EnumI18N.Chinese, "\u53cd\u63a8\u4eba"), "Trap self when piston kick", Module.Category.COMBAT);
        this.helper = this.rbool("Helper", true);
        INSTANCE = this;
    }

    public static boolean canPlace(BlockPos var0) {
        if (!RebirthUtil.canBlockFacing(var0)) {
            return false;
        }
        if (!RebirthUtil.canReplace(var0)) {
            return false;
        }
        return !RebirthUtil.checkEntity(var0);
    }

    private Block getBlock(BlockPos var1) {
        return AntiPush.mc.field_71441_e.func_180495_p(var1).func_177230_c();
    }

    @Override
    public void onUpdate() {
        if (!AntiPush.fullNullCheck() && AntiPush.mc.field_71439_g.field_70122_E && !(Client.speedManager.getPlayerSpeed((EntityPlayer)AntiPush.mc.field_71439_g) > this.maxSelfSpeed.getValue())) {
            this.block();
        }
    }

    private void placeBlock(BlockPos var1) {
        if (AntiPush.canPlace(var1)) {
            int var2 = AntiPush.mc.field_71439_g.field_71071_by.field_70461_c;
            if (RebirthUtil.findHotbarClass(BlockObsidian.class) != -1) {
                RebirthUtil.doSwap(RebirthUtil.findHotbarClass(BlockObsidian.class));
                BlockUtil.placeBlock(var1, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue());
                RebirthUtil.doSwap(var2);
            }
        }
    }

    private void block() {
        BlockPos playerPos = RebirthUtil.getPlayerPos();
        if (this.getBlock(playerPos.func_177981_b(2)) != Blocks.field_150343_Z && this.getBlock(playerPos.func_177981_b(2)) != Blocks.field_150357_h) {
            int var2 = 0;
            if (this.whenDouble.getValue().booleanValue()) {
                for (EnumFacing var6 : EnumFacing.field_82609_l) {
                    if (var6 == EnumFacing.DOWN || var6 == EnumFacing.UP || !(this.getBlock(playerPos.func_177972_a(var6).func_177984_a()) instanceof BlockPistonBase) || ((EnumFacing)AntiPush.mc.field_71441_e.func_180495_p(playerPos.func_177972_a(var6).func_177984_a()).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var6) continue;
                    ++var2;
                }
            }
            for (EnumFacing var14 : EnumFacing.field_82609_l) {
                BlockPos pistonpos;
                if (var14 == EnumFacing.DOWN || var14 == EnumFacing.UP || !(this.getBlock(pistonpos = playerPos.func_177972_a(var14).func_177984_a()) instanceof BlockPistonBase)) continue;
                if (!(this.trap.getValue() != TrapMode.PISTONUP || this.getBlock(playerPos) == Blocks.field_150350_a && this.onlyBurrow.getValue().booleanValue())) {
                    this.placeBlock(pistonpos.func_177984_a());
                }
                if (!(this.trap.getValue() != TrapMode.SMART || this.getBlock(playerPos) == Blocks.field_150350_a && this.onlyBurrow.getValue().booleanValue())) {
                    Block b = UtilsRewrite.UBlock.getBlock(pistonpos.func_177984_a());
                    if (b == Blocks.field_150350_a) {
                        this.placeBlock(pistonpos.func_177984_a());
                    } else if (b == Blocks.field_150451_bX) {
                        this.placeBlock(playerPos.func_177981_b(2));
                        if (!RebirthUtil.canPlaceEnum(playerPos.func_177981_b(2))) {
                            EnumFacing[] enumFacingArray = EnumFacing.field_82609_l;
                            int n = enumFacingArray.length;
                            for (int i = 0; i < n; ++i) {
                                EnumFacing var10 = enumFacingArray[i];
                                if (!AntiPush.canPlace(playerPos.func_177972_a(var10).func_177981_b(2))) continue;
                                this.placeBlock(playerPos.func_177972_a(var10).func_177981_b(2));
                                break;
                            }
                        }
                    }
                }
                if (((EnumFacing)AntiPush.mc.field_71441_e.func_180495_p(playerPos.func_177972_a(var14).func_177984_a()).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var14) continue;
                this.placeBlock(playerPos.func_177984_a().func_177967_a(var14, -1));
                if (!(this.trap.getValue() != TrapMode.HEAD || this.getBlock(playerPos) == Blocks.field_150350_a && this.onlyBurrow.getValue().booleanValue() && var2 < 2)) {
                    this.placeBlock(playerPos.func_177981_b(2));
                    if (!RebirthUtil.canPlaceEnum(playerPos.func_177981_b(2))) {
                        for (EnumFacing var10 : EnumFacing.field_82609_l) {
                            if (!AntiPush.canPlace(playerPos.func_177972_a(var10).func_177981_b(2))) continue;
                            this.placeBlock(playerPos.func_177972_a(var10).func_177981_b(2));
                            break;
                        }
                    }
                }
                if (RebirthUtil.canPlaceEnum(playerPos.func_177984_a().func_177967_a(var14, -1)) || !this.helper.getValue().booleanValue()) continue;
                if (RebirthUtil.canPlaceEnum(playerPos.func_177967_a(var14, -1))) {
                    this.placeBlock(playerPos.func_177967_a(var14, -1));
                    continue;
                }
                this.placeBlock(playerPos.func_177967_a(var14, -1).func_177977_b());
            }
        }
    }

    static enum TrapMode {
        HEAD,
        PISTONUP,
        SMART,
        NOTRAP;

    }
}

