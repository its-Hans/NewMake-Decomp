/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.network.play.client.CPacketUseEntity$Action
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.combat;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;
import java.util.Objects;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Crit
extends Module {
    private final Setting<Integer> packets = this.register(new Setting<Integer>("Packets", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(4), "Amount of packets you want to send."));
    private final Timer timer = new Timer();
    private final boolean resetTimer = false;

    public Crit() {
        super(new I18NInfo("Crit").bind(EnumI18N.Chinese, "\u66b4\u51fb"), "L", Module.Category.COMBAT, true, false, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        CPacketUseEntity packet;
        if (event.getPacket() instanceof CPacketUseEntity && (packet = (CPacketUseEntity)event.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK) {
            Objects.requireNonNull(this);
            if (!this.timer.passedMs(0L)) {
                return;
            }
            if (Crit.mc.field_71439_g.field_70122_E && !Crit.mc.field_71474_y.field_74314_A.func_151470_d() && packet.func_149564_a((World)Crit.mc.field_71441_e) instanceof EntityLivingBase && !Crit.mc.field_71439_g.func_70090_H() && !Crit.mc.field_71439_g.func_180799_ab()) {
                switch (this.packets.getValue()) {
                    case 1: {
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + (double)0.1f, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        break;
                    }
                    case 2: {
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 0.0625101, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 1.1E-5, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        break;
                    }
                    case 3: {
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 0.0625101, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 0.0125, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        break;
                    }
                    case 4: {
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 0.1625, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 4.0E-6, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u + 1.0E-6, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crit.mc.field_71439_g.field_70165_t, Crit.mc.field_71439_g.field_70163_u, Crit.mc.field_71439_g.field_70161_v, false));
                        Crit.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
                        Crit.mc.field_71439_g.func_71009_b(Objects.requireNonNull(packet.func_149564_a((World)Crit.mc.field_71441_e)));
                    }
                }
                this.timer.reset();
            }
        }
    }

    @Override
    public String getDisplayInfo() {
        return "Packet";
    }
}

