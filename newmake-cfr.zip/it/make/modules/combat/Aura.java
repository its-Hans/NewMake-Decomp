/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemAxe
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package it.make.modules.combat;

import it.make.Client;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.EntityUtil;
import it.make.api.utils.MathUtil;
import it.make.api.utils.RotationUtil;
import it.make.api.utils.second.m4ke.general.PairUtil;
import it.make.api.utils.second.m4ke.io.STAGE;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import it.make.modules.client.Targets;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class Aura
extends Module {
    public static Aura INSTANCE;
    PairUtil.Pair<Entity, Integer> target = null;
    Setting<Rotation> rotation = this.rother("Rotation", Rotation.ONE);
    Setting<STAGE> rotate = this.rother("RotateStage", STAGE.PRE);
    Setting<STAGE> swing = this.rother("SwingStage", STAGE.PRE);
    Setting<STAGE> updateHurtHighlight = this.rother("HighlightStage", STAGE.POST);
    Setting<Float> range = this.rfloa("Range", Float.valueOf(5.4f), Float.valueOf(1.0f), Float.valueOf(6.0f));
    Setting<Float> wallRange = this.rfloa("WallRange", Float.valueOf(2.8f), Float.valueOf(0.0f), Float.valueOf(6.0f));
    Setting<Boolean> packetAttack = this.rbool("PacketAttack", false);
    Setting<Boolean> debug = this.rbool("Debug", false);
    Setting<Boolean> targetMob = this.rbool("TargetMob", true);
    Setting<Boolean> cooldown = this.rbool("Cooldown", true);
    Setting<Boolean> swordOnly = this.rbool("WeaponCheck", true);
    Setting<Boolean> eatingCheck = this.rbool("Using Cancel", true);
    Setting<Boolean> render = this.rbool("Render", false);
    Setting<Integer> hurtHighlight = this.rinte("HurtHighlight", 5, 0, 20, v -> this.render.getValue());
    Setting<Integer> redw = this.rinte("Red_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> greenw = this.rinte("Green_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> bluew = this.rinte("Blue_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> alphaw = this.rinte("Alpha_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> redh = this.rinte("Red_Hurt", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> greenh = this.rinte("Green_Hurt", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> blueh = this.rinte("Blue_Hurt", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> alphah = this.rinte("Alpha_Hurt", 255, 0, 255, v -> this.render.getValue());

    public Aura() {
        super(new I18NInfo("Aura").bind(EnumI18N.Chinese, "\u6740\u622e\u5149\u73af"), "description", Module.Category.COMBAT);
        INSTANCE = this;
    }

    public void lookAtEntity(Entity entity) {
        switch (this.rotation.getValue()) {
            case ONE: {
                RotationUtil.faceEntity(entity);
                break;
            }
            case TWO: {
                Client.rotationManager.lookAtEntity(entity);
                break;
            }
            case THREE: {
                RebirthUtil.faceXYZ(entity.field_70165_t, entity.field_70163_u + 0.25, entity.field_70161_v);
            }
        }
    }

    @SubscribeEvent
    public void onWalk(UpdateWalkingPlayerEvent event) {
        if (this.attackCheck()) {
            this.refreshTarget();
            if (this.target.left != null && this.isntEating() && this.isRaytraceable((Entity)this.target.left)) {
                this.hurt();
            }
        }
    }

    public void refreshTarget() {
        Object t = this.targetMob.getValue() != false ? Targets.getTargetByRange_Mob(this.range.getValue()) : Targets.getTargetByRange(this.range.getValue());
        if (this.target == null || this.target.left != t) {
            this.target = new PairUtil.Pair<Entity, Integer>((Entity)t, this.hurtHighlight.getValue());
        }
    }

    @Override
    public void onTick() {
        if (this.target != null && (Integer)this.target.right > 0) {
            PairUtil.Pair<Entity, Integer> pair = this.target;
            pair.right = (Integer)pair.right - 1;
        }
    }

    public void hurt() {
        STAGE swingmode = this.swing.getValue();
        STAGE rotatemode = this.rotate.getValue();
        STAGE updatemode = this.updateHurtHighlight.getValue();
        Entity t = (Entity)this.target.left;
        if (swingmode == STAGE.PRE) {
            Aura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (rotatemode == STAGE.PRE) {
            this.lookAtEntity(t);
        }
        if (updatemode == STAGE.PRE) {
            this.target.right = this.hurtHighlight.getValue();
        }
        if (this.packetAttack.getValue().booleanValue()) {
            Aura.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(t));
        } else {
            Aura.mc.field_71442_b.func_78764_a((EntityPlayer)Aura.mc.field_71439_g, t);
        }
        if (swingmode == STAGE.POST) {
            Aura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (rotatemode == STAGE.POST) {
            this.lookAtEntity(t);
        }
        if (updatemode == STAGE.POST) {
            this.target.right = this.hurtHighlight.getValue();
        }
        if (this.debug.getValue().booleanValue()) {
            Aura.notiMessage("HURT. ROTATE: " + rotatemode.name() + " SWING: " + swingmode.name() + " TARGET: " + t.func_70005_c_());
        }
    }

    public boolean attackCheck() {
        return this.isHeldWeapon() && this.isDelayed();
    }

    public boolean isHeldWeapon() {
        return this.swordOnly.getValue() == false || this.isWeapon(Aura.mc.field_71439_g.func_184614_ca().func_77973_b());
    }

    public boolean isDelayed() {
        return this.cooldown.getValue() == false || Aura.mc.field_71439_g.func_184825_o(0.0f) >= 1.0f;
    }

    public boolean isntEating() {
        return this.eatingCheck.getValue() == false || !Mouse.isButtonDown((int)1) && !Aura.mc.field_71439_g.func_184587_cr();
    }

    public boolean isRaytraceable(Entity entity) {
        return Aura.mc.field_71439_g.func_70685_l(entity) || EntityUtil.canEntityFeetBeSeen(entity) || !(Aura.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(this.wallRange.getValue().floatValue()));
    }

    public boolean isWeapon(Item item) {
        return item instanceof ItemSword || item instanceof ItemAxe;
    }

    private double easeInOutQuad(double d) {
        return d < 0.5 ? 2.0 * d * d : 1.0 - Math.pow(-2.0 * d + 2.0, 2.0) / 2.0;
    }

    @Override
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.render.getValue().booleanValue()) {
            return;
        }
        if (!this.isHeldWeapon()) {
            return;
        }
        if (this.target == null) {
            return;
        }
        Entity entity = (Entity)this.target.left;
        if (entity == null) {
            return;
        }
        Color color1 = (Integer)this.target.right > 0 ? new Color(this.redh.getValue(), this.greenh.getValue(), this.blueh.getValue(), this.alphah.getValue()) : new Color(this.redw.getValue(), this.greenw.getValue(), this.bluew.getValue(), this.alphaw.getValue());
        double d = 1500.0;
        double d2 = (double)System.currentTimeMillis() % d;
        boolean bl = d2 > d / 2.0;
        double d3 = d2 / (d / 2.0);
        d3 = !bl ? 1.0 - d3 : d3 - 1.0;
        d3 = this.easeInOutQuad(d3);
        Aura.mc.field_71460_t.func_175072_h();
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glShadeModel((int)7425);
        Aura.mc.field_71460_t.func_175072_h();
        double d4 = entity.field_70130_N;
        double d5 = (double)entity.field_70131_O + 0.1;
        double d6 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78730_l;
        double d7 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78731_m + d5 * d3;
        double d8 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)mc.func_184121_ak() - Aura.mc.func_175598_ae().field_78728_n;
        double d9 = d5 / 3.0 * (d3 > 0.5 ? 1.0 - d3 : d3) * (double)(bl ? -1 : 1);
        for (int i = 0; i < 360; i += 5) {
            double d10 = d6 - Math.sin((double)i * Math.PI / 180.0) * d4;
            double d11 = d8 + Math.cos((double)i * Math.PI / 180.0) * d4;
            double d12 = d6 - Math.sin((double)(i - 5) * Math.PI / 180.0) * d4;
            double d13 = d8 + Math.cos((double)(i - 5) * Math.PI / 180.0) * d4;
            GL11.glBegin((int)7);
            GL11.glColor4f((float)((float)ColorUtil.pulseColor(color1, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getBlue() / 255.0f), (float)0.0f);
            GL11.glVertex3d((double)d10, (double)(d7 + d9), (double)d11);
            GL11.glVertex3d((double)d12, (double)(d7 + d9), (double)d13);
            GL11.glColor4f((float)((float)ColorUtil.pulseColor(color1, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getBlue() / 255.0f), (float)200.0f);
            GL11.glVertex3d((double)d12, (double)d7, (double)d13);
            GL11.glVertex3d((double)d10, (double)d7, (double)d11);
            GL11.glEnd();
            GL11.glBegin((int)2);
            GL11.glVertex3d((double)d12, (double)d7, (double)d13);
            GL11.glVertex3d((double)d10, (double)d7, (double)d11);
            GL11.glEnd();
        }
        GL11.glEnable((int)2884);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
    }

    @Override
    public String getDisplayInfo() {
        if (this.target == null) {
            return null;
        }
        Entity t = (Entity)this.target.left;
        if (t == null) {
            return null;
        }
        return t.func_70005_c_();
    }

    static enum Rotation {
        ONE,
        TWO,
        THREE;

    }
}

