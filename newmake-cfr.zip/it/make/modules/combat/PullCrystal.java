/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDirectional
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 */
package it.make.modules.combat;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import it.make.modules.combat.AutoPush;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class PullCrystal
extends Module {
    public static PullCrystal INSTANCE;
    private EntityPlayer target;
    private final Timer timer;
    public static BlockPos crystalPos;
    public static BlockPos powerPos;
    private final Setting<Boolean> pistonPacket = this.register(new Setting<Boolean>("PistonPacket", false));
    private final Setting<Boolean> onlyGround = this.register(new Setting<Boolean>("onlyGround", true));
    private final Setting<Boolean> onlyStatic = this.register(new Setting<Boolean>("onlyStatic", true));
    private final Setting<Integer> updateDelay = this.register(new Setting<Integer>("UpdateDelay", 100, 0, 500));
    private final Setting<Boolean> packet = this.register(new Setting<Boolean>("Packet", true));
    private final Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(5.0f), Float.valueOf(1.0f), Float.valueOf(8.0f)));
    private final Setting<Boolean> fire = this.register(new Setting<Boolean>("Fire", true));
    private final Setting<Boolean> noEating = this.register(new Setting<Boolean>("EatingPause", true));
    private final Setting<Boolean> multiPlace = this.register(new Setting<Boolean>("MultiPlace", false));
    private final Setting<Boolean> debug = this.register(new Setting<Boolean>("debug", true));
    private final Setting<Boolean> fixPlaceCrystal = this.register(new Setting<Boolean>("placeFix", true));

    public PullCrystal() {
        super(new I18NInfo("PullCrystal").bind(EnumI18N.Chinese, "\u6d3b\u585e\u62c9\u6c34\u6676"), "use piston pull crystal and boom", Module.Category.COMBAT);
        INSTANCE = this;
        this.target = null;
        this.timer = new Timer();
    }

    @Override
    public String getDisplayInfo() {
        return this.target != null ? this.target.func_70005_c_() : null;
    }

    @Override
    public void onUpdate() {
        if (!(!this.timer.passedMs(this.updateDelay.getValue().intValue()) || this.noEating.getValue().booleanValue() && RebirthUtil.isEating())) {
            boolean var10001;
            boolean var10000 = this.onlyStatic.getValue();
            if (!PullCrystal.mc.field_71439_g.field_70122_E) {
                var10001 = true;
                boolean bl = false;
            } else {
                var10001 = false;
            }
            if (!PullCrystal.check(var10000, var10001, this.onlyGround.getValue())) {
                this.target = this.getTarget(this.range.getValue().floatValue());
                if (this.target == null) {
                    this.target = RebirthUtil.getTarget(this.range.getValue().floatValue());
                    if (this.target != null) {
                        this.mineBlock(RebirthUtil.getEntityPos((Entity)this.target));
                        var10000 = false;
                    }
                } else {
                    this.timer.reset();
                    var10000 = false;
                    BlockPos var1 = RebirthUtil.getEntityPos((Entity)this.target);
                    if (this.checkCrystal(var1.func_177981_b(0))) {
                        RebirthUtil.attackCrystal(var1.func_177981_b(0), true, true);
                    }
                    if (this.checkCrystal(var1.func_177981_b(1))) {
                        RebirthUtil.attackCrystal(var1.func_177981_b(1), true, true);
                    }
                    if (this.checkCrystal(var1.func_177981_b(2))) {
                        RebirthUtil.attackCrystal(var1.func_177981_b(2), true, true);
                    }
                    if (this.checkCrystal(var1.func_177981_b(3))) {
                        RebirthUtil.attackCrystal(var1.func_177981_b(3), true, true);
                    }
                    if (!(this.doPullCrystal(var1) || this.doPullCrystal(new BlockPos(this.target.field_70165_t + 0.1, this.target.field_70163_u + 0.5, this.target.field_70161_v + 0.1)) || this.doPullCrystal(new BlockPos(this.target.field_70165_t - 0.1, this.target.field_70163_u + 0.5, this.target.field_70161_v + 0.1)) || this.doPullCrystal(new BlockPos(this.target.field_70165_t + 0.1, this.target.field_70163_u + 0.5, this.target.field_70161_v - 0.1)))) {
                        this.doPullCrystal(new BlockPos(this.target.field_70165_t - 0.1, this.target.field_70163_u + 0.5, this.target.field_70161_v - 0.1));
                        boolean bl = false;
                    }
                }
            }
        }
    }

    private boolean checkCrystal(BlockPos var1) {
        for (Entity var3 : PullCrystal.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var1))) {
            float var4;
            if (var3 instanceof EntityEnderCrystal && (var4 = RebirthUtil.calculateDamage(var3, (Entity)this.target)) > 6.0f) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private IBlockState getBlockState(BlockPos var1) {
        return PullCrystal.mc.field_71441_e.func_180495_p(var1);
    }

    private boolean placePiston(BlockPos var1, EnumFacing var2, BlockPos var3) {
        return this.placePiston(var1, var2, var3, false) || this.placePiston(var1, var2, var3, true);
    }

    public static boolean check(boolean var0, boolean var1, boolean var2) {
        boolean var10000;
        if (RebirthUtil.isMoving() && var0) {
            return true;
        }
        if (var1 && var2) {
            return true;
        }
        if (RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) == -1) {
            return true;
        }
        if (RebirthUtil.findHotbarClass(BlockPistonBase.class) == -1) {
            return true;
        }
        if (RebirthUtil.findItemInHotbar(Items.field_185158_cP) == -1) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    public boolean crystal(BlockPos var1) {
        for (Entity var3 : PullCrystal.mc.field_71441_e.field_72996_f) {
            if (!(var3 instanceof EntityEnderCrystal)) continue;
            if (!(var3.func_70011_f((double)var1.func_177958_n() + 0.5, (double)var1.func_177956_o(), (double)var1.func_177952_p() + 0.5) > 4.0)) {
                RebirthUtil.attackCrystal(var3, true, false);
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private boolean power(BlockPos var1) {
        for (EnumFacing var5 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var5 != EnumFacing.DOWN) {
                if (var5 == EnumFacing.UP) {
                    bl = false;
                } else {
                    int var6 = var1.func_177972_a(var5).func_177958_n() - var1.func_177958_n();
                    int var7 = var1.func_177972_a(var5).func_177952_p() - var1.func_177952_p();
                    if (this.placePower(var1.func_177967_a(var5, 1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePower(var1.func_177967_a(var5, 1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePower(var1.func_177967_a(var5, -1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePower(var1.func_177967_a(var5, -1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                }
            }
            bl = false;
        }
        return false;
    }

    private boolean doPullCrystal(BlockPos var1) {
        if (this.pull(var1.func_177981_b(2))) {
            return true;
        }
        if (this.pull(var1.func_177984_a())) {
            return true;
        }
        if (this.crystal(var1.func_177984_a())) {
            return true;
        }
        if (this.power(var1.func_177981_b(2))) {
            return true;
        }
        if (this.power(var1.func_177984_a())) {
            return true;
        }
        return this.piston(var1.func_177981_b(2)) ? true : this.piston(var1.func_177984_a());
    }

    private boolean placePower(BlockPos var1, EnumFacing var2, BlockPos var3, boolean var4) {
        if (var4) {
            var1 = var1.func_177984_a();
        }
        if (!RebirthUtil.canPlaceCrystal(var3.func_177967_a(var2, -1)) && !RebirthUtil.posHasCrystal(var3.func_177967_a(var2, -1))) {
            return false;
        }
        if (!(this.getBlock(var1) instanceof BlockPistonBase)) {
            return false;
        }
        if (((EnumFacing)this.getBlockState(var1).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var2) {
            return false;
        }
        if (this.getBlock(var1.func_177967_a(var2, -1)) == Blocks.field_150332_K || this.getBlock(var1.func_177967_a(var2, -1)) == Blocks.field_180384_M) {
            return true;
        }
        if (!PullCrystal.mc.field_71441_e.func_175623_d(var1.func_177967_a(var2, -1)) && this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_150332_K && this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_180384_M && this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_150480_ab) {
            return false;
        }
        int var5 = PullCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
        return this.placeRedStone(var1, var2, var5, var3);
    }

    private boolean placePower(BlockPos var1, EnumFacing var2, BlockPos var3) {
        return this.placePower(var1, var2, var3, false) ? true : this.placePower(var1, var2, var3, true);
    }

    private boolean piston(BlockPos var1) {
        for (EnumFacing var5 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var5 != EnumFacing.DOWN) {
                if (var5 == EnumFacing.UP) {
                    bl = false;
                } else {
                    int var6 = var1.func_177972_a(var5).func_177958_n() - var1.func_177958_n();
                    int var7 = var1.func_177972_a(var5).func_177952_p() - var1.func_177952_p();
                    if (this.placePiston(var1.func_177967_a(var5, 1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePiston(var1.func_177967_a(var5, 1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePiston(var1.func_177967_a(var5, -1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.placePiston(var1.func_177967_a(var5, -1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                }
            }
            bl = false;
        }
        return false;
    }

    private void doFire(BlockPos var1, EnumFacing var2) {
        if (this.fire.getValue().booleanValue() && RebirthUtil.findItemInHotbar(Items.field_151033_d) != -1) {
            boolean bl;
            int var3 = PullCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
            for (EnumFacing var7 : EnumFacing.field_82609_l) {
                if (var7 != EnumFacing.DOWN) {
                    if (var7 == EnumFacing.UP) {
                        bl = false;
                    } else if (var1.func_177972_a(var7).equals((Object)var1.func_177972_a(var2))) {
                        bl = false;
                    } else if (PullCrystal.mc.field_71441_e.func_180495_p(var1.func_177972_a(var7)).func_177230_c() == Blocks.field_150480_ab) {
                        return;
                    }
                }
                bl = false;
            }
            for (EnumFacing var11 : EnumFacing.field_82609_l) {
                if (var11 != EnumFacing.DOWN) {
                    if (var11 == EnumFacing.UP) {
                        bl = false;
                    } else if (var1.func_177972_a(var11).equals((Object)var1.func_177972_a(var2))) {
                        bl = false;
                    } else if (var1.func_177972_a(var11).equals((Object)var1.func_177967_a(var2, -1)) && !RebirthUtil.posHasCrystal(var1.func_177967_a(var2, -1))) {
                        bl = false;
                    } else if (PullCrystal.canFire(var1.func_177972_a(var11))) {
                        RebirthUtil.doSwap(RebirthUtil.findItemInHotbar(Items.field_151033_d));
                        RebirthUtil.placeBlock(var1.func_177972_a(var11), EnumHand.MAIN_HAND, true, this.packet.getValue());
                        RebirthUtil.doSwap(var3);
                        return;
                    }
                }
                bl = false;
            }
            if (PullCrystal.canFire(var1.func_177967_a(var2, 1))) {
                RebirthUtil.doSwap(RebirthUtil.findItemInHotbar(Items.field_151033_d));
                RebirthUtil.placeBlock(var1.func_177967_a(var2, 1), EnumHand.MAIN_HAND, true, this.packet.getValue());
                RebirthUtil.doSwap(var3);
            }
        }
    }

    private boolean pistonActive(BlockPos var1, EnumFacing var2, BlockPos var3, boolean var4) {
        if (var4) {
            var1 = var1.func_177984_a();
        }
        if (!RebirthUtil.canPlaceCrystal(var3.func_177967_a(var2, -1)) && !RebirthUtil.posHasCrystal(var3.func_177967_a(var2, -1))) {
            return false;
        }
        if (!(this.getBlock(var1) instanceof BlockPistonBase)) {
            return false;
        }
        if (((EnumFacing)this.getBlockState(var1).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var2) {
            return false;
        }
        if (this.getBlock(var1.func_177967_a(var2, -1)) == Blocks.field_180384_M) {
            return true;
        }
        if (this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_150332_K) {
            return false;
        }
        for (EnumFacing var8 : EnumFacing.field_82609_l) {
            if (this.getBlock(var1.func_177972_a(var8)) == Blocks.field_150451_bX) {
                if (!RebirthUtil.posHasCrystal(var3.func_177967_a(var2, -1))) {
                    int var9 = PullCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
                    crystalPos = var3.func_177967_a(var2, -1);
                    RebirthUtil.doSwap(RebirthUtil.findItemInHotbar(Items.field_185158_cP));
                    this.placeCrystal(var3.func_177967_a(var2, -1), true, this.debug.getValue());
                    RebirthUtil.doSwap(var9);
                }
                this.doFire(var3, var2);
                powerPos = var1.func_177972_a(var8);
                this.mineBlock(var1.func_177972_a(var8));
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private boolean pull(BlockPos var1) {
        for (EnumFacing var5 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var5 != EnumFacing.DOWN) {
                if (var5 == EnumFacing.UP) {
                    bl = false;
                } else {
                    int var6 = var1.func_177972_a(var5).func_177958_n() - var1.func_177958_n();
                    int var7 = var1.func_177972_a(var5).func_177952_p() - var1.func_177952_p();
                    if (this.pistonActive(var1.func_177967_a(var5, 1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.pistonActive(var1.func_177967_a(var5, 1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                    if (this.pistonActive(var1.func_177967_a(var5, -1).func_177982_a(var7, 0, var6), var5, var1)) {
                        return true;
                    }
                    if (this.pistonActive(var1.func_177967_a(var5, -1).func_177982_a(-var7, 0, -var6), var5, var1)) {
                        return true;
                    }
                }
            }
            bl = false;
        }
        return false;
    }

    private void mineBlock(BlockPos var1) {
        RebirthUtil.mineBlock(var1);
    }

    private static boolean canFire(BlockPos var0) {
        return RebirthUtil.canReplace(var0.func_177977_b()) ? false : PullCrystal.mc.field_71441_e.func_175623_d(var0);
    }

    private Block getBlock(BlockPos var1) {
        return PullCrystal.mc.field_71441_e.func_180495_p(var1).func_177230_c();
    }

    private EntityPlayer getTarget(double var1) {
        EntityPlayer var3 = null;
        double var4 = var1;
        for (EntityPlayer var7 : PullCrystal.mc.field_71441_e.field_73010_i) {
            if (RebirthUtil.invalid((Entity)var7, var1) || this.getBlock(RebirthUtil.getEntityPos((Entity)var7)) != Blocks.field_150350_a) continue;
            if (var3 == null) {
                var3 = var7;
                var4 = PullCrystal.mc.field_71439_g.func_70068_e((Entity)var7);
                continue;
            }
            if (PullCrystal.mc.field_71439_g.func_70068_e((Entity)var7) >= var4) continue;
            var3 = var7;
            var4 = PullCrystal.mc.field_71439_g.func_70068_e((Entity)var7);
        }
        return var3;
    }

    private boolean placePiston(BlockPos var1, EnumFacing var2, BlockPos var3, boolean var4) {
        if (var4) {
            var1 = var1.func_177984_a();
        }
        if (!RebirthUtil.canPlaceCrystal(var3.func_177967_a(var2, -1)) && !RebirthUtil.posHasCrystal(var3.func_177967_a(var2, -1))) {
            return false;
        }
        if (!RebirthUtil.canPlace(var1) && !(this.getBlock(var1) instanceof BlockPistonBase)) {
            return false;
        }
        if (this.getBlock(var1) instanceof BlockPistonBase && ((EnumFacing)this.getBlockState(var1).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var2) {
            return false;
        }
        if (this.getBlock(var1.func_177967_a(var2, -1)) == Blocks.field_150332_K || this.getBlock(var1.func_177967_a(var2, -1)) == Blocks.field_180384_M) {
            return true;
        }
        if (!PullCrystal.mc.field_71441_e.func_175623_d(var1.func_177967_a(var2, -1)) && this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_150332_K && this.getBlock(var1.func_177967_a(var2, -1)) != Blocks.field_180384_M) {
            return false;
        }
        if ((PullCrystal.mc.field_71439_g.field_70163_u - (double)var1.func_177977_b().func_177956_o() <= -1.0 || PullCrystal.mc.field_71439_g.field_70163_u - (double)var1.func_177977_b().func_177956_o() >= 2.0) && RebirthUtil.distanceToXZ((double)var1.func_177958_n() + 0.5, (double)var1.func_177952_p() + 0.5) < 2.6) {
            return false;
        }
        int var5 = PullCrystal.mc.field_71439_g.field_71071_by.field_70461_c;
        if (RebirthUtil.canPlace(var1)) {
            RebirthUtil.facePlacePos(var1);
            AutoPush.pistonFacing(var2);
            RebirthUtil.doSwap(RebirthUtil.findHotbarBlock((Block)Blocks.field_150331_J));
            RebirthUtil.placeBlock(var1, EnumHand.MAIN_HAND, false, this.pistonPacket.getValue());
            RebirthUtil.doSwap(var5);
            RebirthUtil.facePlacePos(var1);
            return this.multiPlace.getValue() != false && this.placeRedStone(var1, var2, var5, var3) ? true : true;
        }
        return this.placeRedStone(var1, var2, var5, var3);
    }

    private boolean placeRedStone(BlockPos var1, EnumFacing var2, int var3, BlockPos var4) {
        for (EnumFacing var8 : EnumFacing.field_82609_l) {
            if (this.getBlock(var1.func_177972_a(var8)) == Blocks.field_150451_bX) {
                powerPos = var1.func_177972_a(var8);
                return true;
            }
            boolean bl = false;
        }
        EnumFacing var10 = RebirthUtil.getBestNeighboring(var1, var2);
        if (var10 != null && !var1.func_177972_a(var10).equals((Object)var4.func_177967_a(var2, -1)) && !var1.func_177972_a(var10).equals((Object)var4.func_177967_a(var2, -1).func_177984_a()) && RebirthUtil.canPlace(powerPos = var1.func_177972_a(var10))) {
            RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
            RebirthUtil.placeBlock(var1.func_177972_a(var10), EnumHand.MAIN_HAND, true, this.packet.getValue());
            RebirthUtil.doSwap(var3);
            return true;
        }
        for (EnumFacing var9 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var1.func_177972_a(var9).equals((Object)var1.func_177967_a(var2, -1))) {
                bl = false;
            } else if (var1.func_177972_a(var9).equals((Object)var4.func_177967_a(var2, -1))) {
                bl = false;
            } else if (var1.func_177972_a(var9).equals((Object)var4.func_177967_a(var2, -1).func_177984_a())) {
                bl = false;
            } else if (RebirthUtil.canPlace(var1.func_177972_a(var9))) {
                powerPos = var1.func_177972_a(var9);
                RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
                RebirthUtil.placeBlock(var1.func_177972_a(var9), EnumHand.MAIN_HAND, true, this.packet.getValue());
                RebirthUtil.doSwap(var3);
                return true;
            }
            bl = false;
        }
        return false;
    }

    private boolean pistonActive(BlockPos var1, EnumFacing var2, BlockPos var3) {
        return this.pistonActive(var1, var2, var3, false) || this.pistonActive(var1, var2, var3, true);
    }

    private void placeCrystal(BlockPos var0, boolean var1, boolean debug) {
        if (this.fixPlaceCrystal.getValue().booleanValue()) {
            RebirthUtil.placeCrystalFix(var0, true, debug);
        } else {
            RebirthUtil.placeCrystal(var0, true, debug);
        }
    }
}

