/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockDirectional
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.block.properties.IProperty
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.modules.combat;

import it.make.Client;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.two.BlockUtil;
import it.make.modules.Module;
import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class AutoPush
extends Module {
    public static final List<Block> canPushBlock = Arrays.asList(Blocks.field_150350_a, Blocks.field_150477_bB, Blocks.field_150472_an, Blocks.field_150444_as, Blocks.field_150488_af, Blocks.field_150473_bD);
    private EntityPlayer DisplayTarget = null;
    private final Timer timer;
    private final Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));
    private final Setting<Boolean> mine = this.register(new Setting<Boolean>("Mine", true));
    private final Setting<Double> placeRange = this.register(new Setting<Double>("PlaceRange", 5.0, 0.0, 6.0));
    private final Setting<Double> range = this.register(new Setting<Double>("Range", 5.0, 0.0, 6.0));
    private final Setting<Integer> surroundCheck = this.register(new Setting<Integer>("SurroundCheck", 2, 0, 4));
    private final Setting<Boolean> attackCrystal = this.register(new Setting<Boolean>("BreakCrystal", true));
    private final Setting<Boolean> crystalCheck = this.register(new Setting<Boolean>("CrystalCheck", true));
    private final Setting<Boolean> checkPiston = this.register(new Setting<Boolean>("PistonCheck", false));
    private final Setting<Boolean> redStonePacket = this.register(new Setting<Boolean>("RedStonePacket", true));
    private final Setting<Boolean> pistonPacket = this.register(new Setting<Boolean>("PistonPacket", false));
    private final Setting<Integer> updateDelay = this.register(new Setting<Integer>("delayUpdate", 100, 0, 500));
    private final Setting<Double> maxSelfSpeed = this.register(new Setting<Double>("MaxSelfSpeed", 6.0, 1.0, 30.0));
    private final Setting<Double> maxTargetSpeed = this.register(new Setting<Double>("MaxTargetSpeed", 4.0, 1.0, 15.0));
    private final Setting<Boolean> eatingPause = this.register(new Setting<Boolean>("E-Pause", Boolean.valueOf(true), v -> this.attackCrystal.getValue()));
    private final Setting<Boolean> pullBack = this.register(new Setting<Boolean>("PullBack", true));
    private final Setting<Boolean> onlyBurrow = this.register(new Setting<Boolean>("OnlyBurrow", Boolean.valueOf(true), v -> this.pullBack.getValue()));
    private final Setting<Boolean> allowWeb = this.register(new Setting<Boolean>("AllowWeb", true));
    private final Setting<Boolean> autoDisable = this.register(new Setting<Boolean>("AutoDisable", true));
    private final Setting<Boolean> onlyCrystal = this.register(new Setting<Boolean>("OnlyCrystal", false));
    private final Setting<Boolean> selfGround = this.register(new Setting<Boolean>("SelfGround", true));
    private final Setting<Boolean> noEating = this.register(new Setting<Boolean>("NoEating", true));
    private final Setting<Boolean> onlyGround = this.register(new Setting<Boolean>("OnlyGround", false));

    public AutoPush() {
        super(new I18NInfo("AutoPush").bind(EnumI18N.Chinese, "\u8001\u81ea\u52a8\u63a8\u4eba"), "use piston push hole fag", Module.Category.COMBAT);
        this.timer = new Timer();
    }

    @Override
    public String getDisplayInfo() {
        return this.DisplayTarget != null ? this.DisplayTarget.func_70005_c_() : null;
    }

    @Override
    public void onUpdate() {
        if (this.timer.passedMs(this.updateDelay.getValue().intValue())) {
            if (this.selfGround.getValue().booleanValue() && !AutoPush.mc.field_71439_g.field_70122_E) {
                if (this.autoDisable.getValue().booleanValue()) {
                    this.disable();
                }
            } else if (RebirthUtil.findHotbarBlock(Blocks.field_150451_bX) != -1 && RebirthUtil.findHotbarClass(BlockPistonBase.class) != -1) {
                if (Client.speedManager.getPlayerSpeed((EntityPlayer)AutoPush.mc.field_71439_g) > this.maxSelfSpeed.getValue()) {
                    if (this.autoDisable.getValue().booleanValue()) {
                        this.disable();
                    }
                } else if (!(this.noEating.getValue().booleanValue() && RebirthUtil.isEating() || this.onlyCrystal.getValue().booleanValue() && !AutoPush.mc.field_71439_g.func_184592_cb().func_77973_b().equals(Items.field_185158_cP) && !AutoPush.mc.field_71439_g.func_184614_ca().func_77973_b().equals(Items.field_185158_cP))) {
                    this.timer.reset();
                    boolean var10000 = false;
                    for (EntityPlayer var2 : AutoPush.mc.field_71441_e.field_73010_i) {
                        if (RebirthUtil.invalid((Entity)var2, this.range.getValue()) || !this.canPush(var2).booleanValue() || !var2.field_70122_E && this.onlyGround.getValue().booleanValue()) continue;
                        if (Client.speedManager.getPlayerSpeed(var2) > this.maxTargetSpeed.getValue()) {
                            var10000 = false;
                            continue;
                        }
                        if (AutoPush.isWeb(var2) && !this.allowWeb.getValue().booleanValue()) {
                            var10000 = false;
                            continue;
                        }
                        this.DisplayTarget = var2;
                        if (this.doPush(new BlockPos(var2.field_70165_t + 0.1, var2.field_70163_u + 0.5, var2.field_70161_v + 0.1), var2)) {
                            return;
                        }
                        if (this.doPush(new BlockPos(var2.field_70165_t - 0.1, var2.field_70163_u + 0.5, var2.field_70161_v + 0.1), var2)) {
                            return;
                        }
                        if (this.doPush(new BlockPos(var2.field_70165_t + 0.1, var2.field_70163_u + 0.5, var2.field_70161_v - 0.1), var2)) {
                            return;
                        }
                        if (this.doPush(new BlockPos(var2.field_70165_t - 0.1, var2.field_70163_u + 0.5, var2.field_70161_v - 0.1), var2)) {
                            return;
                        }
                        var10000 = false;
                    }
                    if (this.autoDisable.getValue().booleanValue()) {
                        this.disable();
                    }
                    this.DisplayTarget = null;
                }
            } else if (this.autoDisable.getValue().booleanValue()) {
                this.disable();
            }
        }
    }

    private Block getBlock(BlockPos var1) {
        return AutoPush.mc.field_71441_e.func_180495_p(var1).func_177230_c();
    }

    public static boolean isWeb(EntityPlayer var0) {
        if (AutoPush.isWeb(new BlockPos(var0.field_70165_t + 0.2, var0.field_70163_u + 0.5, var0.field_70161_v + 0.2))) {
            return true;
        }
        if (AutoPush.isWeb(new BlockPos(var0.field_70165_t - 0.2, var0.field_70163_u + 0.5, var0.field_70161_v + 0.2))) {
            return true;
        }
        return AutoPush.isWeb(new BlockPos(var0.field_70165_t - 0.2, var0.field_70163_u + 0.5, var0.field_70161_v - 0.2)) || AutoPush.isWeb(new BlockPos(var0.field_70165_t + 0.2, var0.field_70163_u + 0.5, var0.field_70161_v - 0.2));
    }

    public boolean doPush(BlockPos var1, EntityPlayer var2) {
        if (this.checkPiston.getValue().booleanValue() && this.checkPiston(var1)) {
            return true;
        }
        if (AutoPush.mc.field_71441_e.func_175623_d(var1.func_177981_b(2))) {
            boolean var472;
            boolean var462;
            boolean bl;
            boolean bl2;
            for (EnumFacing var38 : EnumFacing.field_82609_l) {
                if (var38 != EnumFacing.DOWN) {
                    if (var38 == EnumFacing.UP) {
                        boolean bl3 = false;
                    } else {
                        BlockPos var462 = var1.func_177972_a(var38).func_177984_a();
                        if (this.getBlock(var462) instanceof BlockPistonBase && canPushBlock.contains(this.getBlock(var462.func_177967_a(var38, -2))) && (this.getBlock(var462.func_177967_a(var38, -2).func_177984_a()) == Blocks.field_150350_a || this.getBlock(var462.func_177967_a(var38, -2).func_177984_a()) == Blocks.field_150451_bX)) {
                            if (((EnumFacing)this.getBlockState(var462).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var38) {
                                bl2 = false;
                            } else {
                                for (EnumFacing var61 : EnumFacing.field_82609_l) {
                                    if (this.getBlock(var462.func_177972_a(var61)) == Blocks.field_150451_bX) {
                                        if (this.mine.getValue().booleanValue()) {
                                            this.mine(var462.func_177972_a(var61));
                                        }
                                        if (this.autoDisable.getValue().booleanValue()) {
                                            this.disable();
                                        }
                                        return true;
                                    }
                                    bl = false;
                                }
                            }
                        }
                    }
                }
                var462 = false;
            }
            for (EnumFacing var39 : EnumFacing.field_82609_l) {
                if (var39 != EnumFacing.DOWN) {
                    if (var39 == EnumFacing.UP) {
                        var462 = false;
                    } else {
                        BlockPos var472 = var1.func_177972_a(var39).func_177984_a();
                        if (this.getBlock(var472) instanceof BlockPistonBase && canPushBlock.contains(this.getBlock(var472.func_177967_a(var39, -2))) && (this.getBlock(var472.func_177967_a(var39, -2).func_177984_a()) == Blocks.field_150350_a || this.getBlock(var472.func_177967_a(var39, -2).func_177984_a()) == Blocks.field_150451_bX)) {
                            if (((EnumFacing)this.getBlockState(var472).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var39) {
                                bl2 = false;
                            } else if (this.doPower(var472)) {
                                return true;
                            }
                        }
                    }
                }
                var472 = false;
            }
            for (EnumFacing var40 : EnumFacing.field_82609_l) {
                if (var40 != EnumFacing.DOWN) {
                    if (var40 == EnumFacing.UP) {
                        var472 = false;
                    } else {
                        BlockPos var48 = var1.func_177972_a(var40).func_177984_a();
                        if ((AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u <= -1.0 || AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u >= 2.0) && RebirthUtil.distanceToXZ((double)var48.func_177958_n() + 0.5, (double)var48.func_177952_p() + 0.5) < 2.6) {
                            bl2 = false;
                        } else if (this.attackCrystal(var48) && this.crystalCheck.getValue().booleanValue()) {
                            bl2 = false;
                        } else if (RebirthUtil.canPlace2(var48) && canPushBlock.contains(this.getBlock(var48.func_177967_a(var40, -2))) && canPushBlock.contains(this.getBlock(var48.func_177967_a(var40, -2).func_177984_a()))) {
                            if (RebirthUtil.canBlockFacing(var48) || !this.downPower(var48)) {
                                this.doPiston(var40, var48);
                                return true;
                            }
                            boolean var83 = false;
                            break;
                        }
                    }
                }
                boolean var48 = false;
            }
            if (this.getBlock(var1) == Blocks.field_150350_a && this.onlyBurrow.getValue().booleanValue() || !this.pullBack.getValue().booleanValue()) {
                if (this.autoDisable.getValue().booleanValue()) {
                    this.disable();
                }
                return true;
            }
            for (EnumFacing var41 : EnumFacing.field_82609_l) {
                if (var41 != EnumFacing.DOWN) {
                    if (var41 == EnumFacing.UP) {
                        boolean var48 = false;
                    } else {
                        BlockPos var49 = var1.func_177972_a(var41).func_177984_a();
                        for (EnumFacing var62 : EnumFacing.field_82609_l) {
                            if (this.getBlock(var49) instanceof BlockPistonBase && this.getBlock(var49.func_177972_a(var62)) == Blocks.field_150451_bX) {
                                if (((EnumFacing)this.getBlockState(var49).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() == var41) {
                                    this.mine(var49.func_177972_a(var62));
                                    if (this.autoDisable.getValue().booleanValue()) {
                                        this.disable();
                                    }
                                    return true;
                                }
                                bl = false;
                            }
                            bl = false;
                        }
                    }
                }
                boolean var49 = false;
            }
            for (EnumFacing var42 : EnumFacing.field_82609_l) {
                if (var42 != EnumFacing.DOWN) {
                    if (var42 == EnumFacing.UP) {
                        boolean var49 = false;
                    } else {
                        BlockPos var50 = var1.func_177972_a(var42).func_177984_a();
                        for (EnumFacing var63 : EnumFacing.field_82609_l) {
                            if (this.getBlock(var50) instanceof BlockPistonBase && this.getBlock(var50.func_177972_a(var63)) == Blocks.field_150350_a) {
                                if (((EnumFacing)this.getBlockState(var50).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var42) {
                                    bl = false;
                                } else if (this.attackCrystal(var50.func_177972_a(var63)) && this.crystalCheck.getValue().booleanValue()) {
                                    bl = false;
                                } else {
                                    if (!this.doPower(var50, var63)) {
                                        this.mine(var50.func_177972_a(var63));
                                        return true;
                                    }
                                    bl = false;
                                }
                            }
                            bl = false;
                        }
                    }
                }
                boolean var50 = false;
            }
            for (EnumFacing var43 : EnumFacing.field_82609_l) {
                if (var43 != EnumFacing.DOWN) {
                    if (var43 == EnumFacing.UP) {
                        boolean var50 = false;
                    } else {
                        boolean var83;
                        BlockPos var51 = var1.func_177972_a(var43).func_177984_a();
                        if ((AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u <= -1.0 || AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u >= 2.0) && RebirthUtil.distanceToXZ((double)var51.func_177958_n() + 0.5, (double)var51.func_177952_p() + 0.5) < 2.6) {
                            var83 = false;
                        } else if (this.attackCrystal(var51) && this.crystalCheck.getValue().booleanValue()) {
                            var83 = false;
                        } else if (RebirthUtil.canPlace2(var51)) {
                            if (!this.downPower(var51)) {
                                this.doPiston(var43, var51);
                                return true;
                            }
                            var83 = false;
                        }
                    }
                }
                boolean var51 = false;
            }
            boolean bl4 = false;
        } else {
            boolean var442;
            boolean var72;
            for (EnumFacing var6 : EnumFacing.field_82609_l) {
                if (var6 != EnumFacing.DOWN) {
                    if (var6 == EnumFacing.UP) {
                        boolean var51 = false;
                    } else {
                        BlockPos var72 = var1.func_177972_a(var6).func_177984_a();
                        if (this.getBlock(var72) instanceof BlockPistonBase && (AutoPush.mc.field_71441_e.func_175623_d(var72.func_177967_a(var6, -2)) && AutoPush.mc.field_71441_e.func_175623_d(var72.func_177967_a(var6, -2).func_177977_b()) || AutoPush.checkTarget(var72.func_177967_a(var6, 2), (Entity)var2))) {
                            if (((EnumFacing)this.getBlockState(var72).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var6) {
                                boolean var83 = false;
                            } else {
                                for (EnumFacing var11 : EnumFacing.field_82609_l) {
                                    if (this.getBlock(var72.func_177972_a(var11)) == Blocks.field_150451_bX) {
                                        if (this.mine.getValue().booleanValue()) {
                                            this.mine(var72.func_177972_a(var11));
                                        }
                                        if (this.autoDisable.getValue().booleanValue()) {
                                            this.disable();
                                        }
                                        return true;
                                    }
                                    boolean bl = false;
                                }
                            }
                        }
                    }
                }
                var72 = false;
            }
            for (EnumFacing var36 : EnumFacing.field_82609_l) {
                if (var36 != EnumFacing.DOWN) {
                    if (var36 == EnumFacing.UP) {
                        var72 = false;
                    } else {
                        BlockPos var442 = var1.func_177972_a(var36).func_177984_a();
                        if (this.getBlock(var442) instanceof BlockPistonBase && (AutoPush.mc.field_71441_e.func_175623_d(var442.func_177967_a(var36, -2)) && AutoPush.mc.field_71441_e.func_175623_d(var442.func_177967_a(var36, -2).func_177977_b()) || AutoPush.checkTarget(var442.func_177967_a(var36, 2), (Entity)var2))) {
                            if (((EnumFacing)this.getBlockState(var442).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var36) {
                                boolean var83 = false;
                            } else if (this.doPower(var442)) {
                                return true;
                            }
                        }
                    }
                }
                var442 = false;
            }
            for (EnumFacing var37 : EnumFacing.field_82609_l) {
                if (var37 != EnumFacing.DOWN) {
                    if (var37 == EnumFacing.UP) {
                        var442 = false;
                    } else {
                        boolean var83;
                        BlockPos var45 = var1.func_177972_a(var37).func_177984_a();
                        if ((AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u <= -1.0 || AutoPush.mc.field_71439_g.field_70163_u - var2.field_70163_u >= 2.0) && RebirthUtil.distanceToXZ((double)var45.func_177958_n() + 0.5, (double)var45.func_177952_p() + 0.5) < 2.6) {
                            var83 = false;
                        } else if (this.attackCrystal(var45) && this.crystalCheck.getValue().booleanValue()) {
                            var83 = false;
                        } else if (RebirthUtil.canPlace2(var45) && (AutoPush.mc.field_71441_e.func_175623_d(var45.func_177967_a(var37, -2)) && AutoPush.mc.field_71441_e.func_175623_d(var45.func_177967_a(var37, -2).func_177977_b()) || AutoPush.checkTarget(var45.func_177967_a(var37, 2), (Entity)var2)) && canPushBlock.contains(this.getBlock(var45.func_177967_a(var37, -2).func_177984_a()))) {
                            if (RebirthUtil.canBlockFacing(var45) || !this.downPower(var45)) {
                                this.doPiston(var37, var45);
                                return true;
                            }
                            boolean var71 = false;
                            break;
                        }
                    }
                }
                boolean bl = false;
            }
        }
        return false;
    }

    private static boolean checkEntity(BlockPos var0) {
        for (Entity var2 : AutoPush.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var0))) {
            if (!(var2 instanceof EntityPlayer)) continue;
            if (var2 != AutoPush.mc.field_71439_g) {
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private Boolean canPush(EntityPlayer var1) {
        int var2 = 0;
        if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t + 1.0, var1.field_70163_u + 0.5, var1.field_70161_v))) {
            ++var2;
        }
        if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t - 1.0, var1.field_70163_u + 0.5, var1.field_70161_v))) {
            ++var2;
        }
        if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t, var1.field_70163_u + 0.5, var1.field_70161_v + 1.0))) {
            ++var2;
        }
        if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t, var1.field_70163_u + 0.5, var1.field_70161_v - 1.0))) {
            ++var2;
        }
        if (AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t, var1.field_70163_u + 2.5, var1.field_70161_v))) {
            boolean var10;
            if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t, var1.field_70163_u + 0.5, var1.field_70161_v))) {
                return true;
            }
            if (var2 > this.surroundCheck.getValue() - 1) {
                var10 = true;
                boolean bl = false;
            } else {
                var10 = false;
            }
            return var10;
        }
        for (EnumFacing var6 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var6 != EnumFacing.UP) {
                if (var6 == EnumFacing.DOWN) {
                    bl = false;
                } else {
                    BlockPos var7 = RebirthUtil.getEntityPos((Entity)var1).func_177972_a(var6);
                    if (AutoPush.mc.field_71441_e.func_175623_d(var7) && AutoPush.mc.field_71441_e.func_175623_d(var7.func_177984_a()) || AutoPush.checkTarget(var7, (Entity)this.DisplayTarget)) {
                        boolean var9;
                        if (!AutoPush.mc.field_71441_e.func_175623_d(new BlockPos(var1.field_70165_t, var1.field_70163_u + 0.5, var1.field_70161_v))) {
                            return true;
                        }
                        if (var2 > this.surroundCheck.getValue() - 1) {
                            var9 = true;
                            boolean bl2 = false;
                        } else {
                            var9 = false;
                        }
                        return var9;
                    }
                }
            }
            bl = false;
        }
        return false;
    }

    private void doPiston(EnumFacing var1, BlockPos var2) {
        if (RebirthUtil.canPlace(var2, this.placeRange.getValue())) {
            if (this.rotate.getValue().booleanValue()) {
                RebirthUtil.facePlacePos(var2);
            }
            AutoPush.pistonFacing(var1);
            int var3 = AutoPush.mc.field_71439_g.field_71071_by.field_70461_c;
            RebirthUtil.doSwap(RebirthUtil.findHotbarClass(BlockPistonBase.class));
            BlockUtil.placeBlock(var2, EnumHand.MAIN_HAND, false, this.pistonPacket.getValue());
            RebirthUtil.doSwap(var3);
            if (this.rotate.getValue().booleanValue()) {
                RebirthUtil.facePlacePos(var2);
            }
            for (EnumFacing var7 : EnumFacing.field_82609_l) {
                if (this.getBlock(var2.func_177972_a(var7)) == Blocks.field_150451_bX) {
                    if (this.mine.getValue().booleanValue()) {
                        this.mine(var2.func_177972_a(var7));
                    }
                    if (this.autoDisable.getValue().booleanValue()) {
                        this.disable();
                    }
                    return;
                }
                boolean bl = false;
            }
            this.doPower(var2);
            boolean bl = false;
        }
    }

    private boolean doPower(BlockPos var1) {
        EnumFacing var2 = RebirthUtil.getBestNeighboring(var1, null);
        if (var2 != null) {
            if (this.attackCrystal(var1.func_177972_a(var2)) && this.crystalCheck.getValue().booleanValue()) {
                return true;
            }
            if (!this.doPower(var1, var2)) {
                return true;
            }
        }
        for (EnumFacing var6 : EnumFacing.field_82609_l) {
            if (this.attackCrystal(var1.func_177972_a(var6)) && this.crystalCheck.getValue().booleanValue()) {
                return true;
            }
            if (!this.doPower(var1, var6)) {
                return true;
            }
            boolean var10000 = false;
            var10000 = false;
        }
        return false;
    }

    private boolean checkPiston(BlockPos var1) {
        for (EnumFacing var5 : EnumFacing.field_82609_l) {
            boolean bl;
            if (var5 != EnumFacing.DOWN) {
                if (var5 == EnumFacing.UP) {
                    bl = false;
                } else {
                    BlockPos var6 = var1.func_177984_a();
                    if (this.getBlock(var6.func_177972_a(var5)) instanceof BlockPistonBase) {
                        if (((EnumFacing)this.getBlockState(var6.func_177972_a(var5)).func_177229_b((IProperty)BlockDirectional.field_176387_N)).func_176734_d() != var5) {
                            boolean bl2 = false;
                        } else {
                            for (EnumFacing var10 : EnumFacing.field_82609_l) {
                                if (this.getBlock(var6.func_177972_a(var5).func_177972_a(var10)) == Blocks.field_150451_bX && this.mine.getValue().booleanValue()) {
                                    this.mine(var6.func_177972_a(var5).func_177972_a(var10));
                                    if (this.autoDisable.getValue().booleanValue()) {
                                        this.disable();
                                    }
                                    return true;
                                }
                                boolean bl3 = false;
                            }
                        }
                    }
                }
            }
            bl = false;
        }
        return false;
    }

    static boolean checkTarget(BlockPos var0, Entity var1) {
        Vec3d[] var2;
        for (Vec3d var6 : var2 = RebirthUtil.getVarOffsets(0, 0, 0)) {
            BlockPos var7 = new BlockPos((Vec3i)var0).func_177963_a(var6.field_72450_a, var6.field_72448_b, var6.field_72449_c);
            for (Entity var9 : AutoPush.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(var7))) {
                if (var9 == var1) {
                    return true;
                }
                boolean bl = false;
            }
            boolean bl = false;
        }
        return false;
    }

    private IBlockState getBlockState(BlockPos var1) {
        return AutoPush.mc.field_71441_e.func_180495_p(var1);
    }

    private boolean attackCrystal(BlockPos var1) {
        for (Entity var3 : AutoPush.mc.field_71441_e.field_72996_f) {
            if (!(var3 instanceof EntityEnderCrystal) || var3.func_70011_f((double)var1.func_177958_n() + 0.5, (double)var1.func_177956_o(), (double)var1.func_177952_p() + 0.5) > 4.0 && this.crystalCheck.getValue().booleanValue()) continue;
            if (!(var3.func_70011_f((double)var1.func_177958_n() + 0.5, (double)var1.func_177956_o(), (double)var1.func_177952_p() + 0.5) > 2.0) || this.crystalCheck.getValue().booleanValue()) {
                RebirthUtil.attackCrystal(var3, (boolean)this.rotate.getValue(), (boolean)this.eatingPause.getValue());
                return true;
            }
            boolean bl = false;
        }
        return false;
    }

    private boolean doPower(BlockPos var1, EnumFacing var2) {
        if (!RebirthUtil.canPlace(var1.func_177972_a(var2), this.placeRange.getValue())) {
            return true;
        }
        int var3 = AutoPush.mc.field_71439_g.field_71071_by.field_70461_c;
        RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
        BlockUtil.placeBlock(var1.func_177972_a(var2), EnumHand.MAIN_HAND, this.rotate.getValue(), this.redStonePacket.getValue());
        RebirthUtil.doSwap(var3);
        return false;
    }

    private boolean downPower(BlockPos var1) {
        if (!RebirthUtil.canBlockFacing(var1)) {
            boolean var2 = true;
            for (EnumFacing var6 : EnumFacing.field_82609_l) {
                if (this.getBlock(var1.func_177972_a(var6)) == Blocks.field_150451_bX) {
                    var2 = false;
                    boolean var8 = false;
                    break;
                }
                boolean bl = false;
            }
            if (var2) {
                if (!RebirthUtil.canPlace(var1.func_177982_a(0, -1, 0), this.placeRange.getValue())) {
                    return true;
                }
                int var7 = AutoPush.mc.field_71439_g.field_71071_by.field_70461_c;
                RebirthUtil.doSwap(RebirthUtil.findHotbarBlock(Blocks.field_150451_bX));
                BlockUtil.placeBlock(var1.func_177982_a(0, -1, 0), EnumHand.MAIN_HAND, this.rotate.getValue(), this.redStonePacket.getValue());
                RebirthUtil.doSwap(var7);
            }
        }
        return false;
    }

    private static boolean isWeb(BlockPos var0) {
        boolean var10000;
        if (AutoPush.mc.field_71441_e.func_180495_p(var0).func_177230_c() == Blocks.field_150321_G && AutoPush.checkEntity(var0)) {
            var10000 = true;
            boolean bl = false;
        } else {
            var10000 = false;
        }
        return var10000;
    }

    private void mine(BlockPos var1) {
        RebirthUtil.mineBlock(var1);
    }

    public static void pistonFacing(EnumFacing var0) {
        if (var0 == EnumFacing.EAST) {
            RebirthUtil.faceYawAndPitch(-90.0f, 5.0f);
            boolean bl = false;
        } else if (var0 == EnumFacing.WEST) {
            RebirthUtil.faceYawAndPitch(90.0f, 5.0f);
            boolean bl = false;
        } else if (var0 == EnumFacing.NORTH) {
            RebirthUtil.faceYawAndPitch(180.0f, 5.0f);
            boolean bl = false;
        } else if (var0 == EnumFacing.SOUTH) {
            RebirthUtil.faceYawAndPitch(0.0f, 5.0f);
        }
    }
}

