/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MovementInput
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.movement;

import it.make.api.events.player.MoveEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.EntityUtil;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import net.minecraft.util.MovementInput;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Strafe
extends Module {
    Setting<MoveFix> moveFix = this.rother("MoveFix", MoveFix.NEW);
    Setting<Boolean> speed = this.rbool("Speed", true);

    public Strafe() {
        super("Strafe", "Better", Module.Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (this.moveFix.getValue() == MoveFix.OLD && Strafe.mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && Strafe.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) {
            Strafe.mc.field_71439_g.field_70159_w = 0.0;
            Strafe.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent event) {
        if (this.moveFix.getValue() == MoveFix.NEW && !RebirthUtil.isMoving()) {
            Strafe.mc.field_71439_g.field_70159_w = 0.0;
            Strafe.mc.field_71439_g.field_70179_y = 0.0;
        }
        if (!this.speed.getValue().booleanValue()) {
            return;
        }
        if (!(event.getStage() != 0 || Strafe.nullCheck() || Strafe.mc.field_71439_g.func_70093_af() || !Strafe.mc.field_71439_g.func_70051_ag() || !Strafe.mc.field_71439_g.field_70122_E || Strafe.mc.field_71439_g.func_70090_H() || Strafe.mc.field_71439_g.func_180799_ab() || Strafe.mc.field_71439_g.field_71158_b.field_192832_b == 0.0f && Strafe.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f)) {
            MovementInput movementInput = Strafe.mc.field_71439_g.field_71158_b;
            float moveForward = movementInput.field_192832_b;
            float moveStrafe = movementInput.field_78902_a;
            float rotationYaw = Strafe.mc.field_71439_g.field_70177_z;
            if ((double)moveForward == 0.0 && (double)moveStrafe == 0.0) {
                event.setX(0.0);
                event.setZ(0.0);
            } else {
                if ((double)moveForward != 0.0) {
                    if ((double)moveStrafe > 0.0) {
                        rotationYaw += (float)((double)moveForward > 0.0 ? -45 : 45);
                    } else if ((double)moveStrafe < 0.0) {
                        rotationYaw += (float)((double)moveForward > 0.0 ? 45 : -45);
                    }
                    moveStrafe = 0.0f;
                    if (moveForward != 0.0f) {
                        moveForward = (double)moveForward > 0.0 ? 1.0f : -1.0f;
                    }
                }
                moveStrafe = moveStrafe == 0.0f ? moveStrafe : ((double)moveStrafe > 0.0 ? 1.0f : -1.0f);
                event.setX((double)moveForward * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians(rotationYaw + 90.0f)) + (double)moveStrafe * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians(rotationYaw + 90.0f)));
                event.setZ((double)moveForward * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians(rotationYaw + 90.0f)) - (double)moveStrafe * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians(rotationYaw + 90.0f)));
            }
        }
    }

    static enum MoveFix {
        OLD,
        NEW,
        NONE;

    }
}

