/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.movement;

import it.make.api.events.network.PacketEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;
import it.make.modules.movement.Speed;
import java.util.HashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FastFall
extends Module {
    public Setting<Mode> mode = this.register(new Setting<Mode>("Type", Mode.Motion));
    public Setting<Integer> height = this.register(new Setting<Integer>("Height", 10, 1, 20));
    public Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", Boolean.valueOf(true), v -> this.mode.getValue() == Mode.Motion));
    public Setting<Float> timerVal = this.register(new Setting<Float>("TimerSpeed", Float.valueOf(2.5f), Float.valueOf(1.0f), Float.valueOf(10.0f), v -> this.mode.getValue() == Mode.Timer));
    public Setting<Float> motionVal = this.register(new Setting<Float>("MotionSpeed", Float.valueOf(2.5f), Float.valueOf(1.0f), Float.valueOf(10.0f), v -> this.mode.getValue() == Mode.Motion && this.noLag.getValue() != true));
    private final Timer lagTimer = new Timer();
    private boolean useTimer;

    public FastFall() {
        super("FastFall", "Makes you fall faster", Module.Category.MOVEMENT, true, false, false);
    }

    @Override
    public void onDisable() {
        Speed.mc.field_71428_T.field_194149_e = 50.0f;
        this.useTimer = false;
    }

    @Override
    public void onUpdate() {
        if (FastFall.fullNullCheck() || this.shouldReturn()) {
            return;
        }
    }

    @Override
    public void onTick() {
        if (this.height.getValue() > 0 && this.traceDown() > this.height.getValue() || FastFall.mc.field_71439_g.func_70094_T() || FastFall.mc.field_71439_g.func_70090_H() || FastFall.mc.field_71439_g.func_180799_ab() || FastFall.mc.field_71439_g.func_70617_f_() || !this.lagTimer.passedMs(1000L) || FastFall.fullNullCheck()) {
            FastFall.mc.field_71428_T.field_194149_e = 50.0f;
            return;
        }
        if (FastFall.mc.field_71439_g.field_70134_J) {
            return;
        }
        if (FastFall.mc.field_71439_g.field_70122_E && this.mode.getValue() == Mode.Motion) {
            FastFall.mc.field_71439_g.field_70181_x = this.noLag.getValue().booleanValue() ? (FastFall.mc.field_71439_g.field_70181_x -= (double)0.62f) : (FastFall.mc.field_71439_g.field_70181_x -= (double)this.motionVal.getValue().floatValue());
        }
        if (this.traceDown() != 0 && this.traceDown() <= this.height.getValue() && this.trace() && FastFall.mc.field_71439_g.field_70122_E) {
            FastFall.mc.field_71439_g.field_70159_w *= (double)0.05f;
            FastFall.mc.field_71439_g.field_70179_y *= (double)0.05f;
        }
        if (this.mode.getValue() == Mode.Timer) {
            if (!FastFall.mc.field_71439_g.field_70122_E) {
                if (FastFall.mc.field_71439_g.field_70181_x < 0.0 && this.useTimer) {
                    FastFall.mc.field_71428_T.field_194149_e = 50.0f / this.timerVal.getValue().floatValue();
                    return;
                }
                this.useTimer = false;
            } else {
                FastFall.mc.field_71439_g.field_70181_x = -0.08;
                this.useTimer = true;
            }
        }
        FastFall.mc.field_71428_T.field_194149_e = 50.0f;
    }

    private boolean shouldReturn() {
        return FastFall.mc.field_71439_g.func_184613_cA() || FastFall.isClipping() || FastFall.isInLiquid() || FastFall.mc.field_71439_g.func_70617_f_() || FastFall.mc.field_71439_g.field_71075_bZ.field_75100_b || FastFall.mc.field_71439_g.field_70181_x > 0.0 || FastFall.mc.field_71474_y.field_74314_A.func_151470_d() || FastFall.mc.field_71439_g.func_70094_T() || FastFall.mc.field_71439_g.field_70145_X || !FastFall.mc.field_71439_g.field_70122_E || Speed.INSTANCE.isEnabled();
    }

    @SubscribeEvent
    public void onPacket(PacketEvent event) {
        if (!FastFall.fullNullCheck() && event.getPacket() instanceof SPacketPlayerPosLook) {
            this.lagTimer.reset();
        }
    }

    private int traceDown() {
        int y;
        int retval = 0;
        for (int tracey = y = (int)Math.round(FastFall.mc.field_71439_g.field_70163_u) - 1; tracey >= 0; --tracey) {
            RayTraceResult trace = FastFall.mc.field_71441_e.func_72901_a(FastFall.mc.field_71439_g.func_174791_d(), new Vec3d(FastFall.mc.field_71439_g.field_70165_t, (double)tracey, FastFall.mc.field_71439_g.field_70161_v), false);
            if (trace != null && trace.field_72313_a == RayTraceResult.Type.BLOCK) {
                return retval;
            }
            ++retval;
        }
        return retval;
    }

    private boolean trace() {
        AxisAlignedBB bbox = FastFall.mc.field_71439_g.func_174813_aQ();
        Vec3d basepos = bbox.func_189972_c();
        double minX = bbox.field_72340_a;
        double minZ = bbox.field_72339_c;
        double maxX = bbox.field_72336_d;
        double maxZ = bbox.field_72334_f;
        HashMap<Vec3d, Vec3d> positions = new HashMap<Vec3d, Vec3d>();
        positions.put(basepos, new Vec3d(basepos.field_72450_a, basepos.field_72448_b - 1.0, basepos.field_72449_c));
        positions.put(new Vec3d(minX, basepos.field_72448_b, minZ), new Vec3d(minX, basepos.field_72448_b - 1.0, minZ));
        positions.put(new Vec3d(maxX, basepos.field_72448_b, minZ), new Vec3d(maxX, basepos.field_72448_b - 1.0, minZ));
        positions.put(new Vec3d(minX, basepos.field_72448_b, maxZ), new Vec3d(minX, basepos.field_72448_b - 1.0, maxZ));
        positions.put(new Vec3d(maxX, basepos.field_72448_b, maxZ), new Vec3d(maxX, basepos.field_72448_b - 1.0, maxZ));
        for (Vec3d key : positions.keySet()) {
            RayTraceResult result = FastFall.mc.field_71441_e.func_72901_a(key, (Vec3d)positions.get(key), true);
            if (result == null || result.field_72313_a != RayTraceResult.Type.BLOCK) continue;
            return false;
        }
        IBlockState state = FastFall.mc.field_71441_e.func_180495_p(new BlockPos(FastFall.mc.field_71439_g.field_70165_t, FastFall.mc.field_71439_g.field_70163_u - 1.0, FastFall.mc.field_71439_g.field_70161_v));
        return state.func_177230_c() == Blocks.field_150350_a;
    }

    public static boolean isClipping() {
        return !FastFall.mc.field_71441_e.func_184144_a((Entity)FastFall.mc.field_71439_g, FastFall.mc.field_71439_g.func_174813_aQ()).isEmpty();
    }

    public static boolean isInLiquid() {
        if (FastFall.mc.field_71439_g.field_70143_R >= 3.0f) {
            return false;
        }
        boolean inLiquid = false;
        AxisAlignedBB bb = FastFall.mc.field_71439_g.func_184187_bx() != null ? FastFall.mc.field_71439_g.func_184187_bx().func_174813_aQ() : FastFall.mc.field_71439_g.func_174813_aQ();
        int y = (int)bb.field_72338_b;
        for (int x = MathHelper.func_76128_c((double)bb.field_72340_a); x < MathHelper.func_76128_c((double)bb.field_72336_d) + 1; ++x) {
            for (int z = MathHelper.func_76128_c((double)bb.field_72339_c); z < MathHelper.func_76128_c((double)bb.field_72334_f) + 1; ++z) {
                Block block = FastFall.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
                if (block instanceof BlockAir) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                inLiquid = true;
            }
        }
        return inLiquid;
    }

    public static enum Mode {
        Motion,
        Timer;

    }
}

