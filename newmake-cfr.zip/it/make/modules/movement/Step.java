/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules.movement;

import it.make.api.setting.Setting;
import it.make.modules.Module;

public class Step
extends Module {
    public Setting<Float> height = this.rfloa("Height", Float.valueOf(2.0f), Float.valueOf(1.0f), Float.valueOf(2.5f));
    public static Step INSTANCE = new Step();

    public Step() {
        super("VanillaStep", "Step", Module.Category.MOVEMENT);
        INSTANCE = this;
    }

    @Override
    public void onDisable() {
        this.setHeightDefault();
    }

    @Override
    public void onUpdate() {
        if (Step.mc.field_71439_g == null) {
            return;
        }
        if (!Step.mc.field_71439_g.field_70122_E || Step.mc.field_71439_g.field_70134_J || Step.mc.field_71439_g.field_71075_bZ.field_75100_b || Step.mc.field_71439_g.func_70090_H() || Step.mc.field_71439_g.func_180799_ab() || Step.mc.field_71439_g.func_184218_aH()) {
            this.setHeightDefault();
        } else {
            this.setHeightValue();
        }
    }

    public void setHeightDefault() {
        Step.mc.field_71439_g.field_70138_W = 0.6f;
    }

    public void setHeightValue() {
        Step.mc.field_71439_g.field_70138_W = this.height.getValue().floatValue();
    }
}

