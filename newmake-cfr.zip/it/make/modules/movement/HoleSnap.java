/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.MobEffects
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.MovementInput
 *  net.minecraft.util.MovementInputFromOptions
 *  net.minecraft.util.Timer
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec2f
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.World
 *  net.minecraftforge.client.event.InputUpdateEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.movement;

import it.make.api.events.network.PacketEvent;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.Timer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HoleSnap
extends Module {
    public static final List<BlockPos> holeBlocks = Arrays.asList(new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(-1, 0, 0), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1));
    private static final BlockPos[] surroundOffset = new BlockPos[]{new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0)};
    public static HoleSnap INSTANCE;
    private final Setting<Integer> range = this.rinte("Range", 5, 1, 50);
    private final Setting<Float> timer = this.rfloa("Timer", Float.valueOf(1.6f), Float.valueOf(1.0f), Float.valueOf(8.0f));
    private final Setting<Integer> timeoutTicks = this.rinte("TimeOutTicks", 10, 0, 30);
    boolean resetMove = false;
    private BlockPos holePos;
    private int stuckTicks;
    private int enabledTicks;

    public HoleSnap() {
        super("HoleSnap", "IQ", Module.Category.MOVEMENT);
        INSTANCE = this;
    }

    public static boolean is2HoleB(BlockPos pos) {
        return HoleSnap.is2Hole(pos) != null;
    }

    public static BlockPos is2Hole(BlockPos pos) {
        if (HoleSnap.isHole(pos)) {
            return null;
        }
        BlockPos blockpos2 = null;
        int size = 0;
        int size2 = 0;
        if (HoleSnap.mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150350_a) {
            return null;
        }
        for (BlockPos bPos : holeBlocks) {
            if (HoleSnap.mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)bPos)).func_177230_c() != Blocks.field_150350_a || pos.func_177971_a((Vec3i)bPos).equals((Object)new BlockPos(bPos.func_177958_n(), bPos.func_177956_o() - 1, bPos.func_177952_p()))) continue;
            blockpos2 = pos.func_177971_a((Vec3i)bPos);
            ++size;
        }
        if (size == 1) {
            for (BlockPos bPoss : holeBlocks) {
                if (HoleSnap.mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)bPoss)).func_177230_c() != Blocks.field_150357_h && HoleSnap.mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)bPoss)).func_177230_c() != Blocks.field_150343_Z) continue;
                ++size2;
            }
            for (BlockPos bPoss : holeBlocks) {
                if (HoleSnap.mc.field_71441_e.func_180495_p(blockpos2.func_177971_a((Vec3i)bPoss)).func_177230_c() != Blocks.field_150357_h && HoleSnap.mc.field_71441_e.func_180495_p(blockpos2.func_177971_a((Vec3i)bPoss)).func_177230_c() != Blocks.field_150343_Z) continue;
                ++size2;
            }
        }
        if (size2 == 8) {
            return blockpos2;
        }
        return null;
    }

    public static boolean isHole(BlockPos blockPos) {
        return !(HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 1, 0)) != BlockResistance.Blank || HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 0, 0)) != BlockResistance.Blank || HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 2, 0)) != BlockResistance.Blank || HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 0, -1)) != BlockResistance.Resistant && HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 0, -1)) != BlockResistance.Unbreakable || HoleSnap.getBlockResistance(blockPos.func_177982_a(1, 0, 0)) != BlockResistance.Resistant && HoleSnap.getBlockResistance(blockPos.func_177982_a(1, 0, 0)) != BlockResistance.Unbreakable || HoleSnap.getBlockResistance(blockPos.func_177982_a(-1, 0, 0)) != BlockResistance.Resistant && HoleSnap.getBlockResistance(blockPos.func_177982_a(-1, 0, 0)) != BlockResistance.Unbreakable || HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 0, 1)) != BlockResistance.Resistant && HoleSnap.getBlockResistance(blockPos.func_177982_a(0, 0, 1)) != BlockResistance.Unbreakable || HoleSnap.getBlockResistance(blockPos.func_177963_a(0.5, 0.5, 0.5)) != BlockResistance.Blank || HoleSnap.getBlockResistance(blockPos.func_177982_a(0, -1, 0)) != BlockResistance.Resistant && HoleSnap.getBlockResistance(blockPos.func_177982_a(0, -1, 0)) != BlockResistance.Unbreakable);
    }

    public static BlockResistance getBlockResistance(BlockPos block) {
        if (HoleSnap.mc.field_71441_e.func_175623_d(block)) {
            return BlockResistance.Blank;
        }
        if (!(HoleSnap.mc.field_71441_e.func_180495_p(block).func_185887_b((World)HoleSnap.mc.field_71441_e, block) == -1.0f || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150343_Z) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150467_bQ) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150381_bn) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150477_bB))) {
            return BlockResistance.Breakable;
        }
        if (HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150343_Z) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150467_bQ) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150381_bn) || HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150477_bB)) {
            return BlockResistance.Resistant;
        }
        if (HoleSnap.mc.field_71441_e.func_180495_p(block).func_177230_c().equals(Blocks.field_150357_h)) {
            return BlockResistance.Unbreakable;
        }
        return null;
    }

    @Override
    public void onEnable() {
        this.resetMove = false;
    }

    @Override
    public void onDisable() {
        if (this.resetMove) {
            HoleSnap.mc.field_71439_g.field_70159_w = 0.0;
            HoleSnap.mc.field_71439_g.field_70179_y = 0.0;
        }
        this.holePos = null;
        this.stuckTicks = 0;
        this.enabledTicks = 0;
        HoleSnap.mc.field_71428_T.field_194149_e = 50.0f;
    }

    public double getSpeed(Entity entity) {
        return Math.hypot(entity.field_70159_w, entity.field_70179_y);
    }

    private boolean isFlying(EntityPlayer player) {
        return player.func_184613_cA() || player.field_71075_bZ.field_75100_b;
    }

    @SubscribeEvent
    public void onReceivePacket(PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            this.disable();
        }
    }

    @SubscribeEvent
    public void onInput(InputUpdateEvent event) {
        if (event.getMovementInput() instanceof MovementInputFromOptions && this.holePos != null) {
            MovementInput movementInput = event.getMovementInput();
            this.resetMove(movementInput);
        }
    }

    private void resetMove(MovementInput movementInput) {
        movementInput.field_192832_b = 0.0f;
        movementInput.field_78902_a = 0.0f;
        movementInput.field_187255_c = false;
        movementInput.field_187256_d = false;
        movementInput.field_187257_e = false;
        movementInput.field_187258_f = false;
    }

    private boolean isCentered(Entity entity, BlockPos pos) {
        double d = (double)pos.func_177958_n() + 0.31;
        double d2 = (double)pos.func_177958_n() + 0.69;
        double d3 = entity.field_70165_t;
        if (d > d3) {
            return false;
        }
        if (d3 > d2) {
            return false;
        }
        d = (double)pos.func_177952_p() + 0.31;
        d2 = (double)pos.func_177952_p() + 0.69;
        d3 = entity.field_70161_v;
        return d <= d3 && d3 <= d2;
    }

    @Override
    public void onTick() {
        ++this.enabledTicks;
        if (this.enabledTicks > this.timeoutTicks.getValue() - 1) {
            this.disable();
            return;
        }
        if (HoleSnap.mc.field_71439_g.func_70089_S()) {
            if (!this.isFlying((EntityPlayer)HoleSnap.mc.field_71439_g)) {
                EntityPlayerSP entityPlayerSP = HoleSnap.mc.field_71439_g;
                double currentSpeed = this.getSpeed((Entity)entityPlayerSP);
                if (this.shouldDisable(currentSpeed)) {
                    this.disable();
                    return;
                }
                BlockPos blockPos = this.getHole();
                if (blockPos != null) {
                    if (HoleSnap.mc.field_71439_g.field_70163_u - (double)blockPos.func_177956_o() < 0.5 && HoleSnap.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n() <= 0.65 && HoleSnap.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n() >= 0.35 && HoleSnap.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p() <= 0.65 && HoleSnap.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p() >= 0.35) {
                        this.disable();
                        return;
                    }
                    if (HoleSnap.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n() <= 0.65 && HoleSnap.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n() >= 0.35 && HoleSnap.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p() <= 0.65 && HoleSnap.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p() >= 0.35) {
                        HoleSnap.mc.field_71439_g.field_70159_w = 0.0;
                        HoleSnap.mc.field_71439_g.field_70179_y = 0.0;
                        return;
                    }
                    this.resetMove = true;
                    Timer timer = HoleSnap.mc.field_71428_T;
                    Float f = this.timer.getValue();
                    timer.field_194149_e = 50.0f / f.floatValue();
                    if (!this.isCentered((Entity)HoleSnap.mc.field_71439_g, blockPos)) {
                        Vec3d playerPos = HoleSnap.mc.field_71439_g.func_174791_d();
                        Vec3d targetPos = new Vec3d((double)blockPos.func_177958_n() + 0.5, HoleSnap.mc.field_71439_g.field_70163_u, (double)blockPos.func_177952_p() + 0.5);
                        float rotation = this.getRotationTo((Vec3d)playerPos, (Vec3d)targetPos).field_189982_i;
                        float yawRad = rotation / 180.0f * (float)Math.PI;
                        double dist = playerPos.func_72438_d(targetPos);
                        EntityPlayerSP entityPlayerSP2 = HoleSnap.mc.field_71439_g;
                        double baseSpeed = this.applySpeedPotionEffects((EntityLivingBase)entityPlayerSP2);
                        double speed = HoleSnap.mc.field_71439_g.field_70122_E ? baseSpeed : Math.max(currentSpeed + 0.02, baseSpeed);
                        double cappedSpeed = Math.min(speed, dist);
                        HoleSnap.mc.field_71439_g.field_70159_w = (double)(-((float)Math.sin(yawRad))) * cappedSpeed;
                        HoleSnap.mc.field_71439_g.field_70179_y = (double)((float)Math.cos(yawRad)) * cappedSpeed;
                        this.stuckTicks = HoleSnap.mc.field_71439_g.field_70123_F ? (this.stuckTicks = this.stuckTicks + 1) : 0;
                    }
                } else {
                    this.disable();
                }
            } else {
                this.disable();
            }
        } else {
            this.disable();
        }
    }

    public double applySpeedPotionEffects(EntityLivingBase entityLivingBase) {
        PotionEffect potionEffect = entityLivingBase.func_70660_b(MobEffects.field_76424_c);
        return potionEffect == null ? 0.2873 : 0.2873 * this.getSpeedEffectMultiplier(entityLivingBase);
    }

    private double getSpeedEffectMultiplier(EntityLivingBase entityLivingBase) {
        PotionEffect potionEffect = entityLivingBase.func_70660_b(MobEffects.field_76424_c);
        return potionEffect == null ? 1.0 : 1.0 + ((double)potionEffect.func_76458_c() + 1.0) * 0.2;
    }

    private Vec2f getRotationTo(Vec3d posFrom, Vec3d posTo) {
        Vec3d vec3d = posTo.func_178788_d(posFrom);
        return this.getRotationFromVec(vec3d);
    }

    private Vec2f getRotationFromVec(Vec3d vec) {
        double d = vec.field_72450_a;
        double d2 = vec.field_72449_c;
        double xz = Math.hypot(d, d2);
        d2 = vec.field_72449_c;
        double d3 = vec.field_72450_a;
        double yaw = this.normalizeAngle(Math.toDegrees(Math.atan2(d2, d3)) - 90.0);
        double pitch = this.normalizeAngle(Math.toDegrees(-Math.atan2(vec.field_72448_b, xz)));
        return new Vec2f((float)yaw, (float)pitch);
    }

    private double normalizeAngle(double angleIn) {
        double angle = angleIn;
        if ((angle %= 360.0) < -180.0) {
            angle += 360.0;
        }
        return angle;
    }

    private boolean shouldDisable(double currentSpeed) {
        BlockPos blockPos = this.holePos;
        if (blockPos != null) {
            if (HoleSnap.mc.field_71439_g.field_70163_u < (double)blockPos.func_177956_o()) {
                return true;
            }
            if (HoleSnap.is2HoleB(blockPos) && this.toBlockPos(this.toVec3dCenter((Vec3i)HoleSnap.mc.field_71439_g.func_180425_c())).equals((Object)blockPos)) {
                return true;
            }
        }
        if (this.stuckTicks > 5 && currentSpeed < 0.1) {
            return true;
        }
        if (currentSpeed >= 0.01) {
            return false;
        }
        EntityPlayerSP entityPlayerSP = HoleSnap.mc.field_71439_g;
        return this.checkHole((Entity)entityPlayerSP) != HoleType.NONE;
    }

    private BlockPos getHole() {
        if (HoleSnap.mc.field_71439_g.field_70173_aa % 10 == 0 && !this.getFlooredPosition((Entity)HoleSnap.mc.field_71439_g).equals((Object)this.holePos)) {
            return this.findHole();
        }
        BlockPos blockPos = this.holePos;
        if (blockPos != null) {
            return blockPos;
        }
        blockPos = this.findHole();
        return blockPos;
    }

    private BlockPos findHole() {
        BlockPos blockPos3;
        Pair<Double, BlockPos> closestHole = new Pair<Double, BlockPos>(69.69, BlockPos.field_177992_a);
        EntityPlayerSP entityPlayerSP = HoleSnap.mc.field_71439_g;
        BlockPos playerPos = this.getFlooredPosition((Entity)entityPlayerSP);
        Integer ceilRange = this.range.getValue();
        BlockPos blockPos2 = playerPos.func_177982_a(ceilRange.intValue(), -1, ceilRange.intValue());
        BlockPos object = playerPos.func_177982_a(-ceilRange.intValue(), -1, -ceilRange.intValue());
        List<BlockPos> posList = this.getBlockPositionsInArea(blockPos2, object);
        Iterator<BlockPos> iterator2 = posList.iterator();
        while (iterator2.hasNext()) {
            BlockPos pos;
            EntityPlayerSP entityPlayerSP2 = HoleSnap.mc.field_71439_g;
            BlockPos blockPos = iterator2.next();
            double dist = this.distanceTo((Entity)entityPlayerSP2, (Vec3i)blockPos);
            if (!(dist <= (double)this.range.getValue().intValue()) || dist > closestHole.getLeft()) continue;
            int n2 = 0;
            while (n2 < 6 && HoleSnap.mc.field_71441_e.func_175623_d((pos = blockPos.func_177982_a(0, -n2++, 0)).func_177984_a())) {
                if (!HoleSnap.is2HoleB(pos) && this.checkHole(pos) == HoleType.NONE) continue;
                closestHole = new Pair<Double, BlockPos>(dist, pos);
            }
        }
        if (closestHole.getRight() != BlockPos.field_177992_a) {
            this.holePos = object = closestHole.getRight();
            blockPos3 = object;
        } else {
            blockPos3 = null;
        }
        return blockPos3;
    }

    public BlockPos getFlooredPosition(Entity entity) {
        return new BlockPos((int)Math.floor(entity.field_70165_t), (int)Math.floor(entity.field_70163_u), (int)Math.floor(entity.field_70161_v));
    }

    public HoleType checkHole(Entity entity) {
        return this.checkHole(this.getFlooredPosition(entity));
    }

    public HoleType checkHole(BlockPos pos) {
        if (!(HoleSnap.mc.field_71441_e.func_175623_d(pos) && HoleSnap.mc.field_71441_e.func_175623_d(pos.func_177984_a()) && HoleSnap.mc.field_71441_e.func_175623_d(pos.func_177984_a().func_177984_a()))) {
            return HoleType.NONE;
        }
        HoleType type = HoleType.BEDROCK;
        for (BlockPos offset : surroundOffset) {
            Block block = HoleSnap.mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)offset)).func_177230_c();
            if (this.checkBlock(block)) continue;
            type = HoleType.NONE;
            break;
        }
        return type;
    }

    private boolean checkBlock(Block block) {
        return block == Blocks.field_150357_h || block == Blocks.field_150343_Z || block == Blocks.field_150477_bB || block == Blocks.field_150467_bQ;
    }

    public double distanceTo(Entity entity, Vec3i vec3i) {
        double xDiff = (double)vec3i.func_177958_n() + 0.5 - entity.field_70165_t;
        double yDiff = (double)vec3i.func_177956_o() + 0.5 - entity.field_70163_u;
        double zDiff = (double)vec3i.func_177952_p() + 0.5 - entity.field_70161_v;
        return Math.sqrt(xDiff * xDiff + yDiff * yDiff + zDiff * zDiff);
    }

    public BlockPos toBlockPos(Vec3d vec) {
        int n = (int)Math.floor(vec.field_72450_a);
        int n2 = (int)Math.floor(vec.field_72448_b);
        return new BlockPos(n, n2, (int)Math.floor(vec.field_72449_c));
    }

    public Vec3d toVec3dCenter(Vec3i vec3i) {
        return this.toVec3dCenter(vec3i, 0.0, 0.0, 0.0);
    }

    public Vec3d toVec3dCenter(Vec3i vec3i, double xOffset, double yOffset, double zOffset) {
        return new Vec3d((double)vec3i.func_177958_n() + 0.5 + xOffset, (double)vec3i.func_177956_o() + 0.5 + yOffset, (double)vec3i.func_177952_p() + 0.5 + zOffset);
    }

    public List<BlockPos> getBlockPositionsInArea(BlockPos pos1, BlockPos pos2) {
        int minX = Math.min(pos1.func_177958_n(), pos2.func_177958_n());
        int maxX = Math.max(pos1.func_177958_n(), pos2.func_177958_n());
        int minY = Math.min(pos1.func_177956_o(), pos2.func_177956_o());
        int maxY = Math.max(pos1.func_177956_o(), pos2.func_177956_o());
        int minZ = Math.min(pos1.func_177952_p(), pos2.func_177952_p());
        int maxZ = Math.max(pos1.func_177952_p(), pos2.func_177952_p());
        return this.getBlockPos(minX, maxX, minY, maxY, minZ, maxZ);
    }

    private List<BlockPos> getBlockPos(int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
        ArrayList<BlockPos> returnList = new ArrayList<BlockPos>();
        int n = minX;
        if (n <= maxX) {
            int x;
            do {
                int z;
                x = n++;
                int n2 = minZ;
                if (n2 > maxZ) continue;
                do {
                    int y;
                    z = n2++;
                    int n3 = minY;
                    if (n3 > maxY) continue;
                    do {
                        y = n3++;
                        returnList.add(new BlockPos(x, y, z));
                    } while (y != maxY);
                } while (z != maxZ);
            } while (x != maxX);
        }
        return returnList;
    }

    public static enum BlockResistance {
        Blank,
        Breakable,
        Resistant,
        Unbreakable;

    }

    public static enum HoleType {
        NONE,
        OBBY,
        BEDROCK;

    }

    public static class Pair<L, R> {
        L left;
        R right;

        public Pair(L l, R r) {
            this.left = l;
            this.right = r;
        }

        public L getLeft() {
            return this.left;
        }

        public R getRight() {
            return this.right;
        }
    }
}

