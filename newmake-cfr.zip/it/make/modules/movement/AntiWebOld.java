/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.movement;

import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.MathUtil;
import it.make.modules.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiWebOld
extends Module {
    private final Setting<Mode> mode = this.rother("Mode", Mode.Ignore);
    private final Setting<Float> speed = this.rfloa("Factor", Float.valueOf(10.0f), Float.valueOf(1.0f), Float.valueOf(10.0f), v -> this.mode.getValue() == Mode.Fast1);

    public AntiWebOld() {
        super(new I18NInfo("AntiWebOld").bind(EnumI18N.Chinese, "\u53cd\u8718\u86db\u4fa0"), "Stops you being slowed down by webs", Module.Category.MISC, true, false, false);
    }

    @SubscribeEvent
    public void onUpdate(UpdateWalkingPlayerEvent event) {
        if (AntiWebOld.mc.field_71439_g.field_70134_J) {
            switch (this.mode.getValue()) {
                case Ignore: {
                    AntiWebOld.mc.field_71439_g.field_70134_J = false;
                    break;
                }
                case Fast1: {
                    if (!AntiWebOld.mc.field_71474_y.field_74311_E.func_151470_d()) break;
                    double[] calc = MathUtil.directionSpeed((double)this.speed.getValue().floatValue() / 10.0);
                    AntiWebOld.mc.field_71439_g.field_70159_w = calc[0];
                    AntiWebOld.mc.field_71439_g.field_70179_y = calc[1];
                    AntiWebOld.mc.field_71439_g.field_70181_x -= (double)(this.speed.getValue().floatValue() / 10.0f);
                    break;
                }
                case Fast2: {
                    AntiWebOld.mc.field_71439_g.field_70181_x -= 1.0;
                }
            }
        }
    }

    static enum Mode {
        Ignore,
        Fast1,
        Fast2;

    }
}

