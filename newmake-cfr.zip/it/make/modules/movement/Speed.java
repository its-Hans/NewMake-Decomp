/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.network.play.server.SPacketEntityVelocity
 *  net.minecraft.network.play.server.SPacketExplosion
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.movement;

import it.make.api.events.network.PacketEvent;
import it.make.api.events.player.MoveEvent;
import it.make.api.events.player.PushEvent;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import java.util.Objects;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Speed
extends Module {
    public static Speed INSTANCE = new Speed();
    private final Setting<Boolean> jump = this.register(new Setting<Boolean>("Jump", false));
    private final Setting<Boolean> inWater = this.register(new Setting<Boolean>("InWater", false));
    private final Setting<Double> strafeSpeed = this.register(new Setting<Double>("StrafeSpeed", 278.5, 100.0, 1000.0));
    private final Setting<Boolean> explosions = this.register(new Setting<Boolean>("Explosions", true));
    private final Setting<Boolean> velocity = this.register(new Setting<Boolean>("Velocity", true));
    private final Setting<Float> multiplier = this.register(new Setting<Float>("H-Factor", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(5.0f)));
    private final Setting<Float> vertical = this.register(new Setting<Float>("V-Factor", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(5.0f)));
    private final Setting<Integer> coolDown = this.register(new Setting<Integer>("CoolDown", 400, 0, 5000));
    private final Setting<Integer> pauseTime = this.register(new Setting<Integer>("PauseTime", 400, 0, 1000));
    private final Setting<Boolean> directional = this.register(new Setting<Boolean>("Directional", false));
    private final Setting<Double> cap = this.register(new Setting<Double>("Cap", 10.0, 0.0, 10.0));
    private final Setting<Boolean> scaleCap = this.register(new Setting<Boolean>("ScaleCap", false));
    private final Setting<Boolean> slow = this.register(new Setting<Boolean>("Slowness", true));
    private final Setting<Boolean> modify = this.register(new Setting<Boolean>("Modify", false));
    private final Setting<Double> xzFactor = this.register(new Setting<Double>("XZ-Factor", Double.valueOf(1.0), Double.valueOf(0.0), Double.valueOf(5.0), v -> this.modify.getValue()));
    private final Setting<Double> yFactor = this.register(new Setting<Double>("Y-Factor", Double.valueOf(1.0), Double.valueOf(0.0), Double.valueOf(5.0), v -> this.modify.getValue()));
    private final Setting<Boolean> debug = this.register(new Setting<Boolean>("Debug", false));
    private final Setting<Boolean> noEventTest1 = this.rbool("NoEventTest1", false);
    private final Setting<Boolean> noEventTest2 = this.rbool("NoEventTest2", false);
    private final Setting<Boolean> noEventTest3 = this.rbool("NoEventTest3", false);
    private final Setting<Boolean> noEventTest4 = this.rbool("NoEventTest4", false);
    private final Setting<Boolean> noIdk1 = this.rbool("NoIdk1", false);
    private final Timer expTimer = new Timer();
    private boolean stop;
    private double speed;
    private double distance;
    private int stage;
    private double lastExp;
    private boolean boost;

    public Speed() {
        super("Speed", "3ar", Module.Category.MOVEMENT);
        INSTANCE = this;
    }

    @SubscribeEvent(priority=EventPriority.HIGHEST)
    public void onReceivePacket(PacketEvent.Receive event) {
        if (this.noEventTest1.getValue().booleanValue()) {
            return;
        }
        if (Speed.fullNullCheck()) {
            return;
        }
        if (event.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity packet2 = (SPacketEntityVelocity)event.getPacket();
            if (packet2.func_149412_c() == Speed.mc.field_71439_g.func_145782_y() && !this.directional.getValue().booleanValue() && this.velocity.getValue().booleanValue()) {
                double speed = Math.sqrt(packet2.func_149411_d() * packet2.func_149411_d() + packet2.func_149409_f() * packet2.func_149409_f()) / 8000.0;
                this.lastExp = this.expTimer.passedMs(this.coolDown.getValue().intValue()) ? speed : speed - this.lastExp;
                double d = this.lastExp;
                if (this.lastExp > 0.0) {
                    if (this.debug.getValue().booleanValue()) {
                        Speed.notiMessage("boost");
                    }
                    this.expTimer.reset();
                    this.speed += this.lastExp * (double)this.multiplier.getValue().floatValue();
                    this.distance += this.lastExp * (double)this.multiplier.getValue().floatValue();
                    if (Speed.mc.field_71439_g.field_70181_x > 0.0 && this.vertical.getValue().floatValue() != 0.0f) {
                        Speed.mc.field_71439_g.field_70181_x *= (double)this.vertical.getValue().floatValue();
                    }
                }
            }
        } else if (event.getPacket() instanceof SPacketPlayerPosLook) {
            this.distance = 0.0;
            this.speed = 0.0;
            this.stage = 4;
        } else if (event.getPacket() instanceof SPacketExplosion && this.explosions.getValue().booleanValue() && RebirthUtil.isMoving()) {
            BlockPos blockPos;
            SPacketExplosion packet = (SPacketExplosion)event.getPacket();
            BlockPos pos = new BlockPos(packet.func_149148_f(), packet.func_149143_g(), packet.func_149145_h());
            if (!(!(Speed.mc.field_71439_g.func_174818_b(blockPos) < 100.0) || this.directional.getValue().booleanValue() && RebirthUtil.isInMovementDirection(packet.func_149148_f(), packet.func_149143_g(), packet.func_149145_h()))) {
                double speed = Math.sqrt(packet.func_149149_c() * packet.func_149149_c() + packet.func_149147_e() * packet.func_149147_e());
                this.lastExp = this.expTimer.passedMs(this.coolDown.getValue().intValue()) ? speed : speed - this.lastExp;
                double d = this.lastExp;
                if (this.lastExp > 0.0) {
                    if (this.debug.getValue().booleanValue()) {
                        Speed.notiMessage("boost");
                    }
                    this.expTimer.reset();
                    this.speed += this.lastExp * (double)this.multiplier.getValue().floatValue();
                    this.distance += this.lastExp * (double)this.multiplier.getValue().floatValue();
                    if (Speed.mc.field_71439_g.field_70181_x > 0.0) {
                        Speed.mc.field_71439_g.field_70181_x *= (double)this.vertical.getValue().floatValue();
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onPush(PushEvent event) {
        if (this.noEventTest2.getValue().booleanValue()) {
            return;
        }
        if (event.getStage() == 0 && event.entity.equals((Object)Speed.mc.field_71439_g)) {
            event.x = -event.x * 0.0;
            event.y = -event.y * 0.0;
            event.z = -event.z * 0.0;
        } else if (event.getStage() == 1) {
            event.setCanceled(true);
        } else if (event.getStage() == 2 && Speed.mc.field_71439_g != null && Speed.mc.field_71439_g.equals((Object)event.entity)) {
            event.setCanceled(true);
        }
    }

    @Override
    public String getInfo() {
        return "3arthh4ck";
    }

    @Override
    public void onEnable() {
        this.speed = RebirthUtil.getSpeed();
        this.distance = RebirthUtil.getDistance2D();
        this.stage = 4;
    }

    private boolean isFlying(EntityPlayer player) {
        return player.func_184613_cA() || player.field_71075_bZ.field_75100_b;
    }

    @SubscribeEvent
    public void Update(UpdateWalkingPlayerEvent event) {
        if (this.noEventTest3.getValue().booleanValue()) {
            return;
        }
        if (this.expTimer.passedMs(this.pauseTime.getValue().intValue())) {
            this.distance = RebirthUtil.getDistance2D();
        }
    }

    @SubscribeEvent
    public void Move(MoveEvent event) {
        if (this.noEventTest4.getValue().booleanValue()) {
            return;
        }
        if (Speed.fullNullCheck()) {
            return;
        }
        if (this.isFlying((EntityPlayer)Speed.mc.field_71439_g)) {
            return;
        }
        if (!this.inWater.getValue().booleanValue() && (RebirthUtil.inLiquid() || RebirthUtil.inLiquid(true)) || Speed.mc.field_71439_g.func_70617_f_() || Speed.mc.field_71439_g.func_70094_T()) {
            this.stop = true;
            return;
        }
        if (this.stop) {
            this.stop = false;
            return;
        }
        if (!RebirthUtil.isMoving()) {
            Speed.mc.field_71439_g.field_70159_w = 0.0;
            Speed.mc.field_71439_g.field_70179_y = 0.0;
        }
        this.playerMove(event);
        if (this.modify.getValue().booleanValue()) {
            event.setX(event.getX() * this.xzFactor.getValue());
            event.setY(event.getY() * this.yFactor.getValue());
            event.setZ(event.getZ() * this.xzFactor.getValue());
        }
    }

    public double getCap() {
        int amplifier;
        double ret = this.cap.getValue();
        if (!this.scaleCap.getValue().booleanValue()) {
            return ret;
        }
        if (Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = Objects.requireNonNull(Speed.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            ret *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (this.slow.getValue().booleanValue() && Speed.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = Objects.requireNonNull(Speed.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d)).func_76458_c();
            ret /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return ret;
    }

    public void playerMove(MoveEvent event) {
        if (this.noIdk1.getValue().booleanValue()) {
            return;
        }
        if (!RebirthUtil.isMoving()) {
            return;
        }
        if (this.stage == 1) {
            this.speed = 1.35 * RebirthUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0) - 0.01;
        } else if (this.stage == 2) {
            if (this.jump.getValue().booleanValue() || Speed.mc.field_71474_y.field_74314_A.func_151470_d()) {
                double yMotion;
                Speed.mc.field_71439_g.field_70181_x = yMotion = 0.3999 + RebirthUtil.getJumpSpeed();
                event.setY(yMotion);
                this.speed *= this.boost ? 1.6835 : 1.395;
            }
        } else if (this.stage == 3) {
            this.speed = this.distance - 0.66 * (this.distance - RebirthUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0));
            this.boost = !this.boost;
        } else {
            if ((Speed.mc.field_71441_e.func_184144_a(null, Speed.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, Speed.mc.field_71439_g.field_70181_x, 0.0)).size() > 0 || Speed.mc.field_71439_g.field_70124_G) && this.stage > 0) {
                this.stage = RebirthUtil.isMoving() ? 1 : 0;
            }
            this.speed = this.distance - this.distance / 159.0;
        }
        this.speed = Math.min(this.speed, this.getCap());
        this.speed = Math.max(this.speed, RebirthUtil.getSpeed(this.slow.getValue(), this.strafeSpeed.getValue() / 1000.0));
        RebirthUtil.strafe(event, this.speed);
        ++this.stage;
    }
}

