/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package it.make.modules;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.api.events.client.ClientEvent;
import it.make.api.events.render.Render2DEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.features.Feature;
import it.make.features.commands.Command;
import it.make.modules.client.NotifyModule;
import java.util.function.Predicate;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;

public class Module
extends Feature {
    public final I18NInfo info;
    public final String defaultName;
    private final String description;
    private final Category category;
    public Setting<Boolean> enabled = this.register(new Setting<Boolean>("Enabled", false));
    public Setting<Boolean> drawn = this.register(new Setting<Boolean>("Drawn", true));
    public Setting<Bind> bind = this.register(new Setting<Bind>("Keybind", new Bind(-1)));
    public Setting<String> displayName;
    public boolean hasListener;
    public boolean alwaysListening;
    public boolean hidden;
    public float arrayListOffset = 0.0f;
    public float arrayListVOffset = 0.0f;
    public float offset;
    public float vOffset;
    public boolean sliding;

    public Module(I18NInfo info, String description, Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
        super(Client.i18NManager.addI18N(info));
        this.defaultName = info.defaultName;
        this.displayName = this.register(new Setting<String>("DisplayName", this.getName()));
        this.description = description;
        this.category = category;
        this.hasListener = hasListener;
        this.hidden = hidden;
        this.alwaysListening = alwaysListening;
        this.info = info;
    }

    public Module(I18NInfo info, String description, Category category) {
        this(info, description, category, true, false, false);
    }

    public Module(String name, String description, Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
        this(new I18NInfo(name), description, category, hasListener, hidden, alwaysListening);
    }

    public Module(String name, String description, Category category) {
        this(new I18NInfo(name), description, category);
    }

    public <T> Setting<T> rother(String settingname, T defaultVal) {
        return this.register(new Setting<T>(settingname, defaultVal));
    }

    public <T> Setting<T> rother(String settingname, T defaultVal, Predicate<T> visibleat) {
        return this.register(new Setting<T>(settingname, defaultVal, visibleat));
    }

    public Setting<Bind> rbind(String settingname, Bind defaultVal) {
        return this.register(new Setting<Bind>(settingname, defaultVal));
    }

    public Setting<Bind> rbind(String settingname, Bind defaultVal, Predicate<Bind> visibleat) {
        return this.register(new Setting<Bind>(settingname, defaultVal, visibleat));
    }

    public Setting<Boolean> rbool(String settingname, Boolean defaultVal) {
        return this.register(new Setting<Boolean>(settingname, defaultVal));
    }

    public Setting<Boolean> rbool(String settingname, Boolean defaultVal, Predicate<Boolean> visibleat) {
        return this.register(new Setting<Boolean>(settingname, defaultVal, visibleat));
    }

    public Setting<String> rstri(String settingname, String defaultVal) {
        return this.register(new Setting<String>(settingname, defaultVal));
    }

    public Setting<String> rstri(String settingname, String defaultVal, Predicate<String> visibleat) {
        return this.register(new Setting<String>(settingname, defaultVal, visibleat));
    }

    public Setting<Integer> rcolo(String settingname) {
        return this.register(new Setting<Integer>(settingname, 0, 0, 255));
    }

    public Setting<Integer> rcolo(String settingname, Predicate<Integer> visibleat) {
        return this.register(new Setting<Integer>(settingname, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), visibleat));
    }

    public Setting<Integer> rinte(String settingname, Integer defaultVal, Integer min, Integer max) {
        return this.register(new Setting<Integer>(settingname, defaultVal, min, max));
    }

    public Setting<Integer> rinte(String settingname, Integer defaultVal, Integer min, Integer max, Predicate<Integer> visibleat) {
        return this.register(new Setting<Integer>(settingname, defaultVal, min, max, visibleat));
    }

    public Setting<Double> rdoub(String settingname, Double defaultVal, Double min, Double max) {
        return this.register(new Setting<Double>(settingname, defaultVal, min, max));
    }

    public Setting<Double> rdoub(String settingname, Double defaultVal, Double min, Double max, Predicate<Double> visibleat) {
        return this.register(new Setting<Double>(settingname, defaultVal, min, max, visibleat));
    }

    public Setting<Float> rfloa(String settingname, Float defaultVal, Float min, Float max) {
        return this.register(new Setting<Float>(settingname, defaultVal, min, max));
    }

    public Setting<Float> rfloa(String settingname, Float defaultVal, Float min, Float max, Predicate<Float> visibleat) {
        return this.register(new Setting<Float>(settingname, defaultVal, min, max, visibleat));
    }

    public boolean isSliding() {
        return this.sliding;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onToggle() {
    }

    public void onLoad() {
    }

    public void onTick() {
    }

    public void onLogin() {
    }

    public void onLogout() {
    }

    public void onUpdate() {
    }

    public void onRender2D(Render2DEvent event) {
    }

    public void onRender3D(Render3DEvent event) {
    }

    public void onUnload() {
    }

    public String getDisplayInfo() {
        return null;
    }

    public boolean isOn() {
        return this.enabled.getValue();
    }

    public boolean isOff() {
        return this.enabled.getValue() == false;
    }

    public void setEnabled(boolean enabled) {
        if (enabled) {
            this.enable();
        } else {
            this.disable();
        }
    }

    public void enable() {
        this.enable(true);
    }

    public void enable(boolean isNoti) {
        NotifyModule noti2;
        this.enabled.setValue(Boolean.TRUE);
        this.onToggle();
        this.onEnable();
        if (isNoti && this.isDrawn() && (noti2 = NotifyModule.getNoti()).isEnabled()) {
            noti2.pushEnable(this.getDisplayName());
            noti2.putModuleToggle(true, this);
        }
        if (this.isOn() && this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.register((Object)this);
        }
    }

    public void disable() {
        this.disable(true);
    }

    public void disable(boolean isNoti) {
        NotifyModule noti;
        if (this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.unregister((Object)this);
        }
        this.enabled.setValue(false);
        if (isNoti && this.isDrawn() && (noti = NotifyModule.getNoti()).isEnabled()) {
            noti.pushDisable(this.getDisplayName());
            noti.putModuleToggle(false, this);
        }
        this.onToggle();
        this.onDisable();
    }

    public void toggle() {
        ClientEvent event = new ClientEvent(!this.isEnabled() ? 1 : 0, this);
        MinecraftForge.EVENT_BUS.post((Event)event);
        if (!event.isCanceled()) {
            this.setEnabled(!this.isEnabled());
        }
    }

    public String getDisplayName() {
        return this.displayName.getValue();
    }

    public void sendModuleMessage(String message) {
        Command.sendSilentMessage(ChatFormatting.GRAY + "[" + ChatFormatting.RESET + this.getDisplayName() + ChatFormatting.GRAY + "] " + message);
    }

    public void setDisplayName(String name) {
        Module module = Client.moduleManager.getModuleByDisplayName(name);
        Module originalModule = Client.moduleManager.getModuleByName(name);
        if (module == null && originalModule == null) {
            Command.sendMessage(this.getDisplayName() + ", name: " + this.getName() + ", has been renamed to: " + name);
            this.displayName.setValue(name);
            return;
        }
        Command.sendMessage(ChatFormatting.RED + "A module of this name already exists.");
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isDrawn() {
        return this.drawn.getValue();
    }

    public void setDrawn(boolean drawn) {
        this.drawn.setValue(drawn);
    }

    public Category getCategory() {
        return this.category;
    }

    public String getInfo() {
        return null;
    }

    public Bind getBind() {
        return this.bind.getValue();
    }

    public void setBind(int key) {
        this.bind.setValue(new Bind(key));
    }

    public boolean listening() {
        return this.hasListener && this.isOn() || this.alwaysListening;
    }

    public String getFullArrayString() {
        return this.getDisplayName() + ChatFormatting.GRAY + (this.getDisplayInfo() != null ? " [" + ChatFormatting.WHITE + this.getDisplayInfo() + ChatFormatting.GRAY + "]" : "");
    }

    public static void notiMessage(String message) {
        NotifyModule.getNoti().pushString(message);
    }

    public String getI18NName() {
        return Client.i18NManager.getModuleI18N(Client.i18NManager.current, this.getDefaultName());
    }

    public final String getDefaultName() {
        return this.defaultName;
    }

    public final void refreshI18N() {
        if (this.info.i18ns.containsValue(this.displayName.getValue())) {
            this.displayName.setValue(this.getI18NName());
        }
    }

    public static enum Category {
        COMBAT("Combat"),
        MISC("Misc"),
        RENDER("Render"),
        MOVEMENT("Movement"),
        PLAYER("Player"),
        CLIENT("Client"),
        FUN("Fun");

        private final String name;

        private Category(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }
}

