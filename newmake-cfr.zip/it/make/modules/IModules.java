/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules;

import it.make.modules.Module;
import it.make.modules.client.ClickGui;
import it.make.modules.client.HUD;
import it.make.modules.client.NotifyModule;
import it.make.modules.client.Targets;
import it.make.modules.combat.AntiPush;
import it.make.modules.combat.Aura;
import it.make.modules.combat.AutoCNM;
import it.make.modules.combat.AutoPush;
import it.make.modules.combat.AutoTrap;
import it.make.modules.combat.CevSelect;
import it.make.modules.combat.Crit;
import it.make.modules.combat.KeyPushMake;
import it.make.modules.combat.NewPush;
import it.make.modules.combat.Offhand;
import it.make.modules.combat.PullCrystal;
import it.make.modules.combat.Surround;
import it.make.modules.fun.AimAssist;
import it.make.modules.fun.AntiGay;
import it.make.modules.fun.BlatantClicker;
import it.make.modules.fun.Eagle;
import it.make.modules.fun.FastPlace;
import it.make.modules.fun.Ghost;
import it.make.modules.fun.LegitAutoArmor;
import it.make.modules.fun.PotatoAura;
import it.make.modules.fun.PotatoDetect;
import it.make.modules.fun.Reach;
import it.make.modules.fun.RightClicker;
import it.make.modules.fun.VClip;
import it.make.modules.misc.AutoPlace;
import it.make.modules.misc.CityTest;
import it.make.modules.misc.FakeEffects;
import it.make.modules.misc.FakePlayer;
import it.make.modules.misc.InstantMine;
import it.make.modules.misc.Kit;
import it.make.modules.misc.MiddleClick;
import it.make.modules.misc.NoAbortEat;
import it.make.modules.misc.NoCAnimation;
import it.make.modules.misc.NoTryUseItemOnBlock;
import it.make.modules.misc.PacketTranslation;
import it.make.modules.misc.SpoofGround;
import it.make.modules.misc.Suffix;
import it.make.modules.movement.AntiWebOld;
import it.make.modules.movement.FastFall;
import it.make.modules.movement.HoleSnap;
import it.make.modules.movement.Speed;
import it.make.modules.movement.Step;
import it.make.modules.movement.Strafe;
import it.make.modules.movement.TestPacketFly;
import it.make.modules.player.AutoExp;
import it.make.modules.player.Blink;
import it.make.modules.player.BowExploit;
import it.make.modules.player.BowTweaks;
import it.make.modules.player.KeyBurrow;
import it.make.modules.player.KuraMineTest;
import it.make.modules.player.NewBurrow;
import it.make.modules.player.OldPacketMine;
import it.make.modules.player.OldTimerBypass;
import it.make.modules.player.PacketMine;
import it.make.modules.player.PlayerTweaks;
import it.make.modules.player.Shake;
import it.make.modules.player.StayBurrow;
import it.make.modules.render.Animations;
import it.make.modules.render.BlockHighlight;
import it.make.modules.render.BreakESP;
import it.make.modules.render.Chams;
import it.make.modules.render.CustomRender;
import it.make.modules.render.ESP;
import it.make.modules.render.NameTags;
import it.make.modules.render.NoPotionRender;
import it.make.modules.render.PlaceRender;
import it.make.modules.render.Trajectories;
import it.make.modules.render.ViewModel;
import java.util.Arrays;
import java.util.List;

public interface IModules {
    public static List<Module> getModules() {
        return Arrays.asList(new HUD(), new BlockHighlight(), new FakePlayer(), new MiddleClick(), new Offhand(), new Surround(), new AutoTrap(), new Crit(), new StayBurrow(), new ESP(), new Trajectories(), new AntiPush(), new AutoPush(), new PullCrystal(), new Suffix(), new BowTweaks(), new Kit(), new PacketMine(), new Animations(), new OldPacketMine(), new CustomRender(), new PlaceRender(), new KeyPushMake(), new SpoofGround(), new CevSelect(), new AutoPlace(), new InstantMine(), new Shake(), new Ghost(), new OldTimerBypass(), new NotifyModule(), new Targets(), new Blink(), new HoleSnap(), new NewBurrow(), new Speed(), new AutoCNM(), new AutoExp(), new BreakESP(), new KeyBurrow(), new Step(), new TestPacketFly(), new NewPush(), new AntiWebOld(), new BowExploit(), new NoTryUseItemOnBlock(), new Aura(), new NoCAnimation(), new Strafe(), new PlayerTweaks(), new PacketTranslation(), new NoPotionRender(), new FastFall(), new Chams(), new NameTags(), new ViewModel(), new KuraMineTest(), new AimAssist(), new BlatantClicker(), new FakeEffects(), new ClickGui(), new CityTest(), new NoAbortEat(), new RightClicker(), new FastPlace(), new Eagle(), new AntiGay(), new VClip(), new PotatoAura(), new PotatoDetect(), new Reach(), new LegitAutoArmor());
    }
}

