/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SpoofGround
extends Module {
    public static SpoofGround INSTANCE = new SpoofGround();
    Setting<Boolean> grPacket = this.rbool("GroundPacket", true);

    public SpoofGround() {
        super(new I18NInfo("SpoofGround").bind(EnumI18N.Chinese, "\u4e0d\u77e5\u9053"), "AntiPush Or AntiHunger", Module.Category.PLAYER);
        INSTANCE = this;
    }

    @SubscribeEvent(priority=EventPriority.LOW)
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer && SpoofGround.mc.field_71439_g.field_70122_E) {
            if (this.grPacket.getValue().booleanValue()) {
                ((CPacketPlayer)event.getPacket()).field_149474_g = false;
            } else {
                SpoofGround.mc.field_71439_g.field_70122_E = false;
            }
        }
    }
}

