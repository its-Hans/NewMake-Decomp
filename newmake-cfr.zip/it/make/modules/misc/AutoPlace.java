/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemShulkerBox
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.block.SelfDamageBlockEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.api.utils.second.m4ke.render.BlockAnimationMake;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.two.BlockUtil;
import it.make.modules.Module;
import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoPlace
extends Module {
    public Setting<BlockMode> blockMode = this.rother("BlockMode", BlockMode.Shulker);
    public Setting<Boolean> rotate = this.rbool("Rotate", true);
    public Setting<Boolean> packet = this.rbool("Packet", false);
    public Setting<Boolean> swing = this.rbool("Swing", true);
    public Setting<Boolean> swapBack = this.rbool("SwapBack", true);
    public Setting<Integer> delay = this.rinte("Delay", 10, 0, 500);
    public Setting<Boolean> render = this.rbool("Render", true);
    public Setting<Integer> red = this.rinte("Red", 0, 0, 255, v -> this.render.getValue());
    public Setting<Integer> green = this.rinte("Green", 0, 0, 255, v -> this.render.getValue());
    public Setting<Integer> blue = this.rinte("Blue", 150, 0, 255, v -> this.render.getValue());
    public Setting<Integer> alpha = this.rinte("Alpha", 240, 0, 255, v -> this.render.getValue());
    BlockPos select;
    Timer timer = new Timer();
    BlockAnimationMake ba = BlockAnimationMake.getNormalAnimation();

    public AutoPlace() {
        super(new I18NInfo("AutoPlace").bind(EnumI18N.Chinese, "\u81ea\u52a8\u653e\u7f6e"), "idk", Module.Category.MISC);
        this.select(null);
    }

    @Override
    public void onDisable() {
        this.resets();
    }

    @Override
    public void onUpdate() {
        if (!this.timer.passedMs(this.delay.getValue().intValue())) {
            return;
        }
        this.timer.reset();
        if (AutoPlace.fullNullCheck()) {
            this.disable();
            return;
        }
        if (this.select == null) {
            return;
        }
        if (!RebirthUtil.canReplace(this.select)) {
            return;
        }
        int slot = this.findBlock(this.blockMode.getValue());
        if (slot == -1) {
            return;
        }
        int old = AutoPlace.mc.field_71439_g.field_71071_by.field_70461_c;
        UtilsRewrite.UInventory.heldItemChange(slot, true, false, true);
        BlockUtil.placeSync(this.select, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), this.swing.getValue());
        if (this.swapBack.getValue().booleanValue()) {
            UtilsRewrite.UInventory.heldItemChange(old, true, false, true);
        }
    }

    public Color getColor() {
        return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.render.getValue().booleanValue()) {
            return;
        }
        this.ba.doDraw();
    }

    public int findBlock(BlockMode block) {
        block4: for (int x = 0; x < 9; ++x) {
            Item item = AutoPlace.mc.field_71439_g.field_71071_by.func_70301_a(x).func_77973_b();
            switch (block) {
                case Shulker: {
                    if (!(item instanceof ItemShulkerBox)) continue block4;
                    return x;
                }
                case EnderChest: {
                    if (item != Item.func_150898_a((Block)Blocks.field_150477_bB)) continue block4;
                    return x;
                }
            }
        }
        return -1;
    }

    @SubscribeEvent
    public void onDmgBlock(SelfDamageBlockEvent.Port2 event) {
        this.select(event.pos);
    }

    public void resets() {
        this.timer.reset();
        this.select(null);
    }

    @Override
    public void onTick() {
        this.ba.setColor(this.getColor());
        this.ba.doUpdate();
    }

    @Override
    public String getDisplayInfo() {
        if (this.select == null) {
            return "waiting";
        }
        return UtilsRewrite.UBlock.getPosString(this.select);
    }

    public void select(BlockPos pos) {
        this.ba.select(pos);
        this.select = pos;
    }

    static enum BlockMode {
        Shulker,
        EnderChest;

    }
}

