/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules.misc;

import it.make.api.setting.Setting;
import it.make.modules.Module;

public class NoAbortEat
extends Module {
    public static NoAbortEat INSTANCE = new NoAbortEat();
    public Setting<Boolean> onlyMainHand = this.rbool("OnlyMainHand", true);

    public NoAbortEat() {
        super("NoAbortEat", "IDK", Module.Category.MISC);
        INSTANCE = this;
    }
}

