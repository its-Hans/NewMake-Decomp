/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.entity.Entity
 *  net.minecraft.world.GameType
 *  net.minecraft.world.World
 */
package it.make.modules.misc;

import com.mojang.authlib.GameProfile;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.world.GameType;
import net.minecraft.world.World;

public class FakePlayer
extends Module {
    private final Setting<Integer> setHealth = this.register(new Setting<Integer>("SetHealth", 20, 1, 20));
    public Setting<String> fName = this.register(new Setting<String>("Name", "ImWindsFlow", "Fake player's name"));
    private EntityOtherPlayerMP clonedPlayer;

    public FakePlayer() {
        super(new I18NInfo("FakePlayer").bind(EnumI18N.Chinese, "\u5047\u4eba"), "Spawns FP", Module.Category.MISC, true, false, false);
    }

    @Override
    public void onEnable() {
        if (FakePlayer.mc.field_71439_g != null && !FakePlayer.mc.field_71439_g.field_70128_L) {
            this.clonedPlayer = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, new GameProfile(UUID.fromString("a3ca166d-c5f1-3d5a-baac-b18a5b38d4cd"), this.fName.getValue()));
            this.clonedPlayer.func_82149_j((Entity)FakePlayer.mc.field_71439_g);
            this.clonedPlayer.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
            this.clonedPlayer.field_70177_z = FakePlayer.mc.field_71439_g.field_70177_z;
            this.clonedPlayer.field_70125_A = FakePlayer.mc.field_71439_g.field_70125_A;
            this.clonedPlayer.field_71071_by.func_70455_b(FakePlayer.mc.field_71439_g.field_71071_by);
            this.clonedPlayer.func_71033_a(GameType.SURVIVAL);
            this.clonedPlayer.func_70606_j((float)this.setHealth.getValue().intValue());
            FakePlayer.mc.field_71441_e.func_73027_a(-404, (Entity)this.clonedPlayer);
            this.clonedPlayer.func_70636_d();
            return;
        }
        this.disable();
    }

    @Override
    public void onDisable() {
        if (FakePlayer.mc.field_71441_e == null) {
            return;
        }
        FakePlayer.mc.field_71441_e.func_73028_b(-404);
    }

    @Override
    public String getDisplayInfo() {
        return this.fName.getValue();
    }

    @Override
    public void onUnload() {
        this.disableFP();
    }

    @Override
    public void onLogout() {
        this.disableFP();
    }

    private void disableFP() {
        if (this.isEnabled()) {
            this.disable();
        }
    }
}

