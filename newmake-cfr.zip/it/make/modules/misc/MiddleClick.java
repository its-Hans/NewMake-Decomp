/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemEnderPearl
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.world.World
 *  org.lwjgl.input.Mouse
 */
package it.make.modules.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.utils.InventoryUtil;
import it.make.features.commands.Command;
import it.make.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import org.lwjgl.input.Mouse;

public class MiddleClick
extends Module {
    private boolean clicked = false;

    public MiddleClick() {
        super(new I18NInfo("MiddleClick").bind(EnumI18N.Chinese, "\u4e2d\u952e"), "", Module.Category.MISC);
    }

    @Override
    public void onUpdate() {
        if (Mouse.isButtonDown((int)2)) {
            if (!this.clicked && MiddleClick.mc.field_71462_r == null) {
                this.doFriend();
            }
            this.clicked = true;
        } else {
            this.clicked = false;
        }
    }

    private void doFriend() {
        Entity entity;
        RayTraceResult result = MiddleClick.mc.field_71476_x;
        if (result != null && result.field_72313_a == RayTraceResult.Type.ENTITY && (entity = result.field_72308_g) instanceof EntityPlayer) {
            if (Client.friendManager.isFriend(entity.func_70005_c_())) {
                Client.friendManager.removeFriend(entity.func_70005_c_());
                Command.sendMessage(ChatFormatting.RED + entity.func_70005_c_() + ChatFormatting.RED + " has been unfriended.");
            } else {
                Client.friendManager.addFriend(entity.func_70005_c_());
                Command.sendMessage(ChatFormatting.AQUA + entity.func_70005_c_() + ChatFormatting.AQUA + " has been friended.");
            }
        } else {
            this.throwPearl();
        }
        this.clicked = true;
    }

    private void throwPearl() {
        int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
        boolean offhand = MiddleClick.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi;
        boolean bl = offhand;
        if (pearlSlot != -1 || offhand) {
            int oldslot = MiddleClick.mc.field_71439_g.field_71071_by.field_70461_c;
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(pearlSlot, false);
            }
            MiddleClick.mc.field_71442_b.func_187101_a((EntityPlayer)MiddleClick.mc.field_71439_g, (World)MiddleClick.mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(oldslot, false);
            }
        }
    }
}

