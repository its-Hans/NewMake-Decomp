/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockObsidian
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.input.Mouse
 */
package it.make.modules.misc;

import it.make.api.events.block.SelfDamageBlockEvent;
import it.make.api.events.network.PacketEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.api.utils.BlockUtil;
import it.make.api.utils.InventoryUtil;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RenderUtil;
import it.make.modules.Module;
import java.awt.Color;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

public class InstantMine
extends Module {
    private final Timer breakSuccess = new Timer();
    private static InstantMine INSTANCE = new InstantMine();
    Setting<Boolean> creativeMode = this.rbool("CreativeMode", true);
    Setting<Boolean> ghostHand = this.rbool("GhostHand", true, v -> this.creativeMode.getValue());
    Setting<Boolean> render = this.rbool("Fill", true);
    Setting<Integer> falpha = this.rinte("FillAlpha", 30, 0, 255, v -> this.render.getValue());
    Setting<Boolean> render2 = this.rbool("Box", true);
    Setting<Integer> balpha = this.rinte("BoxAlpha", 100, 0, 255, v -> this.render2.getValue());
    private final Setting<Boolean> crystal = this.rbool("Crystal", true);
    private final Setting<Boolean> crystalp = this.rbool("Place", true, v -> this.crystal.getValue());
    public final Setting<Boolean> attackcrystal = this.rbool("Attack", true, v -> this.crystal.getValue());
    public final Setting<Bind> bind = this.rbind("ObbyBind", new Bind(-1), v -> this.crystal.getValue());
    public Setting<Boolean> db = this.rbool("Silent2Break", true);
    public final Setting<Float> health = this.rfloa("SilentHP", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(36.0f), v -> this.db.getValue());
    Setting<Integer> red = this.rinte("Red", 255, 0, 255);
    Setting<Integer> green = this.rinte("Green", 255, 0, 255);
    Setting<Integer> blue = this.rinte("Blue", 255, 0, 255);
    Setting<Integer> alpha = this.rinte("BoxAlpha", 150, 0, 255);
    Setting<Integer> alpha2 = this.rinte("FillAlpha", 70, 0, 255);
    private final List<Block> godBlocks = Arrays.asList(Blocks.field_150350_a, Blocks.field_150356_k, Blocks.field_150353_l, Blocks.field_150358_i, Blocks.field_150355_j, Blocks.field_150357_h, Blocks.field_150349_c, Blocks.field_150329_H, Blocks.field_150328_O, Blocks.field_150327_N, Blocks.field_150457_bL, Blocks.field_150345_g);
    private boolean cancelStart = false;
    private boolean empty = false;
    private EnumFacing facing;
    public static BlockPos breakPos;
    public static BlockPos breakPos2;
    int slotMain2;
    int swithc2;
    double manxi = 0.0;
    double manxi2 = 0.0;
    public final Timer imerS = new Timer();
    public final Timer imerS2 = new Timer();
    static int ticked;

    public InstantMine() {
        super("InstantMine", "Crazy packet miner.", Module.Category.MISC, true, false, false);
        this.setInstance();
    }

    public static InstantMine getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new InstantMine();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onTick() {
        if (!InstantMine.mc.field_71439_g.func_184812_l_()) {
            this.slotMain2 = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
            if (ticked <= 86 && ticked >= 0) {
                ++ticked;
            }
            if (breakPos2 == null) {
                this.manxi2 = 0.0;
            }
            if (breakPos2 != null && (ticked >= 65 || ticked >= 20 && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150477_bB)) {
                if (InstantMine.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() != Items.field_151153_ao && InstantMine.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() != Items.field_185161_cS) {
                    if (this.isHealth()) {
                        if (InventoryUtil.getItemHotbar(Items.field_151046_w) != -1 && this.db.getValue().booleanValue()) {
                            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(InventoryUtil.getItemHotbars(Items.field_151046_w)));
                            this.swithc2 = 1;
                            ++ticked;
                        }
                    } else if (this.swithc2 == 1) {
                        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
                        this.swithc2 = 0;
                    }
                } else if (!Mouse.isButtonDown((int)1)) {
                    if (this.isHealth()) {
                        if (InventoryUtil.getItemHotbar(Items.field_151046_w) != -1 && this.db.getValue().booleanValue()) {
                            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(InventoryUtil.getItemHotbars(Items.field_151046_w)));
                            this.swithc2 = 1;
                            ++ticked;
                        }
                    } else if (this.swithc2 == 1) {
                        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
                        this.swithc2 = 0;
                    }
                } else if (this.swithc2 == 1) {
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
                    this.swithc2 = 0;
                }
            }
            if (breakPos2 != null && InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_177230_c() == Blocks.field_150350_a) {
                if (this.swithc2 == 1) {
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
                    this.swithc2 = 0;
                }
                breakPos2 = null;
                this.manxi2 = 0.0;
                ticked = 0;
            }
            if (ticked == 0) {
                this.manxi2 = 0.0;
                breakPos2 = null;
            }
            if (ticked >= 140) {
                if (this.swithc2 == 1) {
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.slotMain2));
                    this.swithc2 = 0;
                }
                this.manxi2 = 0.0;
                breakPos2 = null;
                ticked = 0;
            }
            if (breakPos != null && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150350_a && breakPos2 == null) {
                ticked = 0;
            }
            if (!InstantMine.fullNullCheck() && this.creativeMode.getValue().booleanValue() && this.cancelStart) {
                if (this.crystal.getValue().booleanValue() && this.attackcrystal.getValue().booleanValue() && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150350_a) {
                    InstantMine.attackcrystal();
                }
                if (this.bind.getValue().isDown() && this.crystal.getValue().booleanValue() && InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1 && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150350_a) {
                    int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
                    int old = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
                    this.switchToSlot(obbySlot);
                    BlockUtil.placeBlock(breakPos, EnumHand.MAIN_HAND, false, true, false);
                    this.switchToSlot(old);
                }
                if (InventoryUtil.getItemHotbar(Items.field_185158_cP) != -1 && this.crystal.getValue().booleanValue() && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150343_Z) {
                    if (this.empty) {
                        BlockUtil.placeCrystalOnBlock(breakPos, EnumHand.MAIN_HAND, true, false, true);
                    } else if (!this.crystalp.getValue().booleanValue()) {
                        BlockUtil.placeCrystalOnBlock(breakPos, EnumHand.MAIN_HAND, true, false, true);
                    }
                }
                if (!this.godBlocks.contains(InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
                    int slotMain;
                    if (InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() != Blocks.field_150321_G) {
                        if (this.ghostHand.getValue().booleanValue() && InventoryUtil.getItemHotbar(Items.field_151046_w) != -1 && InventoryUtil.getItemHotbars(Items.field_151046_w) != -1) {
                            slotMain = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
                            if (InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() == Blocks.field_150343_Z) {
                                if (!this.breakSuccess.passedMs(1234L)) {
                                    return;
                                }
                                InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151046_w);
                                InstantMine.mc.field_71442_b.func_78765_e();
                                InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                                InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = slotMain;
                                InstantMine.mc.field_71442_b.func_78765_e();
                                return;
                            }
                            InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151046_w);
                            InstantMine.mc.field_71442_b.func_78765_e();
                            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                            InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = slotMain;
                            InstantMine.mc.field_71442_b.func_78765_e();
                            return;
                        }
                    } else if (this.ghostHand.getValue().booleanValue() && InventoryUtil.getItemHotbar(Items.field_151048_u) != -1 && InventoryUtil.getItemHotbars(Items.field_151048_u) != -1) {
                        slotMain = InstantMine.mc.field_71439_g.field_71071_by.field_70461_c;
                        InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = InventoryUtil.getItemHotbar(Items.field_151048_u);
                        InstantMine.mc.field_71442_b.func_78765_e();
                        InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                        InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = slotMain;
                        InstantMine.mc.field_71442_b.func_78765_e();
                        return;
                    }
                    InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                }
            }
        }
    }

    private void switchToSlot(int slot) {
        InstantMine.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        InstantMine.mc.field_71442_b.func_78765_e();
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!InstantMine.mc.field_71439_g.func_184812_l_()) {
            double centerZ;
            double centerY;
            double centerX;
            AxisAlignedBB axisAlignedBB;
            if (breakPos2 != null) {
                axisAlignedBB = InstantMine.mc.field_71441_e.func_180495_p(breakPos2).func_185918_c((World)InstantMine.mc.field_71441_e, breakPos2);
                centerX = axisAlignedBB.field_72340_a + (axisAlignedBB.field_72336_d - axisAlignedBB.field_72340_a) / 2.0;
                centerY = axisAlignedBB.field_72338_b + (axisAlignedBB.field_72337_e - axisAlignedBB.field_72338_b) / 2.0;
                centerZ = axisAlignedBB.field_72339_c + (axisAlignedBB.field_72334_f - axisAlignedBB.field_72339_c) / 2.0;
                double var10001 = axisAlignedBB.field_72336_d - centerX;
                double progressValX = InstantMine.getInstance().manxi2 * (var10001 / 10.0);
                var10001 = axisAlignedBB.field_72337_e - centerY;
                double progressValY = InstantMine.getInstance().manxi2 * (var10001 / 10.0);
                var10001 = axisAlignedBB.field_72334_f - centerZ;
                double progressValZ = InstantMine.getInstance().manxi2 * (var10001 / 10.0);
                AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
                if (breakPos != null) {
                    if (!breakPos2.equals((Object)breakPos)) {
                        RenderUtil.drawBBBox(axisAlignedBB1, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.alpha.getValue());
                        RenderUtil.drawBBFill(axisAlignedBB1, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha2.getValue()), this.alpha2.getValue());
                    }
                } else {
                    RenderUtil.drawBBBox(axisAlignedBB1, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.alpha.getValue());
                    RenderUtil.drawBBFill(axisAlignedBB1, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha2.getValue()), this.alpha2.getValue());
                }
            }
            if (this.creativeMode.getValue().booleanValue() && this.cancelStart) {
                if (this.godBlocks.contains(InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
                    this.empty = true;
                }
                if (this.imerS.passedMs(15L)) {
                    if (this.manxi <= 10.0) {
                        this.manxi += 0.11;
                    }
                    this.imerS.reset();
                }
                if (this.imerS2.passedMs(22L)) {
                    if (this.manxi2 <= 10.0 && this.manxi2 >= 0.0) {
                        this.manxi2 += 0.11;
                    }
                    this.imerS2.reset();
                }
                axisAlignedBB = InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_185918_c((World)InstantMine.mc.field_71441_e, breakPos);
                centerX = axisAlignedBB.field_72340_a + (axisAlignedBB.field_72336_d - axisAlignedBB.field_72340_a) / 2.0;
                centerY = axisAlignedBB.field_72338_b + (axisAlignedBB.field_72337_e - axisAlignedBB.field_72338_b) / 2.0;
                centerZ = axisAlignedBB.field_72339_c + (axisAlignedBB.field_72334_f - axisAlignedBB.field_72339_c) / 2.0;
                double progressValX = this.manxi * ((axisAlignedBB.field_72336_d - centerX) / 10.0);
                double progressValY = this.manxi * ((axisAlignedBB.field_72337_e - centerY) / 10.0);
                double progressValZ = this.manxi * ((axisAlignedBB.field_72334_f - centerZ) / 10.0);
                AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
                if (this.render.getValue().booleanValue()) {
                    RenderUtil.drawBBFill(axisAlignedBB1, new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 255), this.falpha.getValue());
                }
                if (this.render2.getValue().booleanValue()) {
                    RenderUtil.drawBBBox(axisAlignedBB1, new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 255), this.balpha.getValue());
                }
            }
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        CPacketPlayerDigging packet;
        if (!InstantMine.fullNullCheck() && !InstantMine.mc.field_71439_g.func_184812_l_() && event.getPacket() instanceof CPacketPlayerDigging && (packet = (CPacketPlayerDigging)event.getPacket()).func_180762_c() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
            event.setCanceled(this.cancelStart);
        }
    }

    public static void attackcrystal() {
        for (Entity crystal : InstantMine.mc.field_71441_e.field_72996_f.stream().filter(e -> e instanceof EntityEnderCrystal && !e.field_70128_L).sorted(Comparator.comparing(e -> Float.valueOf(InstantMine.mc.field_71439_g.func_70032_d(e)))).collect(Collectors.toList())) {
            if (!(crystal instanceof EntityEnderCrystal) || !(crystal.func_174818_b(breakPos) <= 2.0)) continue;
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(crystal));
            InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
        }
    }

    @SubscribeEvent
    public void onBlockEvent(SelfDamageBlockEvent.Port1 event) {
        if (!(InstantMine.fullNullCheck() || InstantMine.mc.field_71439_g.func_184812_l_() || !BlockUtil.canBreak(event.pos) || breakPos != null && breakPos.func_177958_n() == event.pos.func_177958_n() && breakPos.func_177956_o() == event.pos.func_177956_o() && breakPos.func_177952_p() == event.pos.func_177952_p())) {
            if (ticked == 0) {
                ticked = 1;
            }
            if (this.manxi2 == 0.0) {
                this.manxi2 = 0.11;
            }
            if (breakPos != null && breakPos2 == null && InstantMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c() != Blocks.field_150350_a) {
                breakPos2 = breakPos;
            }
            if (breakPos == null && breakPos2 == null) {
                breakPos2 = event.pos;
            }
            this.manxi = 0.0;
            this.empty = false;
            this.cancelStart = false;
            breakPos = event.pos;
            this.breakSuccess.reset();
            this.facing = event.facing;
            if (breakPos != null) {
                InstantMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, this.facing));
                this.cancelStart = true;
                InstantMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, this.facing));
                event.setCanceled(true);
            }
        }
    }

    boolean isHealth() {
        float h = this.health.getValue().floatValue();
        if (h <= 0.2f || h >= 36.0f) {
            return true;
        }
        return InstantMine.mc.field_71439_g.func_110143_aJ() + InstantMine.mc.field_71439_g.func_110139_bj() >= h;
    }

    static {
        ticked = 0;
    }
}

