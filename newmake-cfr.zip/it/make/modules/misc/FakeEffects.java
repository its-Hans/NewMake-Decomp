/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.MobEffects
 *  net.minecraft.potion.PotionEffect
 */
package it.make.modules.misc;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;

public class FakeEffects
extends Module {
    private static FakeEffects INSTANCE = new FakeEffects();
    Setting<Boolean> nv = this.rbool("NightVision", false);
    Setting<Boolean> mf = this.rbool("MiningFatigue", false);

    public FakeEffects() {
        super(new I18NInfo("FakeEffects").bind(EnumI18N.Chinese, "\u5047\u836f"), "", Module.Category.MISC);
        INSTANCE = this;
    }

    public static FakeEffects getInstance() {
        return INSTANCE;
    }

    @Override
    public void onUpdate() {
        if (this.mf.getValue().booleanValue()) {
            FakeEffects.mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76419_f, 1337, 3));
        } else {
            FakeEffects.mc.field_71439_g.func_184589_d(MobEffects.field_76419_f);
        }
        if (this.nv.getValue().booleanValue()) {
            FakeEffects.mc.field_71439_g.func_70690_d(new PotionEffect(MobEffects.field_76439_r, 1337, 0));
        } else {
            FakeEffects.mc.field_71439_g.func_184589_d(MobEffects.field_76439_r);
        }
    }
}

