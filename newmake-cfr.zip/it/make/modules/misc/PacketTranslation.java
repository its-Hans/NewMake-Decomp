/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PacketTranslation
extends Module {
    public static PacketTranslation INSTANCE = new PacketTranslation();
    Setting<Page> page = this.rother("Page", Page.C);
    public Setting<OnGroundForce> cPlayer_OnGround = this.rother("CPacketPlayer_OnGround", OnGroundForce.False, v -> this.page.getValue() == Page.C);
    Setting<Boolean> noRotate = this.rbool("NoRotate", false, v -> this.page.getValue() == Page.S);

    public PacketTranslation() {
        super(new I18NInfo("PacketTranslation").bind(EnumI18N.Chinese, "\u53d1\u5305\u4e2d\u95f4\u4eba"), "description", Module.Category.MISC);
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.isCanceled() || PacketTranslation.fullNullCheck()) {
            return;
        }
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketPlayer) {
            switch (this.cPlayer_OnGround.getValue()) {
                case NONE: {
                    break;
                }
                case True: {
                    ((CPacketPlayer)event.getPacket()).field_149474_g = true;
                    break;
                }
                case False: {
                    ((CPacketPlayer)event.getPacket()).field_149474_g = false;
                }
            }
        }
    }

    @SubscribeEvent
    public void onReceivePacket(PacketEvent.Receive event) {
        if (event.isCanceled() || PacketTranslation.fullNullCheck()) {
            return;
        }
        if (event.getStage() == 0 && event.getPacket() instanceof SPacketPlayerPosLook && this.noRotate.getValue().booleanValue()) {
            ((SPacketPlayerPosLook)event.getPacket()).field_148936_d = PacketTranslation.mc.field_71439_g.field_70177_z;
            ((SPacketPlayerPosLook)event.getPacket()).field_148937_e = PacketTranslation.mc.field_71439_g.field_70125_A;
        }
    }

    public static enum OnGroundForce {
        True,
        False,
        NONE;

    }

    static enum Page {
        C,
        S;

    }
}

