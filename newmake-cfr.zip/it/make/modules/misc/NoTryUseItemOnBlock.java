/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemBucketMilk
 *  net.minecraft.item.ItemFood
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucketMilk;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoTryUseItemOnBlock
extends Module {
    Setting<Boolean> allCancel = this.rbool("AllCancel", false);
    Setting<Boolean> heldCanUseCancel = this.rbool("HeldCanUseCancel", true);

    public NoTryUseItemOnBlock() {
        super(new I18NInfo("NoTryUseItemOnBlock").bind(EnumI18N.Chinese, "\u4e0d\u77e5\u9053"), "", Module.Category.MISC);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.isCanceled()) {
            return;
        }
        if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            if (this.allCancel.getValue().booleanValue()) {
                event.setCanceled(true);
                return;
            }
            if (this.heldCanUseCancel.getValue().booleanValue() && NoTryUseItemOnBlock.isCanUseAnyHand()) {
                event.setCanceled(true);
            }
        }
    }

    public static boolean isStackOnUsable(ItemStack stack) {
        if (stack.func_190926_b()) {
            return false;
        }
        Item item = stack.func_77973_b();
        return item instanceof ItemFood || item instanceof ItemBow || item instanceof ItemBucketMilk;
    }

    public static boolean isStackOnBlock(ItemStack stack) {
        if (stack.func_190926_b()) {
            return false;
        }
        Item item = stack.func_77973_b();
        return item instanceof ItemBlock;
    }

    public static boolean isCanUseAnyHand() {
        return NoTryUseItemOnBlock.isMainhandCanUse() || NoTryUseItemOnBlock.isOffhandCanUse();
    }

    public static boolean isOffhandCanUse() {
        return NoTryUseItemOnBlock.isStackOnUsable(NoTryUseItemOnBlock.mc.field_71439_g.func_184592_cb()) && !NoTryUseItemOnBlock.isStackOnBlock(NoTryUseItemOnBlock.mc.field_71439_g.func_184614_ca());
    }

    public static boolean isMainhandCanUse() {
        return NoTryUseItemOnBlock.isStackOnUsable(NoTryUseItemOnBlock.mc.field_71439_g.func_184614_ca());
    }
}

