/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package it.make.modules.misc;

import it.make.Client;
import it.make.api.utils.M4keUtil;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.modules.Module;
import it.make.modules.client.Targets;
import java.util.ArrayList;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class CityTest
extends Module {
    public CityTest() {
        super("CityTest", "", Module.Category.MISC);
    }

    @Override
    public void onUpdate() {
        BlockPos playerPos = UtilsRewrite.UBlock.getPlayerPosition(Targets.getTarget());
        if (playerPos == null) {
            return;
        }
        ArrayList<BlockPos> breaks = M4keUtil.getDefends(playerPos);
        breaks.removeIf(pos -> UtilsRewrite.UBlock.getBlock(pos) != Blocks.field_150343_Z);
        Client.breakManager.updateBreaks(breaks.toArray(new BlockPos[0]));
    }
}

