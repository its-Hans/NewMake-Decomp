/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketChatMessage
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Suffix
extends Module {
    Setting<String> suffixSetting = this.register(new Setting<String>("suffix", " | Make"));
    Setting<String> no1 = this.register(new Setting<String>("skip1", " "));
    Setting<String> no2 = this.register(new Setting<String>("skip2", "*"));
    Setting<String> no3 = this.register(new Setting<String>("skip3", "-"));
    Setting<String> no4 = this.register(new Setting<String>("skip4", "+"));
    Setting<String> no5 = this.register(new Setting<String>("skip5", ";"));
    Setting<String> no6 = this.register(new Setting<String>("skip6", ","));
    Setting<String> no7 = this.register(new Setting<String>("skip7", "!"));
    Setting<String> no8 = this.register(new Setting<String>("skip8", "@"));
    Setting<String> no9 = this.register(new Setting<String>("skip9", "$"));
    Setting<String> no0 = this.register(new Setting<String>("skip0", "%"));

    public Suffix() {
        super(new I18NInfo("Suffix").bind(EnumI18N.Chinese, "\u804a\u5929\u540e\u7f00"), "chatsuffix", Module.Category.MISC, true, false, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage) {
            CPacketChatMessage packet = (CPacketChatMessage)event.getPacket();
            String message = packet.func_149439_c();
            if (message.startsWith("/") || message.startsWith(this.no0.getValue()) || message.startsWith(this.no1.getValue()) || message.startsWith(this.no2.getValue()) || message.startsWith(this.no3.getValue()) || message.startsWith(this.no4.getValue()) || message.startsWith(this.no5.getValue()) || message.startsWith(this.no6.getValue()) || message.startsWith(this.no7.getValue()) || message.startsWith(this.no8.getValue()) || message.startsWith(this.no9.getValue())) {
                return;
            }
            String suffix = message + this.suffixSetting.getValue();
            if (suffix.length() >= 256) {
                suffix = suffix.substring(0, 256);
            }
            packet.field_149440_a = suffix;
        }
    }
}

