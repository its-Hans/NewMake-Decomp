/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.misc;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.modules.Module;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoCAnimation
extends Module {
    public NoCAnimation() {
        super(new I18NInfo("NoCAnimation").bind(EnumI18N.Chinese, "\u4e0d\u6325\u624b"), "IDK", Module.Category.MISC);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketAnimation) {
            event.setCanceled(true);
        }
    }
}

