/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.material.Material
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package it.make.modules.fun;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class BlatantClicker
extends Module {
    public static BlatantClicker instance = new BlatantClicker();
    Setting<Integer> cpsMax = this.rinte("MaxCPS", 13, 1, 20);
    Setting<Integer> cpsMin = this.rinte("MinCPS", 10, 1, 20);
    TimerUtil timer = new TimerUtil();

    public BlatantClicker() {
        super(new I18NInfo("BlatantClicker").bind(EnumI18N.Chinese, "\u8fde\u70b9\u5668\uff08\u66b4\u529b\uff09"), "", Module.Category.FUN);
        instance = this;
    }

    @Override
    public String getDisplayInfo() {
        if (this.cpsMax.getValue() >= this.cpsMin.getValue() && this.cpsMin.getValue() <= this.cpsMax.getValue()) {
            this.update();
            if (this.cpsMin.getValue() == this.cpsMax.getValue()) {
                return this.cpsMax.getValue() + " CPS";
            }
            return this.cpsMin.getValue() + " ~ " + this.cpsMax.getValue();
        }
        return "Illegal";
    }

    public static double randomDouble(double min, double max) {
        if (min == max) {
            return max;
        }
        return ThreadLocalRandom.current().nextDouble(min, max);
    }

    public void update() {
        if (this.timer.hasReached(1000.0 / BlatantClicker.randomDouble(this.cpsMin.getValue().intValue(), this.cpsMax.getValue().intValue())) && this.isClicking() && BlatantClicker.mc.field_71474_y.field_74312_F.func_151470_d()) {
            BlockPos blockpos;
            BlatantClicker.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            if (BlatantClicker.mc.field_71476_x.field_72308_g != null) {
                BlatantClicker.mc.field_71442_b.func_78764_a((EntityPlayer)BlatantClicker.mc.field_71439_g, BlatantClicker.mc.field_71476_x.field_72308_g);
            }
            if (BlatantClicker.mc.field_71476_x.func_178782_a() != null && BlatantClicker.mc.field_71441_e.func_180495_p(blockpos = BlatantClicker.mc.field_71476_x.func_178782_a()).func_185904_a() != Material.field_151579_a) {
                BlatantClicker.mc.field_71442_b.func_180511_b(blockpos, BlatantClicker.mc.field_71476_x.field_178784_b);
            }
            this.timer.reset();
        }
    }

    public boolean isClicking() {
        return BlatantClicker.mc.field_71474_y.field_74312_F.func_151470_d();
    }

    public static class TimerUtil {
        private long lastMS;

        private long getCurrentMS() {
            return System.nanoTime() / 1000000L;
        }

        public boolean hasReached(double milliseconds) {
            return (double)(this.getCurrentMS() - this.lastMS) >= milliseconds;
        }

        public void reset() {
            this.lastMS = this.getCurrentMS();
        }

        public boolean delay(float milliSec) {
            return (float)(this.getTime() - this.lastMS) >= milliSec;
        }

        public long getTime() {
            return System.nanoTime() / 1000000L;
        }

        public long getDifference() {
            return this.getTime() - this.lastMS;
        }

        public void setDifference(long difference) {
            this.lastMS = this.getTime() - difference;
        }
    }
}

