/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 */
package it.make.modules.fun;

import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;

public class VClip
extends Module {
    Setting<Boolean> debug = this.rbool("Debug", true);
    Setting<Boolean> first = this.rbool("FirstPacket", true);
    Setting<Boolean> firstPacketOnly = this.rbool("FirstPacketOnly", true, v -> this.first.getValue());
    Setting<Boolean> firstGround = this.rbool("FirstGround", true, v -> this.first.getValue() != false && this.firstPacketOnly.getValue() != false);
    Setting<Double> firstX = this.rdoub("FirstX", 0.0, -2.0, 2.0, v -> this.first.getValue());
    Setting<Double> firstY = this.rdoub("FirstY", -0.03, -2.0, 2.0, v -> this.first.getValue());
    Setting<Double> firstZ = this.rdoub("FirstZ", 0.0, -2.0, 2.0, v -> this.first.getValue());
    Setting<Boolean> second = this.rbool("SecondPacket", true);
    Setting<Boolean> secondPacketOnly = this.rbool("SecondPacketOnly", true, v -> this.second.getValue());
    Setting<Boolean> secondGround = this.rbool("SecondGround", true, v -> this.second.getValue() != false && this.secondPacketOnly.getValue() != false);
    Setting<Double> secondX = this.rdoub("SecondX", 0.0, -2.0, 2.0, v -> this.second.getValue());
    Setting<Double> secondY = this.rdoub("SecondY", 0.05, -2.0, 2.0, v -> this.second.getValue());
    Setting<Double> secondZ = this.rdoub("SecondZ", 0.0, -2.0, 2.0, v -> this.second.getValue());
    Setting<Integer> freqs = this.rinte("Freqs", 1, 1, 20);

    public VClip() {
        super("VClip", "", Module.Category.FUN);
    }

    @Override
    public void onEnable() {
        int freqs = this.freqs.getValue();
        for (int i = 0; i < freqs; ++i) {
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage(i + "");
            }
            if (this.positionChange(this.first, this.firstPacketOnly, this.firstGround, this.firstX, this.firstY, this.firstZ)) {
                this.sendModuleMessage("PosedFirst");
            }
            if (!this.positionChange(this.second, this.secondPacketOnly, this.secondGround, this.secondX, this.secondY, this.secondZ)) continue;
            this.sendModuleMessage("PosedSecond");
        }
        this.disable();
    }

    public boolean positionChange(Setting<Boolean> send, Setting<Boolean> packetOnly, Setting<Boolean> onGround, Setting<Double> x, Setting<Double> y, Setting<Double> z) {
        if (!send.getValue().booleanValue()) {
            return false;
        }
        Double nX = x.getValue();
        Double nY = y.getValue();
        Double nZ = z.getValue();
        if (packetOnly.getValue().booleanValue()) {
            VClip.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(nX.doubleValue(), nY.doubleValue(), nZ.doubleValue(), onGround.getValue().booleanValue()));
        } else {
            VClip.mc.field_71439_g.func_70107_b(nX.doubleValue(), nY.doubleValue(), nZ.doubleValue());
        }
        return true;
    }
}

