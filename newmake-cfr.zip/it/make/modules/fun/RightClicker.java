/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules.fun;

import it.make.api.events.render.Render3DEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u0010\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eH\u0016J\u0018\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0005H\u0002R\u0014\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"}, d2={"Lit/make/modules/fun/RightClicker;", "Lit/make/modules/Module;", "()V", "maxCPSValue", "Lit/make/api/setting/Setting;", "", "minCPSValue", "rightDelay", "", "rightLastSwing", "Lit/make/api/utils/Timer;", "onRender3D", "", "event", "Lit/make/api/events/render/Render3DEvent;", "randomClickDelay", "minCPS", "maxCPS", "Make.Life"})
public final class RightClicker
extends Module {
    @NotNull
    private final Setting<Integer> maxCPSValue;
    @NotNull
    private final Setting<Integer> minCPSValue;
    private long rightDelay;
    @NotNull
    private Timer rightLastSwing;

    public RightClicker() {
        super("RightClicker", "", Module.Category.FUN);
        Setting<Integer> setting = this.rinte("MaxCPS", 8, 1, 40);
        Intrinsics.checkNotNullExpressionValue(setting, "rinte(\"MaxCPS\", 8, 1, 40)");
        this.maxCPSValue = setting;
        Setting<Integer> setting2 = this.rinte("MinCPS", 5, 1, 40);
        Intrinsics.checkNotNullExpressionValue(setting2, "rinte(\"MinCPS\", 5, 1, 40)");
        this.minCPSValue = setting2;
        Integer n = this.minCPSValue.getValue();
        Intrinsics.checkNotNullExpressionValue(n, "minCPSValue.value");
        int n2 = ((Number)n).intValue();
        Integer n3 = this.maxCPSValue.getValue();
        Intrinsics.checkNotNullExpressionValue(n3, "maxCPSValue.value");
        this.rightDelay = this.randomClickDelay(n2, ((Number)n3).intValue());
        this.rightLastSwing = new Timer();
    }

    @Override
    public void onRender3D(@NotNull Render3DEvent event) {
        block5: {
            block4: {
                Intrinsics.checkNotNullParameter((Object)event, "event");
                Integer n = this.maxCPSValue.getValue();
                Intrinsics.checkNotNullExpressionValue(n, "maxCPSValue.value");
                int n2 = ((Number)n).intValue();
                Integer n3 = this.minCPSValue.getValue();
                Intrinsics.checkNotNullExpressionValue(n3, "minCPSValue.value");
                if (n2 <= ((Number)n3).intValue()) break block4;
                Integer n4 = this.minCPSValue.getValue();
                Intrinsics.checkNotNullExpressionValue(n4, "minCPSValue.value");
                int n5 = ((Number)n4).intValue();
                Integer n6 = this.maxCPSValue.getValue();
                Intrinsics.checkNotNullExpressionValue(n6, "maxCPSValue.value");
                if (n5 < ((Number)n6).intValue()) break block5;
            }
            return;
        }
        if (Module.mc.field_71474_y.field_74313_G.func_151470_d() && this.rightLastSwing.passedMs(this.rightDelay)) {
            Module.mc.func_147121_ag();
            this.rightLastSwing.reset();
            Integer n = this.minCPSValue.getValue();
            Intrinsics.checkNotNullExpressionValue(n, "minCPSValue.value");
            int n7 = ((Number)n).intValue();
            Integer n8 = this.maxCPSValue.getValue();
            Intrinsics.checkNotNullExpressionValue(n8, "maxCPSValue.value");
            this.rightDelay = this.randomClickDelay(n7, ((Number)n8).intValue());
        }
    }

    private final long randomClickDelay(int minCPS, int maxCPS) {
        return (long)(Math.random() * (double)(1000 / minCPS - 1000 / maxCPS + 1) + (double)(1000 / maxCPS));
    }
}

