/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules.fun;

import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;

public class FastPlace
extends Module {
    public Setting<Double> delay = this.rdoub("Delay", 50.0, 1.0, 500.0);
    private final Timer timer = new Timer();

    public FastPlace() {
        super("FastPlace", "", Module.Category.FUN);
    }

    @Override
    public void onUpdate() {
        if (FastPlace.mc.field_71474_y.field_74313_G.func_151470_d() && this.timer.passedMs(this.delay.getValue().longValue())) {
            FastPlace.mc.field_71467_ac = 0;
            this.timer.reset();
        } else {
            FastPlace.mc.field_71467_ac = 1;
        }
    }
}

