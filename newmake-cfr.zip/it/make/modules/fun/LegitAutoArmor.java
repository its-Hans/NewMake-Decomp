/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Enchantments
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 */
package it.make.modules.fun;

import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;

public class LegitAutoArmor
extends Module {
    private final Timer timer = new Timer();
    private final Setting<Boolean> isOngui = this.rbool("Inventory", false);
    private final Setting<Integer> delay = this.rinte("Delay", 250, 0, 1000);

    public LegitAutoArmor() {
        super("LegitAutoArmor", "", Module.Category.FUN);
    }

    public static boolean isBestArmor(ItemStack stack, int type) {
        float prot = LegitAutoArmor.getProtection(stack);
        EntityEquipmentSlot etype = null;
        if (type == 1) {
            etype = EntityEquipmentSlot.HEAD;
        } else if (type == 2) {
            etype = EntityEquipmentSlot.CHEST;
        } else if (type == 3) {
            etype = EntityEquipmentSlot.LEGS;
        } else if (type == 4) {
            etype = EntityEquipmentSlot.FEET;
        }
        if (etype == null || !stack.func_77973_b().isValidArmor(stack, etype, (Entity)LegitAutoArmor.mc.field_71439_g)) {
            return false;
        }
        for (int i = 5; i < 45; ++i) {
            EntityEquipmentSlot itemSlot;
            ItemStack is = LegitAutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (is.func_190926_b() || !(LegitAutoArmor.getProtection(is) > prot) || etype != (itemSlot = LegitAutoArmor.getEquipmentSlotForItem(is))) continue;
            return false;
        }
        return true;
    }

    private static EntityEquipmentSlot getEquipmentSlotForItem(ItemStack stack) {
        if (stack.func_77973_b().isValidArmor(stack, EntityEquipmentSlot.HEAD, (Entity)LegitAutoArmor.mc.field_71439_g)) {
            return EntityEquipmentSlot.HEAD;
        }
        if (stack.func_77973_b().isValidArmor(stack, EntityEquipmentSlot.CHEST, (Entity)LegitAutoArmor.mc.field_71439_g)) {
            return EntityEquipmentSlot.CHEST;
        }
        if (stack.func_77973_b().isValidArmor(stack, EntityEquipmentSlot.LEGS, (Entity)LegitAutoArmor.mc.field_71439_g)) {
            return EntityEquipmentSlot.LEGS;
        }
        if (stack.func_77973_b().isValidArmor(stack, EntityEquipmentSlot.FEET, (Entity)LegitAutoArmor.mc.field_71439_g)) {
            return EntityEquipmentSlot.FEET;
        }
        return null;
    }

    public static float getProtection(ItemStack stack) {
        float prot = 0.0f;
        if (stack.func_77973_b() instanceof ItemArmor) {
            ItemArmor armor = (ItemArmor)stack.func_77973_b();
            prot = (float)((double)prot + (double)armor.field_77879_b + (double)((100 - armor.field_77879_b) * EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_180310_c, (ItemStack)stack)) * 0.0075);
            prot = (float)((double)prot + (double)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185297_d, (ItemStack)stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_77329_d, (ItemStack)stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_92091_k, (ItemStack)stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185307_s, (ItemStack)stack) / 50.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_180308_g, (ItemStack)stack) / 100.0);
        }
        return prot;
    }

    public void getBestArmor() {
        for (int type = 1; type < 5; ++type) {
            ItemStack equippedItem = LegitAutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(4 + type).func_75211_c();
            if (!equippedItem.func_190926_b() && !LegitAutoArmor.isBestArmor(equippedItem, type)) {
                LegitAutoArmor.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)LegitAutoArmor.mc.field_71439_g, CPacketEntityAction.Action.OPEN_INVENTORY));
                this.drop(4 + type);
            }
            for (int slot = 9; slot < 45; ++slot) {
                ItemStack itemInSlot = LegitAutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(slot).func_75211_c();
                if (itemInSlot.func_190926_b() || !LegitAutoArmor.isBestArmor(itemInSlot, type) || !(LegitAutoArmor.getProtection(itemInSlot) > 0.0f)) continue;
                this.shiftClick(slot);
                this.timer.reset();
                return;
            }
        }
    }

    public void shiftClick(int slot) {
        LegitAutoArmor.mc.field_71442_b.func_187098_a(LegitAutoArmor.mc.field_71439_g.field_71069_bz.field_75152_c, slot, 0, ClickType.QUICK_MOVE, (EntityPlayer)LegitAutoArmor.mc.field_71439_g);
    }

    public void drop(int slot) {
        LegitAutoArmor.mc.field_71442_b.func_187098_a(LegitAutoArmor.mc.field_71439_g.field_71069_bz.field_75152_c, slot, 1, ClickType.THROW, (EntityPlayer)LegitAutoArmor.mc.field_71439_g);
    }

    @Override
    public void onTick() {
        if (LegitAutoArmor.fullNullCheck()) {
            return;
        }
        if (this.isOngui.getValue().booleanValue()) {
            if (LegitAutoArmor.mc.field_71462_r instanceof GuiInventory && (LegitAutoArmor.mc.field_71462_r == null || LegitAutoArmor.mc.field_71462_r instanceof GuiInventory || LegitAutoArmor.mc.field_71462_r instanceof GuiChat) && this.timer.passedMs(this.delay.getValue().intValue())) {
                this.getBestArmor();
            }
        } else {
            this.getBestArmor();
        }
    }
}

