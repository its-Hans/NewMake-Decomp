/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.math.BlockPos
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.fun;

import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Eagle
extends Module {
    public Eagle() {
        super("Eagle", "", Module.Category.FUN);
    }

    public Block getBlockUnderPlayer(EntityPlayer player) {
        return Eagle.mc.field_71441_e.func_180495_p(new BlockPos(player.field_70165_t, player.field_70163_u - 1.0, player.field_70161_v)).func_177230_c();
    }

    @SubscribeEvent
    public void onUpdate(UpdateWalkingPlayerEvent event) {
        if (!Eagle.mc.field_71439_g.field_70122_E) {
            return;
        }
        KeyBinding.func_74510_a((int)Eagle.mc.field_71474_y.field_74311_E.func_151463_i(), (boolean)(this.getBlockUnderPlayer((EntityPlayer)Eagle.mc.field_71439_g) instanceof BlockAir));
    }

    @Override
    public void onDisable() {
        if (!GameSettings.func_100015_a((KeyBinding)Eagle.mc.field_71474_y.field_74311_E)) {
            KeyBinding.func_74510_a((int)Eagle.mc.field_71474_y.field_74311_E.func_151463_i(), (boolean)false);
        }
    }
}

