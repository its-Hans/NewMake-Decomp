/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.monster.EntityMob
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 */
package it.make.modules.fun;

import it.make.api.setting.Setting;
import it.make.modules.Module;
import it.make.modules.fun.BlatantClicker;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class AimAssist
extends Module {
    private final Setting<Double> speed = this.rdoub("Speed", 40.0, 1.0, 100.0);
    private final Setting<Double> compliment = this.rdoub("Compliment", 15.0, 1.0, 100.0);
    private final Setting<Double> distance = this.rdoub("Distance", 4.3, 1.0, 10.0);
    private final Setting<Boolean> clickAim = this.rbool("ClickAim", true);
    private final Setting<Boolean> players = this.rbool("players", true);
    private final Setting<Boolean> animals = this.rbool("animals", false);
    private final Setting<Boolean> mobs = this.rbool("mobs", false);
    private final Setting<Boolean> invisibles = this.rbool("invisibles", false);

    public AimAssist() {
        super("AimAssist", "leave", Module.Category.FUN);
    }

    public static boolean autoClickerClicking() {
        return BlatantClicker.instance.isOn() && BlatantClicker.instance.isClicking();
    }

    public static double fovFromEntity(Entity en) {
        return ((double)(AimAssist.mc.field_71439_g.field_70177_z - AimAssist.fovToEntity(en)) % 360.0 + 540.0) % 360.0 - 180.0;
    }

    public static float fovToEntity(Entity ent) {
        double x = ent.field_70165_t - AimAssist.mc.field_71439_g.field_70165_t;
        double z = ent.field_70161_v - AimAssist.mc.field_71439_g.field_70161_v;
        double yaw = Math.atan2(x, z) * 57.2957795;
        return (float)(yaw * -1.0);
    }

    public static boolean bot(Entity en) {
        if (AimAssist.fullNullCheck() || AimAssist.screenNotNull()) {
            return false;
        }
        if (en.func_70005_c_().startsWith("\ufffd\ufffdc")) {
            return true;
        }
        String n = en.func_145748_c_().func_150260_c();
        if (n.contains("\ufffd\ufffd")) {
            return n.contains("[NPC] ");
        }
        if (n.isEmpty() && en.func_70005_c_().isEmpty()) {
            return true;
        }
        if (n.length() == 10) {
            int num = 0;
            int let = 0;
            for (char c : n.toCharArray()) {
                if (Character.isLetter(c)) {
                    if (Character.isUpperCase(c)) {
                        return false;
                    }
                    ++let;
                    continue;
                }
                if (!Character.isDigit(c)) {
                    return false;
                }
                ++num;
            }
            return num >= 2 && let >= 2;
        }
        return false;
    }

    public static boolean screenNotNull() {
        return AimAssist.mc.field_71462_r != null;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        double n;
        Entity en;
        if (AimAssist.screenNotNull()) {
            return;
        }
        if (AimAssist.fullNullCheck()) {
            return;
        }
        if ((this.clickAim.getValue().booleanValue() && AimAssist.autoClickerClicking() || AimAssist.autoClickerClicking() || !this.clickAim.getValue().booleanValue()) && (en = this.getEnemy()) != null && ((n = AimAssist.fovFromEntity(en)) > 1.0 || n < -1.0)) {
            double complimentSpeed = n * (ThreadLocalRandom.current().nextDouble(this.compliment.getValue() - 1.47328, this.compliment.getValue() + 2.48293) / 100.0);
            ThreadLocalRandom.current().nextDouble(this.speed.getValue() - 4.723847, this.speed.getValue());
            float val = (float)(-(complimentSpeed + n / (101.0 - (double)((float)ThreadLocalRandom.current().nextDouble(this.speed.getValue() - 4.723847, this.speed.getValue())))));
            AimAssist.mc.field_71439_g.field_70177_z += val;
        }
    }

    public Entity getEnemy() {
        Entity en;
        Iterator var2 = AimAssist.mc.field_71441_e.field_72996_f.iterator();
        do {
            if (var2.hasNext()) continue;
            return null;
        } while ((en = (Entity)var2.next()) == AimAssist.mc.field_71439_g || en.field_70128_L || !this.invisibles.getValue().booleanValue() && en.func_82150_aj() || (double)AimAssist.mc.field_71439_g.func_70032_d(en) > this.distance.getValue() || AimAssist.bot(en));
        if (en instanceof EntityPlayer && this.players.getValue().booleanValue()) {
            return en;
        }
        if (en instanceof EntityAnimal && this.animals.getValue().booleanValue()) {
            return en;
        }
        if (en instanceof EntityMob && this.mobs.getValue().booleanValue()) {
            return en;
        }
        return null;
    }
}

