/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.fun;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.modules.Module;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Ghost
extends Module {
    private boolean bypass = false;

    public Ghost() {
        super(new I18NInfo("Ghost").bind(EnumI18N.Chinese, "\u9b3c"), "like a ghost", Module.Category.FUN);
    }

    @Override
    public void onEnable() {
        this.bypass = false;
    }

    @Override
    public void onDisable() {
        if (Ghost.mc.field_71439_g != null) {
            Ghost.mc.field_71439_g.func_71004_bE();
        }
        this.bypass = false;
    }

    @Override
    public void onUpdate() {
        if (Ghost.mc.field_71439_g == null || Ghost.mc.field_71441_e == null) {
            return;
        }
        if (Ghost.mc.field_71439_g.func_110143_aJ() == 0.0f) {
            Ghost.mc.field_71439_g.func_70606_j(20.0f);
            Ghost.mc.field_71439_g.field_70128_L = false;
            this.bypass = true;
            mc.func_147108_a(null);
            Ghost.mc.field_71439_g.func_70634_a(Ghost.mc.field_71439_g.field_70165_t, Ghost.mc.field_71439_g.field_70163_u, Ghost.mc.field_71439_g.field_70161_v);
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (this.bypass && event.getPacket() instanceof CPacketPlayer) {
            event.setCanceled(true);
        }
    }
}

