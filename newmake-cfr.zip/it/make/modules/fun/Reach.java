/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemAxe
 *  net.minecraft.item.ItemSword
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.client.event.MouseEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.fun;

import it.make.api.setting.Setting;
import it.make.modules.Module;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Reach
extends Module {
    private final Setting<Float> range = this.rfloa("Range", Float.valueOf(3.1f), Float.valueOf(3.0f), Float.valueOf(6.0f));
    private final Setting<Boolean> weapon_only = this.rbool("weapon_only", false);
    private final Setting<Boolean> moving_only = this.rbool("moving_only", false);
    private final Setting<Boolean> sprint_only = this.rbool("sprint_only", false);

    public Reach() {
        super("Reach", "Leave", Module.Category.FUN);
    }

    @SubscribeEvent
    public void onMove(MouseEvent ev) {
        BlockPos blocksReach;
        if (this.weapon_only.getValue().booleanValue()) {
            if (Reach.mc.field_71439_g.func_184614_ca().func_190926_b()) {
                return;
            }
            if (!(Reach.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword) && !(Reach.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemAxe)) {
                return;
            }
        }
        if (this.moving_only.getValue().booleanValue() && (double)Reach.mc.field_71439_g.field_191988_bg == 0.0 && (double)Reach.mc.field_71439_g.field_70702_br == 0.0) {
            return;
        }
        if (this.sprint_only.getValue().booleanValue() && !Reach.mc.field_71439_g.func_70051_ag()) {
            return;
        }
        if (Reach.mc.field_71476_x != null && (blocksReach = Reach.mc.field_71476_x.func_178782_a()) != null && Reach.mc.field_71441_e.func_180495_p(blocksReach).func_177230_c() != Blocks.field_150350_a) {
            return;
        }
        double Reach2 = this.range.getValue().floatValue();
        Object[] reachs = Reach.doReach(Reach2, 0.0);
        if (reachs == null) {
            return;
        }
        Reach.mc.field_71476_x = new RayTraceResult((Entity)reachs[0], (Vec3d)reachs[1]);
        Reach.mc.field_147125_j = (Entity)reachs[0];
    }

    public static Object[] doReach(double reachValue, double AABB) {
        Entity target = mc.func_175606_aa();
        Entity entity = null;
        if (target == null || Reach.mc.field_71441_e == null) {
            return null;
        }
        Reach.mc.field_71424_I.func_76320_a("pick");
        Vec3d targetEyes = target.func_174824_e(0.0f);
        Vec3d targetLook = target.func_70676_i(0.0f);
        Vec3d targetVector = targetEyes.func_72441_c(targetLook.field_72450_a * reachValue, targetLook.field_72448_b * reachValue, targetLook.field_72449_c * reachValue);
        Vec3d targetVec = null;
        List targetHitbox = Reach.mc.field_71441_e.func_72839_b(target, target.func_174813_aQ().func_72321_a(targetLook.field_72450_a * reachValue, targetLook.field_72448_b * reachValue, targetLook.field_72449_c * reachValue).func_72321_a(1.0, 1.0, 1.0));
        double reaching = reachValue;
        for (Entity hitbox : targetHitbox) {
            double targetHitVec;
            if (!hitbox.func_70067_L()) continue;
            float targetCollisionBorderSize = hitbox.func_70111_Y();
            AxisAlignedBB targetAABB = hitbox.func_174813_aQ().func_72321_a((double)targetCollisionBorderSize, (double)targetCollisionBorderSize, (double)targetCollisionBorderSize);
            targetAABB = targetAABB.func_72321_a(AABB, AABB, AABB);
            RayTraceResult tagetPosition = targetAABB.func_72327_a(targetEyes, targetVector);
            if (targetAABB.func_72318_a(targetEyes)) {
                if (!(0.0 < reaching) && reaching != 0.0) continue;
                entity = hitbox;
                targetVec = tagetPosition == null ? targetEyes : tagetPosition.field_72307_f;
                reaching = 0.0;
                continue;
            }
            if (tagetPosition == null || !((targetHitVec = targetEyes.func_72438_d(tagetPosition.field_72307_f)) < reaching) && reaching != 0.0) continue;
            if (hitbox == target.field_184239_as) {
                if (reaching != 0.0) continue;
                entity = hitbox;
                targetVec = tagetPosition.field_72307_f;
                continue;
            }
            entity = hitbox;
            targetVec = tagetPosition.field_72307_f;
            reaching = targetHitVec;
        }
        if (reaching < reachValue && !(entity instanceof EntityLivingBase) && !(entity instanceof EntityItemFrame)) {
            entity = null;
        }
        Reach.mc.field_71424_I.func_76319_b();
        if (entity == null || targetVec == null) {
            return null;
        }
        return new Object[]{entity, targetVec};
    }
}

