/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketEntityVelocity
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.fun;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.modules.Module;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class JumpReset
extends Module {
    public JumpReset() {
        super(new I18NInfo("JumpReset").bind(EnumI18N.Chinese, "\u81ea\u52a8\u8df3\u8dc3\u91cd\u7f6e"), "", Module.Category.FUN);
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (JumpReset.fullNullCheck() || event.isCanceled() || !(event.getPacket() instanceof SPacketEntityVelocity)) {
            return;
        }
        SPacketEntityVelocity packet = (SPacketEntityVelocity)event.getPacket();
        if (packet.func_149412_c() == JumpReset.mc.field_71439_g.func_145782_y() && JumpReset.mc.field_71439_g.field_70122_E) {
            JumpReset.mc.field_71439_g.func_70664_aZ();
        }
    }
}

