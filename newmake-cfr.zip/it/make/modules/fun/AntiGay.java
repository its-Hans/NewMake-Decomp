/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package it.make.modules.fun;

import it.make.api.exceptions.GayException;
import it.make.api.setting.Setting;
import it.make.api.utils.second.m4ke.fun.GayCounter;
import it.make.modules.Module;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.entity.player.EntityPlayer;

public class AntiGay
extends Module {
    Setting<Integer> minShift = this.rinte("MinShift", 10, 0, 20);
    GayCounter counter = new GayCounter();

    public AntiGay() {
        super("AntiGay", "6", Module.Category.FUN);
    }

    @Override
    public void onTick() {
        this.counter.updateByTick();
        List<EntityPlayer> gays = this.counter.getGays(this.minShift.getValue());
        if (gays != null) {
            throw new GayException(new GayException.GayError(gays.stream().map(EntityPlayer::func_70005_c_).collect(Collectors.toList())));
        }
    }
}

