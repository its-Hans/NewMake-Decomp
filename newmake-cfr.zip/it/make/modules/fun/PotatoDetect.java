/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.fun;

import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import java.util.stream.Stream;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PotatoDetect
extends Module {
    Setting<Integer> range = this.rinte("Range", 70, 0, 200);
    EntityPlayer detect = null;

    public PotatoDetect() {
        super("PotatoDetect", "", Module.Category.FUN);
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
        if (PotatoDetect.fullNullCheck()) {
            return;
        }
        Stream<EntityPlayer> detects = PotatoDetect.mc.field_71441_e.func_175661_b(EntityPlayer.class, PotatoDetect::isPlayerBomber).stream().filter(this::inRange);
        EntityPlayer detect = detects.findFirst().orElse(null);
        if (detect != null && !detect.equals((Object)this.detect)) {
            PotatoDetect.notiMessage("Detected an player: " + detect.func_70005_c_());
        }
        this.detect = detect;
    }

    public static boolean isPlayerBomber(EntityPlayer player) {
        return PotatoDetect.isStackPotato(player.field_71069_bz.func_75139_a(5).func_75211_c()) || PotatoDetect.isStackPotato(player.func_184614_ca());
    }

    public static boolean isStackPotato(ItemStack stack) {
        if (stack.func_190926_b()) {
            return false;
        }
        Item item = stack.func_77973_b();
        return PotatoDetect.isItemPotato(item);
    }

    public static boolean isItemPotato(Item item) {
        return item.equals(Item.func_150898_a((Block)Blocks.field_150335_W)) || item.equals(Items.field_151174_bG) || item.equals(Items.field_151168_bH);
    }

    @Override
    public String getDisplayInfo() {
        if (this.detect == null) {
            return null;
        }
        return this.detect.func_70005_c_() + " " + PotatoDetect.mc.field_71439_g.func_70032_d((Entity)this.detect) + "m";
    }

    @Override
    public void onToggle() {
        this.detect = null;
    }

    public <T extends Entity> boolean inRange(T en) {
        int range = this.range.getValue();
        return PotatoDetect.mc.field_71439_g.func_174831_c(en.func_180425_c()) < (double)(range * range);
    }
}

