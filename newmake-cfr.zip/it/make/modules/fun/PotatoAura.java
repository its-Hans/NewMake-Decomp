/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package it.make.modules.fun;

import it.make.Client;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.EntityUtil;
import it.make.api.utils.MathUtil;
import it.make.api.utils.second.m4ke.general.PairUtil;
import it.make.api.utils.second.m4ke.io.STAGE;
import it.make.modules.Module;
import it.make.modules.client.Targets;
import it.make.modules.fun.PotatoDetect;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class PotatoAura
extends Module {
    PairUtil.Pair<Entity, Integer> target = null;
    Setting<STAGE> rotate = this.rother("RotateStage", STAGE.PRE);
    Setting<STAGE> swing = this.rother("SwingStage", STAGE.PRE);
    Setting<Float> range = this.rfloa("Range", Float.valueOf(5.4f), Float.valueOf(1.0f), Float.valueOf(6.0f));
    Setting<Float> wallRange = this.rfloa("WallRange", Float.valueOf(2.8f), Float.valueOf(0.0f), Float.valueOf(6.0f));
    Setting<Boolean> debug = this.rbool("Debug", false);
    Setting<Integer> delay = this.rinte("Delay", 5, 0, 40);
    Setting<Boolean> eatingCheck = this.rbool("Using Cancel", true);
    Setting<Boolean> render = this.rbool("Render", true);
    Setting<Integer> redw = this.rinte("Red_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> greenw = this.rinte("Green_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> bluew = this.rinte("Blue_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> alphaw = this.rinte("Alpha_Wait", 255, 0, 255, v -> this.render.getValue());
    Setting<Integer> redh = this.rinte("Red_Hurt", 77, 0, 255, v -> this.render.getValue());
    Setting<Integer> greenh = this.rinte("Green_Hurt", 80, 0, 255, v -> this.render.getValue());
    Setting<Integer> blueh = this.rinte("Blue_Hurt", 200, 0, 255, v -> this.render.getValue());
    Setting<Integer> alphah = this.rinte("Alpha_Hurt", 255, 0, 255, v -> this.render.getValue());

    public PotatoAura() {
        super(new I18NInfo("PotatoAura").bind(EnumI18N.Chinese, "\u571f\u8c46\u5149\u73af"), "description", Module.Category.FUN);
    }

    public void lookAtEntity(Entity entity) {
        Client.rotationManager.lookAtEntity(entity);
    }

    @SubscribeEvent
    public void onWalk(UpdateWalkingPlayerEvent event) {
        this.refreshTarget();
        if (this.attackCheck() && this.target.left != null && this.isntEating() && this.isRaytraceable((Entity)this.target.left)) {
            this.hurt();
        }
    }

    public void refreshTarget() {
        EntityPlayer t = Targets.getTargetByRange(this.range.getValue());
        if (this.target == null || this.target.left != t) {
            this.target = new PairUtil.Pair<EntityPlayer, Integer>(t, this.delay.getValue());
        }
    }

    @Override
    public void onTick() {
        if (this.target != null && (Integer)this.target.right > 0) {
            PairUtil.Pair<Entity, Integer> pair = this.target;
            pair.right = (Integer)pair.right - 1;
        }
    }

    public void hurt() {
        STAGE swingmode = this.swing.getValue();
        STAGE rotatemode = this.rotate.getValue();
        Entity t = (Entity)this.target.left;
        if (swingmode == STAGE.PRE) {
            PotatoAura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (rotatemode == STAGE.PRE) {
            this.lookAtEntity(t);
        }
        PotatoAura.mc.field_71442_b.func_78764_a((EntityPlayer)PotatoAura.mc.field_71439_g, t);
        if (swingmode == STAGE.POST) {
            PotatoAura.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        }
        if (rotatemode == STAGE.POST) {
            this.lookAtEntity(t);
        }
        this.target.right = this.delay.getValue();
        if (this.debug.getValue().booleanValue()) {
            PotatoAura.notiMessage("HURT. ROTATE: " + rotatemode.name() + " SWING: " + swingmode.name() + " TARGET: " + t.func_70005_c_());
        }
    }

    public boolean attackCheck() {
        return this.isHeldWeapon() && this.isDelayed();
    }

    public boolean isHeldWeapon() {
        return this.isWeapon(PotatoAura.mc.field_71439_g.func_184614_ca().func_77973_b());
    }

    public boolean isDelayed() {
        if (this.target == null || this.target.right == null) {
            return false;
        }
        return (Integer)this.target.right <= 1;
    }

    public boolean isntEating() {
        return this.eatingCheck.getValue() == false || !Mouse.isButtonDown((int)1) && !PotatoAura.mc.field_71439_g.func_184587_cr();
    }

    public boolean isRaytraceable(Entity entity) {
        return PotatoAura.mc.field_71439_g.func_70685_l(entity) || EntityUtil.canEntityFeetBeSeen(entity) || !(PotatoAura.mc.field_71439_g.func_70068_e(entity) > MathUtil.square(this.wallRange.getValue().floatValue()));
    }

    public boolean isWeapon(Item item) {
        return PotatoDetect.isItemPotato(item);
    }

    private double easeInOutQuad(double d) {
        return d < 0.5 ? 2.0 * d * d : 1.0 - Math.pow(-2.0 * d + 2.0, 2.0) / 2.0;
    }

    @Override
    public void onRender3D(Render3DEvent render3DEvent) {
        if (!this.render.getValue().booleanValue()) {
            return;
        }
        if (!this.isHeldWeapon()) {
            return;
        }
        if (this.target == null) {
            return;
        }
        Entity entity = (Entity)this.target.left;
        if (entity == null) {
            return;
        }
        Color color1 = (Integer)this.target.right > 0 ? new Color(this.redh.getValue(), this.greenh.getValue(), this.blueh.getValue(), this.alphah.getValue()) : new Color(this.redw.getValue(), this.greenw.getValue(), this.bluew.getValue(), this.alphaw.getValue());
        double d = 1500.0;
        double d2 = (double)System.currentTimeMillis() % d;
        boolean bl = d2 > d / 2.0;
        double d3 = d2 / (d / 2.0);
        d3 = !bl ? 1.0 - d3 : d3 - 1.0;
        d3 = this.easeInOutQuad(d3);
        PotatoAura.mc.field_71460_t.func_175072_h();
        GL11.glPushMatrix();
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2884);
        GL11.glShadeModel((int)7425);
        PotatoAura.mc.field_71460_t.func_175072_h();
        double d4 = entity.field_70130_N;
        double d5 = (double)entity.field_70131_O + 0.1;
        double d6 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)mc.func_184121_ak() - PotatoAura.mc.func_175598_ae().field_78730_l;
        double d7 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)mc.func_184121_ak() - PotatoAura.mc.func_175598_ae().field_78731_m + d5 * d3;
        double d8 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)mc.func_184121_ak() - PotatoAura.mc.func_175598_ae().field_78728_n;
        double d9 = d5 / 3.0 * (d3 > 0.5 ? 1.0 - d3 : d3) * (double)(bl ? -1 : 1);
        for (int i = 0; i < 360; i += 5) {
            double d10 = d6 - Math.sin((double)i * Math.PI / 180.0) * d4;
            double d11 = d8 + Math.cos((double)i * Math.PI / 180.0) * d4;
            double d12 = d6 - Math.sin((double)(i - 5) * Math.PI / 180.0) * d4;
            double d13 = d8 + Math.cos((double)(i - 5) * Math.PI / 180.0) * d4;
            GL11.glBegin((int)7);
            GL11.glColor4f((float)((float)ColorUtil.pulseColor(color1, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getBlue() / 255.0f), (float)0.0f);
            GL11.glVertex3d((double)d10, (double)(d7 + d9), (double)d11);
            GL11.glVertex3d((double)d12, (double)(d7 + d9), (double)d13);
            GL11.glColor4f((float)((float)ColorUtil.pulseColor(color1, 200, 1).getRed() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getGreen() / 255.0f), (float)((float)ColorUtil.pulseColor(color1, 200, 1).getBlue() / 255.0f), (float)200.0f);
            GL11.glVertex3d((double)d12, (double)d7, (double)d13);
            GL11.glVertex3d((double)d10, (double)d7, (double)d11);
            GL11.glEnd();
            GL11.glBegin((int)2);
            GL11.glVertex3d((double)d12, (double)d7, (double)d13);
            GL11.glVertex3d((double)d10, (double)d7, (double)d11);
            GL11.glEnd();
        }
        GL11.glEnable((int)2884);
        GL11.glShadeModel((int)7424);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
    }

    @Override
    public String getDisplayInfo() {
        if (this.target == null) {
            return null;
        }
        Entity t = (Entity)this.target.left;
        if (t == null) {
            return null;
        }
        return t.func_70005_c_();
    }
}

