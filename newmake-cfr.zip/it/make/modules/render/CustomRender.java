/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.EntityViewRenderEvent$FogColors
 *  net.minecraftforge.client.event.EntityViewRenderEvent$FogDensity
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.render;

import it.make.api.events.render.Render2DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.second.skid.RenderUtil;
import it.make.modules.Module;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class CustomRender
extends Module {
    Setting<Boolean> fog = this.rbool("CustomFog", true);
    Setting<Integer> fRed = this.rinte("FogRed", 255, 0, 255, v -> this.fog.getValue());
    Setting<Integer> fGreen = this.rinte("FogGreen", 255, 0, 255, v -> this.fog.getValue());
    Setting<Integer> fBlue = this.rinte("FogBlue", 255, 0, 255, v -> this.fog.getValue());
    Setting<Boolean> wr = this.rbool("WorldRender", false);
    Setting<Integer> wRed = this.rinte("WorldRed", 255, 0, 255, v -> this.wr.getValue());
    Setting<Integer> wGreen = this.rinte("WorldGreen", 255, 0, 255, v -> this.wr.getValue());
    Setting<Integer> wBlue = this.rinte("WorldBlue", 255, 0, 255, v -> this.wr.getValue());
    Setting<Integer> wAlpha = this.rinte("WorldAlpha", 100, 0, 255, v -> this.wr.getValue());

    public CustomRender() {
        super(new I18NInfo("CustomRender").bind(EnumI18N.Chinese, "\u81ea\u5b9a\u4e49\u6e32\u67d3"), "Change world something.", Module.Category.RENDER, true, false, false);
    }

    @SubscribeEvent
    public void fogColors(EntityViewRenderEvent.FogColors event) {
        if (!this.fog.getValue().booleanValue()) {
            return;
        }
        event.setRed((float)this.fRed.getValue().intValue() / 255.0f);
        event.setGreen((float)this.fGreen.getValue().intValue() / 255.0f);
        event.setBlue((float)this.fBlue.getValue().intValue() / 255.0f);
    }

    @SubscribeEvent
    public void fog_density(EntityViewRenderEvent.FogDensity event) {
        if (!this.fog.getValue().booleanValue()) {
            return;
        }
        event.setDensity(0.0f);
        event.setCanceled(true);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (this.wr.getValue().booleanValue()) {
            RenderUtil.drawRectangleCorrectly(0, 0, 1920, 1080, ColorUtil.toRGBA(this.wRed.getValue(), this.wGreen.getValue(), this.wBlue.getValue(), this.wAlpha.getValue()));
        }
    }
}

