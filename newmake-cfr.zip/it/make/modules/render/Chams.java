/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraftforge.client.event.RenderLivingEvent$Post
 *  net.minecraftforge.client.event.RenderLivingEvent$Pre
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.GL11
 */
package it.make.modules.render;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.modules.Module;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

public class Chams
extends Module {
    public Chams() {
        super(new I18NInfo("Chams").bind(EnumI18N.Chinese, "\u900f\u89c6"), "IQ", Module.Category.RENDER);
    }

    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Pre<EntityPlayer> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            mc.func_175598_ae().func_178633_a(false);
            mc.func_175598_ae().func_178632_c(false);
            GlStateManager.func_179094_E();
            GlStateManager.func_179132_a((boolean)true);
            OpenGlHelper.func_77475_a((int)OpenGlHelper.field_77476_b, (float)240.0f, (float)240.0f);
            GL11.glEnable((int)32823);
            GL11.glDepthRange((double)0.0, (double)0.01);
            GlStateManager.func_179121_F();
        }
    }

    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Post<EntityPlayer> event) {
        if (event.getEntity() instanceof EntityPlayer) {
            boolean shadow = mc.func_175598_ae().func_178627_a();
            mc.func_175598_ae().func_178633_a(shadow);
            GlStateManager.func_179094_E();
            GlStateManager.func_179132_a((boolean)false);
            GL11.glDisable((int)32823);
            GL11.glDepthRange((double)0.0, (double)1.0);
            GlStateManager.func_179121_F();
        }
    }
}

