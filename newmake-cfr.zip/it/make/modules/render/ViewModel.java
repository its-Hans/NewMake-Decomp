/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.render;

import it.make.api.events.render.RenderItemEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ViewModel
extends Module {
    public Setting<Boolean> fixEating = this.rbool("Fix Eating", true);
    public Setting<HAND> hand = this.rother("Hand", HAND.MAINHAND);
    public Setting<PAGE> page = this.rother("Page", PAGE.BASIC);
    Setting<Double> mainX = this.rdoub("MainX", 1.2, 0.0, 6.0, v -> this.hm() && this.pb());
    Setting<Double> mainY = this.rdoub("MainY", -0.95, -3.0, 3.0, v -> this.hm() && this.pb());
    Setting<Double> mainZ = this.rdoub("MainZ", -1.45, -5.0, 5.0, v -> this.hm() && this.pb());
    Setting<Double> offX = this.rdoub("OffX", -1.2, -6.0, 0.0, v -> this.ho() && this.pb());
    Setting<Double> offY = this.rdoub("OffY", -0.95, -3.0, 3.0, v -> this.ho() && this.pb());
    Setting<Double> offZ = this.rdoub("OffZ", -1.45, -5.0, 5.0, v -> this.ho() && this.pb());
    Setting<Double> mainAngel = this.rdoub("MainAngle", 0.0, 0.0, 360.0, v -> this.hm() && this.pa());
    Setting<Double> offAngel = this.rdoub("OffAngle", 0.0, 0.0, 360.0, v -> this.ho() && this.pa());
    Setting<Double> mainRx = this.rdoub("MainRotationPointX", 0.0, -1.0, 1.0, v -> this.hm() && this.pr());
    Setting<Double> mainRy = this.rdoub("MainRotationPointY", 0.0, -1.0, 1.0, v -> this.hm() && this.pr());
    Setting<Double> mainRz = this.rdoub("MainRotationPointZ", 0.0, -1.0, 1.0, v -> this.hm() && this.pr());
    Setting<Double> offRx = this.rdoub("OffRotationPointX", 0.0, -1.0, 1.0, v -> this.ho() && this.pr());
    Setting<Double> offRy = this.rdoub("OffRotationPointY", 0.0, -1.0, 1.0, v -> this.ho() && this.pr());
    Setting<Double> offRz = this.rdoub("OffRotationPointZ", 0.0, -1.0, 1.0, v -> this.ho() && this.pr());
    Setting<Double> mainScaleX = this.rdoub("MainScaleX", 1.0, -5.0, 10.0, v -> this.hm() && this.ps());
    Setting<Double> mainScaleY = this.rdoub("MainScaleY", 1.0, -5.0, 10.0, v -> this.hm() && this.ps());
    Setting<Double> mainScaleZ = this.rdoub("MainScaleZ", 1.0, -5.0, 10.0, v -> this.hm() && this.ps());
    Setting<Double> offScaleX = this.rdoub("OffScaleX", 1.0, -5.0, 10.0, v -> this.ho() && this.ps());
    Setting<Double> offScaleY = this.rdoub("OffScaleY", 1.0, -5.0, 10.0, v -> this.ho() && this.ps());
    Setting<Double> offScaleZ = this.rdoub("OffScaleZ", 1.0, -5.0, 10.0, v -> this.ho() && this.ps());

    public ViewModel() {
        super(new I18NInfo("ViewModel").bind(EnumI18N.Chinese, "\u624b\u6301\u6a21\u578b\u6539\u53d8"), "Something Shit", Module.Category.RENDER);
    }

    public boolean hm() {
        return this.hand.getValue() == HAND.MAINHAND;
    }

    public boolean ho() {
        return this.hand.getValue() == HAND.OFFHAND;
    }

    public boolean pb() {
        return this.page.getValue() == PAGE.BASIC;
    }

    public boolean pa() {
        return this.page.getValue() == PAGE.ANGEL;
    }

    public boolean pr() {
        return this.page.getValue() == PAGE.ROTATION;
    }

    public boolean ps() {
        return this.page.getValue() == PAGE.SCALE;
    }

    @SubscribeEvent(priority=EventPriority.LOW)
    public void onItemRender(RenderItemEvent event) {
        if (ViewModel.nullCheck()) {
            return;
        }
        event.setMainX(this.mainX.getValue());
        event.setMainY(this.mainY.getValue());
        event.setMainZ(this.mainZ.getValue());
        event.setOffX(this.offX.getValue());
        event.setOffY(this.offY.getValue());
        event.setOffZ(this.offZ.getValue());
        event.setMainRAngel(this.mainAngel.getValue());
        event.setMainRx(this.mainRx.getValue());
        event.setMainRy(this.mainRy.getValue());
        event.setMainRz(this.mainRz.getValue());
        event.setOffRAngel(this.offAngel.getValue());
        event.setOffRx(this.offRx.getValue());
        event.setOffRy(this.offRy.getValue());
        event.setOffRz(this.offRz.getValue());
        event.setMainHandScaleX(this.mainScaleX.getValue());
        event.setMainHandScaleY(this.mainScaleY.getValue());
        event.setMainHandScaleZ(this.mainScaleZ.getValue());
        event.setOffHandScaleX(this.offScaleX.getValue());
        event.setOffHandScaleY(this.offScaleY.getValue());
        event.setOffHandScaleZ(this.offScaleZ.getValue());
        event.setFixAte(this.fixEating.getValue());
    }

    static enum PAGE {
        BASIC,
        ANGEL,
        ROTATION,
        SCALE;

    }

    static enum HAND {
        MAINHAND,
        OFFHAND;

    }
}

