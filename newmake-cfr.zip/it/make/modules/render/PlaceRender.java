/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 */
package it.make.modules.render;

import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.FadeUtils;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import java.awt.Color;
import java.util.HashMap;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class PlaceRender
extends Module {
    public static HashMap<BlockPos, placePosition> PlaceMap = new HashMap();
    public static PlaceRender INSTANCE;
    private final Setting<Integer> red = this.register(new Setting<Integer>("Red", 255, 1, 255));
    private final Setting<Integer> green = this.register(new Setting<Integer>("Green", 255, 1, 255));
    private final Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 255, 1, 255));
    private final Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 100, 1, 255));
    private final Setting<Integer> animationTime = this.register(new Setting<Integer>("animationTime", 1000, 0, 5000));
    private final Setting<Boolean> outline = this.register(new Setting<Boolean>("Outline", false));
    private final Setting<Boolean> box = this.register(new Setting<Boolean>("Box", true));

    public PlaceRender() {
        super(new I18NInfo("PlaceRender").bind(EnumI18N.Chinese, "\u653e\u7f6e\u6e32\u67d3"), "rebirth", Module.Category.RENDER);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        PlaceMap.clear();
    }

    @Override
    public void onDisable() {
        PlaceMap.clear();
    }

    public Color getNowColor() {
        return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }

    static int getAnimatime() {
        return PlaceRender.INSTANCE.animationTime.getValue();
    }

    private void drawBlock(BlockPos drawPos, double fade, Color color) {
        AxisAlignedBB axis = PlaceRender.mc.field_71441_e.func_180495_p(drawPos).func_185918_c((World)PlaceRender.mc.field_71441_e, drawPos);
        if (this.outline.getValue().booleanValue()) {
            RebirthUtil.RenderUtil.drawBBBox(axis, color, (int)((double)color.getAlpha() * -fade));
        }
        if (this.box.getValue().booleanValue()) {
            RebirthUtil.RenderUtil.drawBoxESP(drawPos, color, (int)((double)color.getAlpha() * -fade));
        }
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        boolean doclear = true;
        for (placePosition var4 : PlaceMap.values()) {
            if (var4.firstFade.easeOutQuad() == 1.0) continue;
            doclear = false;
            this.drawBlock(var4.pos, var4.firstFade.easeOutQuad() - 1.0, var4.posColor);
        }
        if (doclear) {
            PlaceMap.clear();
        }
    }

    public static void putMap(BlockPos pos) {
        if (INSTANCE.isDisabled()) {
            return;
        }
        PlaceMap.put(pos, new placePosition(pos));
    }

    public static class placePosition {
        public Color posColor;
        public BlockPos pos;
        public final FadeUtils firstFade = new FadeUtils(PlaceRender.getAnimatime());

        public placePosition(BlockPos placepos) {
            this.pos = placepos;
            this.posColor = INSTANCE.getNowColor();
        }
    }
}

