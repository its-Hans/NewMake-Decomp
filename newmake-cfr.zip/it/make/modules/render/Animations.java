/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemEgg
 *  net.minecraft.item.ItemElytra
 *  net.minecraft.item.ItemEnderEye
 *  net.minecraft.item.ItemEnderPearl
 *  net.minecraft.item.ItemExpBottle
 *  net.minecraft.item.ItemLingeringPotion
 *  net.minecraft.item.ItemSnowball
 *  net.minecraft.item.ItemSplashPotion
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.render;

import it.make.api.events.network.PacketEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemEnderEye;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemLingeringPotion;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemSplashPotion;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Animations
extends Module {
    private static Animations INSTANCE = new Animations();
    public final Setting<Boolean> customSwing = this.rbool("CustomSwingSpeed", false);
    public final Setting<Integer> swingSpeed = this.rinte("SwingSpeed", 6, 1, 30, v -> this.customSwing.getValue());
    private final Setting<Boolean> offSwing = this.rbool("OffhandSwing", false);
    private final Setting<Boolean> elseSwing = this.rbool("MoreSwings", false);
    private final Setting<Boolean> oldAnimation = this.rbool("OldSwitchAnimation", false);

    public Animations() {
        super(new I18NInfo("Animations").bind(EnumI18N.Chinese, "\u89c6\u89c9"), "Change animations.", Module.Category.RENDER);
        INSTANCE = this;
    }

    public static Animations getInstance() {
        return INSTANCE;
    }

    @Override
    public void onUpdate() {
        if (this.offSwing.getValue().booleanValue()) {
            Animations.mc.field_71439_g.field_184622_au = EnumHand.OFF_HAND;
        }
        if (this.oldAnimation.getValue().booleanValue()) {
            Animations.mc.field_71460_t.field_78516_c.field_187469_f = 1.0f;
            Animations.mc.field_71460_t.field_78516_c.field_187467_d = Animations.mc.field_71439_g.func_184614_ca();
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        Object got = event.getPacket();
        if (got instanceof CPacketPlayerDigging) {
            CPacketPlayerDigging packet = (CPacketPlayerDigging)got;
            CPacketPlayerDigging.Action action = packet.func_180762_c();
            if (this.elseSwing.getValue().booleanValue()) {
                Object enumHand;
                if (action == CPacketPlayerDigging.Action.RELEASE_USE_ITEM && (enumHand = !Animations.mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_190926_b() ? EnumHand.MAIN_HAND : (!Animations.mc.field_71439_g.func_184586_b(EnumHand.OFF_HAND).func_190926_b() ? EnumHand.OFF_HAND : null)) != null && Animations.mc.field_71439_g.func_184586_b(enumHand).func_77973_b() instanceof ItemBow) {
                    Animations.mc.field_71439_g.func_184609_a(enumHand);
                }
                if (!(action != CPacketPlayerDigging.Action.DROP_ITEM && action != CPacketPlayerDigging.Action.DROP_ALL_ITEMS || Animations.mc.field_71439_g.func_184614_ca().func_190926_b())) {
                    Animations.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                }
            }
        }
        if (got instanceof CPacketPlayerTryUseItem) {
            EnumHand enumHand = ((CPacketPlayerTryUseItem)got).func_187028_a();
            Item held = Animations.mc.field_71439_g.func_184586_b(enumHand).func_77973_b();
            if (this.elseSwing.getValue().booleanValue() && (held instanceof ItemExpBottle || held instanceof ItemSnowball || held instanceof ItemEgg || held instanceof ItemLingeringPotion || held instanceof ItemSplashPotion || held instanceof ItemEnderPearl || held instanceof ItemEnderEye || held instanceof ItemElytra || held instanceof ItemArmor)) {
                Animations.mc.field_71439_g.func_184609_a(enumHand);
            }
        }
    }
}

