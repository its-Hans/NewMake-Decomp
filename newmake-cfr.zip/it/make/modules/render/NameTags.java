/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 */
package it.make.modules.render;

import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.modules.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class NameTags
extends Module {
    public NameTags() {
        super(new I18NInfo("NameTags").bind(EnumI18N.Chinese, "\u4e0d\u77e5\u9053\u6807\u7b7e"), "IDK", Module.Category.RENDER);
    }

    private void drawNameTags(EntityPlayer player) {
        String text = String.format("\u00a7a[\u00a7f%.0f\u00a7a]\u00a7r \u00a7f%s\u00a7r \u00a7f:\u00a7r %.1f", Float.valueOf(player.func_70032_d((Entity)NameTags.mc.field_71439_g)), player.func_145748_c_().func_150260_c(), Float.valueOf(player.func_110143_aJ()));
        float health = player.func_110143_aJ() / player.func_110138_aP();
        int color = (double)health > 0.6 ? -16711936 : ((double)health > 0.3 ? -256 : -65536);
        GlStateManager.func_179094_E();
        double xx = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78730_l;
        double yy = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78731_m;
        double zz = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * (double)mc.func_184121_ak() - NameTags.mc.func_175598_ae().field_78728_n;
        GlStateManager.func_179137_b((double)xx, (double)(yy + 2.0), (double)zz);
        GlStateManager.func_187432_a((float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)(-NameTags.mc.field_71439_g.field_70177_z), (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.func_179114_b((float)NameTags.mc.field_71439_g.field_70125_A, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.func_179152_a((float)-0.02666667f, (float)-0.02666667f, (float)0.02666667f);
        double distance = player.func_70032_d((Entity)NameTags.mc.field_71439_g);
        float scaleDistance = (float)distance / 2.0f / 3.0f;
        if (scaleDistance < 0.5f) {
            scaleDistance = 0.5f;
        }
        GlStateManager.func_179152_a((float)scaleDistance, (float)scaleDistance, (float)scaleDistance);
        GlStateManager.func_179097_i();
        GlStateManager.func_179137_b((double)(-((double)NameTags.mc.field_71466_p.func_78256_a(text) / 2.0)), (double)(-NameTags.mc.field_71466_p.field_78288_b), (double)0.0);
        NameTags.drawRect(-1.0f, -1.0f, NameTags.mc.field_71466_p.func_78256_a(text) + 2, NameTags.mc.field_71466_p.field_78288_b + 1, -1090519040);
        NameTags.mc.field_71466_p.func_175063_a(text, 0.0f, 0.0f, color);
        GlStateManager.func_179126_j();
        GlStateManager.func_179121_F();
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        NameTags.mc.field_71441_e.field_72996_f.stream().filter(entity -> entity instanceof EntityPlayer).filter(entity -> entity != NameTags.mc.field_71439_g).map(EntityPlayer.class::cast).forEach(this::drawNameTags);
    }

    public static void drawRect(float x, float y, float width, float height, int color) {
        GuiScreen.func_73734_a((int)((int)x), (int)((int)y), (int)((int)(x + width)), (int)((int)(y + height)), (int)color);
    }
}

