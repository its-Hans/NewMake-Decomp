/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.render;

import it.make.api.events.render.RenderGuiEvent;
import it.make.modules.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoPotionRender
extends Module {
    public NoPotionRender() {
        super("NoPotionRender", "remove the shitty potion gameoverlay", Module.Category.RENDER);
    }

    @SubscribeEvent
    public void onDrawGui(RenderGuiEvent event) {
        if (event.gui == RenderGuiEvent.Guis.PotionEffect) {
            event.setCanceled(true);
        }
    }
}

