/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.render;

import it.make.api.events.block.DamageBlockEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.FadeUtils;
import it.make.api.utils.second.skid.RenderUtil;
import it.make.modules.Module;
import java.awt.Color;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BreakESP
extends Module {
    public static BreakESP INSTANCE = new BreakESP();
    static final HashMap<EntityPlayer, MinePosition> MineMap = new HashMap();
    Setting<Boolean> renderAir = this.rbool("RenderAir", true);
    Setting<Boolean> renderUnknown = this.rbool("RenderUnknown", true);
    Setting<Double> range = this.rdoub("Range", 15.0, 0.0, 50.0);
    Setting<Mode> animationMode = this.rother("AnimationMode", Mode.Up);
    Setting<Integer> animationTime = this.rinte("AnimationTime", 1000, 0, 5000);
    Setting<Boolean> box = this.rbool("Box", true);
    Setting<Integer> boxAlpha = this.rinte("BoxAlpha", 30, 0, 255, v -> this.box.getValue());
    Setting<Boolean> outline = this.rbool("Outline", true);
    Setting<Integer> outlineAlpha = this.rinte("OutlineAlpha", 100, 0, 255, v -> this.outline.getValue());
    Setting<Integer> color1r = this.rinte("ColorRed", 255, 0, 255);
    Setting<Integer> color1g = this.rinte("ColorGreen", 255, 0, 255);
    Setting<Integer> color1b = this.rinte("ColorBlue", 255, 0, 255);
    Setting<Boolean> doubleRender = this.rbool("DoubleRender", false);
    Setting<Integer> color2r = this.rinte("SecondRed", 255, 0, 255, v -> this.doubleRender.getValue());
    Setting<Integer> color2g = this.rinte("SecondGreen", 255, 0, 255, v -> this.doubleRender.getValue());
    Setting<Integer> color2b = this.rinte("SecondBlue", 255, 0, 255, v -> this.doubleRender.getValue());

    public BreakESP() {
        super(new I18NInfo("BreakESP").bind(EnumI18N.Chinese, "\u6316\u6398\u663e\u793a"), "Show mine postion", Module.Category.RENDER);
        INSTANCE = this;
    }

    @Override
    public void onDisable() {
        MineMap.clear();
    }

    @SubscribeEvent
    public void BlockBreak(DamageBlockEvent event) {
        if (event.getPosition().func_177956_o() == -1) {
            return;
        }
        EntityPlayer breaker = (EntityPlayer)BreakESP.mc.field_71441_e.func_73045_a(event.getBreakerId());
        if (breaker == null || breaker.func_70011_f((double)event.getPosition().func_177958_n() + 0.5, (double)event.getPosition().func_177956_o(), (double)event.getPosition().func_177952_p() + 0.5) > 7.0) {
            return;
        }
        if (!MineMap.containsKey(breaker)) {
            MineMap.put(breaker, new MinePosition(breaker));
        }
        MineMap.get(breaker).update(event.getPosition());
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        EntityPlayer[] array = MineMap.keySet().toArray(new EntityPlayer[0]);
        for (EntityPlayer entityPlayer : array) {
            if (entityPlayer == null || entityPlayer.func_70089_S()) continue;
            MineMap.remove(entityPlayer);
        }
        for (MinePosition miner : MineMap.values()) {
            if (!this.renderAir.getValue().booleanValue() && BreakESP.mc.field_71441_e.func_175623_d(miner.first)) {
                miner.finishFirst();
            }
            if (!(miner.firstFinished && !this.renderAir.getValue().booleanValue() || miner.miner == BreakESP.mc.field_71439_g || miner.first.func_185332_f((int)BreakESP.mc.field_71439_g.field_70165_t, (int)BreakESP.mc.field_71439_g.field_70163_u, (int)BreakESP.mc.field_71439_g.field_70161_v) > this.range.getValue() || miner.miner == null && !this.renderUnknown.getValue().booleanValue())) {
                this.draw(miner.first, miner.firstFade.easeOutQuad(), this.getFirstColor());
            }
            if (miner.miner == BreakESP.mc.field_71439_g || miner.secondFinished || miner.second == null) continue;
            if (BreakESP.mc.field_71441_e.func_175623_d(miner.second)) {
                miner.finishSecond();
                continue;
            }
            if (miner.second.equals((Object)miner.first) || !(miner.second.func_185332_f((int)BreakESP.mc.field_71439_g.field_70165_t, (int)BreakESP.mc.field_71439_g.field_70163_u, (int)BreakESP.mc.field_71439_g.field_70161_v) < this.range.getValue()) || miner.miner == null && !this.renderUnknown.getValue().booleanValue() || !this.doubleRender.getValue().booleanValue()) continue;
            this.draw(miner.second, miner.secondFade.easeOutQuad(), this.getSecondColor());
        }
    }

    public void draw(BlockPos pos, double size, Color color) {
        if (this.animationMode.getValue() != Mode.Both) {
            AxisAlignedBB axisAlignedBB;
            if (this.animationMode.getValue() == Mode.InToOut) {
                axisAlignedBB = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
            } else if (this.animationMode.getValue() == Mode.Up) {
                AxisAlignedBB bb = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos);
                axisAlignedBB = new AxisAlignedBB(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * size, bb.field_72334_f);
            } else if (this.animationMode.getValue() == Mode.Down) {
                AxisAlignedBB bb = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos);
                axisAlignedBB = new AxisAlignedBB(bb.field_72340_a, bb.field_72337_e - (bb.field_72337_e - bb.field_72338_b) * size, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
            } else if (this.animationMode.getValue() == Mode.None) {
                axisAlignedBB = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos);
            } else {
                AxisAlignedBB bb = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
                AxisAlignedBB bb2 = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos);
                AxisAlignedBB axisAlignedBB2 = axisAlignedBB = this.animationMode.getValue() == Mode.Horizontal ? new AxisAlignedBB(bb2.field_72340_a, bb.field_72338_b, bb2.field_72339_c, bb2.field_72336_d, bb.field_72337_e, bb2.field_72334_f) : new AxisAlignedBB(bb.field_72340_a, bb2.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb2.field_72337_e, bb.field_72334_f);
            }
            if (this.outline.getValue().booleanValue()) {
                RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
        } else {
            AxisAlignedBB axisAlignedBB = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
            if (this.outline.getValue().booleanValue()) {
                RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
            axisAlignedBB = BreakESP.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)BreakESP.mc.field_71441_e, pos).func_186662_g(-Math.abs(size / 2.0 - 1.0));
            if (this.outline.getValue().booleanValue()) {
                RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
        }
    }

    public Color getFirstColor() {
        return new Color(this.color1r.getValue(), this.color1g.getValue(), this.color1b.getValue());
    }

    public Color getSecondColor() {
        return new Color(this.color2r.getValue(), this.color2g.getValue(), this.color2b.getValue());
    }

    private static class MinePosition {
        public final EntityPlayer miner;
        public FadeUtils firstFade;
        public FadeUtils secondFade;
        public BlockPos first;
        public BlockPos second;
        public boolean secondFinished;
        public boolean firstFinished;

        public MinePosition(EntityPlayer player) {
            this.firstFade = new FadeUtils(BreakESP.INSTANCE.animationTime.getValue().intValue());
            this.secondFade = new FadeUtils(BreakESP.INSTANCE.animationTime.getValue().intValue());
            this.miner = player;
            this.secondFinished = true;
        }

        public void finishSecond() {
            this.secondFinished = true;
        }

        public void finishFirst() {
            this.firstFinished = true;
        }

        public void update(BlockPos pos) {
            if (this.first != null && this.first.equals((Object)pos) && BreakESP.INSTANCE.renderAir.getValue().booleanValue()) {
                return;
            }
            if (this.secondFinished || this.second == null) {
                this.second = pos;
                this.secondFinished = false;
                this.secondFade = new FadeUtils(BreakESP.INSTANCE.animationTime.getValue().intValue());
            }
            if (this.first == null || !this.first.equals((Object)pos) || this.firstFinished) {
                this.firstFade = new FadeUtils(BreakESP.INSTANCE.animationTime.getValue().intValue());
            }
            this.firstFinished = false;
            this.first = pos;
        }
    }

    public static enum Mode {
        Down,
        Up,
        InToOut,
        Both,
        Vertical,
        Horizontal,
        None;

    }
}

