/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.item.EntityExpBottle
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.projectile.EntityArrow
 *  net.minecraft.init.Blocks
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.Item
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.modules.Module;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class NewBurrow
extends Module {
    private final Setting<Boolean> placeDisable = this.rbool("PlaceDisable", false);
    private final Setting<Boolean> wait = this.rbool("Wait", true);
    private final Setting<Boolean> switchBypass = this.rbool("SwitchBypass", false);
    private final Setting<Boolean> rotate = this.rbool("Rotate", true);
    private final Setting<Boolean> onlyGround = this.rbool("OnlyGround", true);
    private final Setting<Boolean> airCheck = this.rbool("OnlyGround-AirCheck", true, v -> this.onlyGround.getValue());
    private final Setting<Boolean> aboveHead = this.rbool("AboveHead", true);
    private final Setting<Boolean> center = this.rbool("AboveHead-Center", false, v -> this.aboveHead.getValue());
    private final Setting<Boolean> breakCrystal = this.rbool("BreakCrystal", true);
    public final Setting<Float> safeHealth = this.rfloa("BreakCrystal-SafeHealth", Float.valueOf(16.0f), Float.valueOf(0.0f), Float.valueOf(36.0f), v -> this.breakCrystal.getValue());
    private final Setting<Integer> multiPlace = this.rinte("MultiPlace", 1, 1, 4);
    private final Setting<Integer> timeOut = this.rinte("TimeOut", 10, 0, 2000);
    private final Setting<Integer> delay = this.rinte("delay", 300, 0, 1000);
    private final Setting<Boolean> smartOffset = this.rbool("SmartOffset", true);
    private final Setting<Double> offsetX = this.rdoub("OffsetX", -7.0, -14.0, 14.0, v -> this.smartOffset.getValue() == false);
    private final Setting<Double> offsetY = this.rdoub("OffsetY", -7.0, -14.0, 14.0, v -> this.smartOffset.getValue() == false);
    private final Setting<Double> offsetZ = this.rdoub("OffsetZ", -7.0, -14.0, 14.0, v -> this.smartOffset.getValue() == false);
    private final Setting<Boolean> debug = this.rbool("Debug", false);
    int progress = 0;
    private final Timer timer = new Timer();
    private final Timer timedOut = new Timer();
    public static NewBurrow INSTANCE;
    private boolean shouldWait = false;

    public NewBurrow() {
        super(new I18NInfo("NewBurrow").bind(EnumI18N.Chinese, "\u65b0Burrow"), "COOL", Module.Category.PLAYER);
        INSTANCE = this;
    }

    private static boolean checkSelf(BlockPos pos) {
        for (Vec3d vec3d : RebirthUtil.getVarOffsets(0, 0, 0)) {
            BlockPos position = new BlockPos((Vec3i)pos).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
            for (Entity entity : NewBurrow.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(position))) {
                if (entity != NewBurrow.mc.field_71439_g) continue;
                return true;
            }
        }
        return false;
    }

    private static boolean isAir(BlockPos pos) {
        return NewBurrow.mc.field_71441_e.func_175623_d(pos);
    }

    private static boolean Trapped(BlockPos pos) {
        return !NewBurrow.mc.field_71441_e.func_175623_d(pos) && NewBurrow.checkSelf(pos.func_177979_c(2));
    }

    public static boolean canReplace(BlockPos pos) {
        return NewBurrow.mc.field_71441_e.func_180495_p(pos).func_185904_a().func_76222_j();
    }

    @Override
    public void onEnable() {
        this.timedOut.reset();
        this.shouldWait = this.wait.getValue();
    }

    @Override
    public void onDisable() {
        this.timer.reset();
        this.shouldWait = false;
    }

    @Override
    public void onUpdate() {
        int blockSlot;
        this.progress = 0;
        int n = !this.switchBypass.getValue().booleanValue() ? (RebirthUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)) != -1 ? RebirthUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)) : RebirthUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB))) : (blockSlot = RebirthUtil.findItemInventorySlot(Item.func_150898_a((Block)Blocks.field_150343_Z), false, true) != -1 ? RebirthUtil.findItemInventorySlot(Item.func_150898_a((Block)Blocks.field_150343_Z), false, true) : RebirthUtil.findItemInventorySlot(Item.func_150898_a((Block)Blocks.field_150477_bB), false, true));
        if (blockSlot == -1) {
            this.sendModuleMessage(ChatFormatting.RED + "Obsidian/Ender Chest ?");
            this.disable();
            return;
        }
        if (this.timedOut.passedMs(this.timeOut.getValue().intValue())) {
            this.disable();
            return;
        }
        BlockPos originalPos = RebirthUtil.getPlayerPos();
        if (!(this.canPlace(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3)) || this.canPlace(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3)) || this.canPlace(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3)) || this.canPlace(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3)))) {
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage("cant place");
            }
            if (!this.shouldWait) {
                this.disable();
            }
            return;
        }
        if (NewBurrow.mc.field_71439_g.func_180799_ab() || NewBurrow.mc.field_71439_g.func_70090_H() || NewBurrow.mc.field_71439_g.field_70134_J) {
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage("player stuck");
            }
            return;
        }
        if (this.onlyGround.getValue().booleanValue()) {
            if (!NewBurrow.mc.field_71439_g.field_70122_E) {
                if (this.debug.getValue().booleanValue()) {
                    this.sendModuleMessage("player not on ground");
                }
                return;
            }
            if (this.airCheck.getValue().booleanValue() && NewBurrow.isAir(RebirthUtil.getPlayerPos().func_177977_b())) {
                if (this.debug.getValue().booleanValue()) {
                    this.sendModuleMessage("player in air");
                }
                return;
            }
        }
        if (!this.timer.passedMs(this.delay.getValue().intValue())) {
            return;
        }
        if (this.breakCrystal.getValue().booleanValue() && RebirthUtil.getHealth((Entity)NewBurrow.mc.field_71439_g) >= this.safeHealth.getValue().floatValue()) {
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage("try break crystal");
            }
            RebirthUtil.attackCrystal(originalPos, (boolean)this.rotate.getValue(), false);
            RebirthUtil.attackCrystal(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3), (boolean)this.rotate.getValue(), false);
            RebirthUtil.attackCrystal(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3), (boolean)this.rotate.getValue(), false);
            RebirthUtil.attackCrystal(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3), (boolean)this.rotate.getValue(), false);
            RebirthUtil.attackCrystal(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3), (boolean)this.rotate.getValue(), false);
        }
        this.timer.reset();
        this.shouldWait = false;
        BlockPos headPos = RebirthUtil.getPlayerPos().func_177981_b(2);
        if (NewBurrow.Trapped(headPos) || NewBurrow.Trapped(headPos.func_177982_a(1, 0, 0)) || NewBurrow.Trapped(headPos.func_177982_a(-1, 0, 0)) || NewBurrow.Trapped(headPos.func_177982_a(0, 0, 1)) || NewBurrow.Trapped(headPos.func_177982_a(0, 0, -1)) || NewBurrow.Trapped(headPos.func_177982_a(1, 0, -1)) || NewBurrow.Trapped(headPos.func_177982_a(-1, 0, -1)) || NewBurrow.Trapped(headPos.func_177982_a(1, 0, 1)) || NewBurrow.Trapped(headPos.func_177982_a(-1, 0, 1))) {
            if (!this.aboveHead.getValue().booleanValue()) {
                if (!this.shouldWait) {
                    this.disable();
                }
                return;
            }
            boolean moved = false;
            BlockPos offPos = originalPos;
            if (NewBurrow.checkSelf(offPos) && !NewBurrow.canReplace(offPos)) {
                this.gotoPos(offPos);
                if (this.debug.getValue().booleanValue()) {
                    this.sendModuleMessage("moved to center " + ((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t) + " " + ((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v));
                }
            } else {
                for (EnumFacing facing : EnumFacing.field_82609_l) {
                    if (facing == EnumFacing.UP || facing == EnumFacing.DOWN || !NewBurrow.checkSelf(offPos = originalPos.func_177972_a(facing)) || NewBurrow.canReplace(offPos)) continue;
                    this.gotoPos(offPos);
                    moved = true;
                    if (!this.debug.getValue().booleanValue()) break;
                    this.sendModuleMessage("moved to block " + ((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t) + " " + ((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v));
                    break;
                }
                if (!moved) {
                    for (EnumFacing facing : EnumFacing.field_82609_l) {
                        if (facing == EnumFacing.UP || facing == EnumFacing.DOWN || !NewBurrow.checkSelf(offPos = originalPos.func_177972_a(facing))) continue;
                        this.gotoPos(offPos);
                        moved = true;
                        if (!this.debug.getValue().booleanValue()) break;
                        this.sendModuleMessage("moved to entity " + ((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t) + " " + ((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v));
                        break;
                    }
                    if (!moved) {
                        if (!this.center.getValue().booleanValue()) {
                            if (!this.shouldWait) {
                                this.disable();
                            }
                            return;
                        }
                        for (EnumFacing facing : EnumFacing.field_82609_l) {
                            if (facing == EnumFacing.UP || facing == EnumFacing.DOWN || !NewBurrow.canReplace(offPos = originalPos.func_177972_a(facing)) || !NewBurrow.canReplace(offPos.func_177984_a())) continue;
                            this.gotoPos(offPos);
                            if (this.debug.getValue().booleanValue()) {
                                this.sendModuleMessage("moved to air " + ((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t) + " " + ((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v));
                            }
                            moved = true;
                            break;
                        }
                        if (!moved) {
                            if (!this.shouldWait) {
                                this.disable();
                            }
                            return;
                        }
                    }
                }
            }
        } else {
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage("fake jump");
            }
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, NewBurrow.mc.field_71439_g.field_70163_u + 0.4199999868869781, NewBurrow.mc.field_71439_g.field_70161_v, false));
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, NewBurrow.mc.field_71439_g.field_70163_u + 0.7531999805212017, NewBurrow.mc.field_71439_g.field_70161_v, false));
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, NewBurrow.mc.field_71439_g.field_70163_u + 0.9999957640154541, NewBurrow.mc.field_71439_g.field_70161_v, false));
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, NewBurrow.mc.field_71439_g.field_70163_u + 1.1661092609382138, NewBurrow.mc.field_71439_g.field_70161_v, false));
        }
        int oldSlot = NewBurrow.mc.field_71439_g.field_71071_by.field_70461_c;
        if (!this.switchBypass.getValue().booleanValue()) {
            RebirthUtil.doSwap(blockSlot);
        } else {
            NewBurrow.mc.field_71442_b.func_187098_a(0, blockSlot, oldSlot, ClickType.SWAP, (EntityPlayer)NewBurrow.mc.field_71439_g);
        }
        this.placeBlock(originalPos);
        this.placeBlock(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3));
        this.placeBlock(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t + 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3));
        this.placeBlock(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v + 0.3));
        this.placeBlock(new BlockPos(NewBurrow.mc.field_71439_g.field_70165_t - 0.3, NewBurrow.mc.field_71439_g.field_70163_u + 0.5, NewBurrow.mc.field_71439_g.field_70161_v - 0.3));
        if (!this.switchBypass.getValue().booleanValue()) {
            RebirthUtil.doSwap(oldSlot);
        } else {
            NewBurrow.mc.field_71442_b.func_187098_a(0, blockSlot, oldSlot, ClickType.SWAP, (EntityPlayer)NewBurrow.mc.field_71439_g);
        }
        if (this.smartOffset.getValue().booleanValue()) {
            double distance = 0.0;
            BlockPos bestPos = null;
            for (BlockPos pos : RebirthUtil.getBox(6.0f)) {
                if (this.cantGoto(pos) || NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5) <= 3.0 || bestPos != null && !(NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5) < distance)) continue;
                bestPos = pos;
                distance = NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5);
            }
            if (bestPos != null) {
                NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position((double)bestPos.func_177958_n() + 0.5, (double)bestPos.func_177956_o(), (double)bestPos.func_177952_p() + 0.5, false));
            } else {
                for (BlockPos pos : RebirthUtil.getBox(6.0f)) {
                    if (this.cantGoto(pos) || NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5) <= 2.0 || bestPos != null && !(NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5) < distance)) continue;
                    bestPos = pos;
                    distance = NewBurrow.mc.field_71439_g.func_70011_f((double)pos.func_177958_n() + 0.5, (double)pos.func_177956_o() + 0.5, (double)pos.func_177952_p() + 0.5);
                }
                if (bestPos != null) {
                    NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position((double)bestPos.func_177958_n() + 0.5, (double)bestPos.func_177956_o(), (double)bestPos.func_177952_p() + 0.5, false));
                } else {
                    NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, -7.0, NewBurrow.mc.field_71439_g.field_70161_v, false));
                }
            }
        } else {
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t + this.offsetX.getValue(), NewBurrow.mc.field_71439_g.field_70163_u + this.offsetY.getValue(), NewBurrow.mc.field_71439_g.field_70161_v + this.offsetZ.getValue(), false));
        }
        if (this.placeDisable.getValue().booleanValue()) {
            this.disable();
        }
    }

    private void gotoPos(BlockPos offPos) {
        if (Math.abs((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t) < Math.abs((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v)) {
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t, NewBurrow.mc.field_71439_g.field_70163_u + 0.2, NewBurrow.mc.field_71439_g.field_70161_v + ((double)offPos.func_177952_p() + 0.5 - NewBurrow.mc.field_71439_g.field_70161_v), true));
        } else {
            NewBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(NewBurrow.mc.field_71439_g.field_70165_t + ((double)offPos.func_177958_n() + 0.5 - NewBurrow.mc.field_71439_g.field_70165_t), NewBurrow.mc.field_71439_g.field_70163_u + 0.2, NewBurrow.mc.field_71439_g.field_70161_v, true));
        }
    }

    private boolean cantGoto(BlockPos pos) {
        return !NewBurrow.isAir(pos) || !NewBurrow.isAir(pos.func_177984_a());
    }

    private void placeBlock(BlockPos pos) {
        if (this.progress >= this.multiPlace.getValue()) {
            return;
        }
        if (this.canPlace(pos)) {
            RebirthUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, this.breakCrystal.getValue(), false);
            ++this.progress;
        }
    }

    private boolean canPlace(BlockPos pos) {
        if (!RebirthUtil.canBlockFacing(pos)) {
            return false;
        }
        if (!NewBurrow.canReplace(pos)) {
            return false;
        }
        return !this.checkEntity(pos);
    }

    private boolean checkEntity(BlockPos pos) {
        for (Entity entity : NewBurrow.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos))) {
            if (entity.field_70128_L || entity instanceof EntityItem || entity instanceof EntityXPOrb || entity instanceof EntityExpBottle || entity instanceof EntityArrow) continue;
            if (entity instanceof EntityEnderCrystal) {
                if (this.breakCrystal.getValue().booleanValue() && !(RebirthUtil.getHealth((Entity)NewBurrow.mc.field_71439_g) < this.safeHealth.getValue().floatValue())) continue;
            } else if (entity == NewBurrow.mc.field_71439_g) continue;
            return true;
        }
        return false;
    }
}

