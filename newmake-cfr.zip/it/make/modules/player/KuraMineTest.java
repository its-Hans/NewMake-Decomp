/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.network.NetHandlerPlayClient
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketClickWindow
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent$ClientDisconnectionFromServerEvent
 */
package it.make.modules.player;

import it.make.Client;
import it.make.api.events.block.SelfDamageBlockEvent;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.m4ke.render.BlockAnimation;
import it.make.modules.Module;
import java.awt.Color;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\u008a\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0014\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u001c\u0010!\u001a\u00020\u00142\b\u0010\"\u001a\u0004\u0018\u00010#2\b\u0010$\u001a\u0004\u0018\u00010#H\u0002J\u001c\u0010!\u001a\u00020\u00142\b\u0010%\u001a\u0004\u0018\u00010&2\b\u0010'\u001a\u0004\u0018\u00010#H\u0002J\u001a\u0010(\u001a\u00020\u00142\b\u0010)\u001a\u0004\u0018\u00010\f2\u0006\u0010*\u001a\u00020\u0014H\u0002J\u0012\u0010+\u001a\u00020\u00052\b\u0010'\u001a\u0004\u0018\u00010#H\u0002J\b\u0010,\u001a\u00020-H\u0016J\b\u0010.\u001a\u00020/H\u0002J\u000e\u00100\u001a\u0002012\u0006\u00102\u001a\u00020\fJ\u0010\u00103\u001a\u0002042\u0006\u00105\u001a\u000206H\u0007J\b\u00107\u001a\u000204H\u0016J\u0012\u00108\u001a\u0002042\b\u00105\u001a\u0004\u0018\u000109H\u0007J\b\u0010:\u001a\u000204H\u0016J\u0012\u0010;\u001a\u0002042\b\u00105\u001a\u0004\u0018\u00010<H\u0016J\u0010\u0010=\u001a\u0002042\u0006\u00105\u001a\u00020>H\u0007J\b\u0010?\u001a\u000204H\u0016J\u0010\u0010@\u001a\u0002042\u0006\u0010A\u001a\u00020\u0005H\u0002R2\u0010\u0003\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\u0004\u0018\u00010\f8\u0006@\u0006X\u0087\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\r\u001a\u0004\u0018\u00010\u000eX\u0086\u000e\u00a2\u0006\u000e\n\u0000\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R2\u0010\u0013\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0015\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0016\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0017\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0018\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u0019\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u001a\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\u001cX\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u001d\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u001e\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010\u001f\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000R2\u0010 \u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00140\u0014\u0018\u00010\u00040\u0004X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006B"}, d2={"Lit/make/modules/player/KuraMineTest;", "Lit/make/modules/Module;", "()V", "alpha", "Lit/make/api/setting/Setting;", "", "kotlin.jvm.PlatformType", "br", "Lit/make/api/utils/second/m4ke/render/BlockAnimation;", "currentBlockState", "Lnet/minecraft/block/state/IBlockState;", "currentPos", "Lnet/minecraft/util/math/BlockPos;", "facing", "Lnet/minecraft/util/EnumFacing;", "getFacing", "()Lnet/minecraft/util/EnumFacing;", "setFacing", "(Lnet/minecraft/util/EnumFacing;)V", "firstIn", "", "packet", "range", "render", "renderSpd", "rotate", "strict", "strictTimer", "Lit/make/api/utils/Timer;", "superGhostHand", "superStrict", "swap", "swing", "areSame", "item1", "Lnet/minecraft/item/Item;", "item2", "stack", "Lnet/minecraft/item/ItemStack;", "item", "canBreak", "pos", "air", "findHotbarItem", "getDisplayInfo", "", "getEyesPos", "Lnet/minecraft/util/math/Vec3d;", "getLegitRotations", "", "vec", "onBlockEvent", "", "event", "Lit/make/api/events/block/SelfDamageBlockEvent$Port3;", "onDisable", "onDisconnect", "Lnet/minecraftforge/fml/common/network/FMLNetworkEvent$ClientDisconnectionFromServerEvent;", "onEnable", "onRender3D", "Lit/make/api/events/render/Render3DEvent;", "onTick", "Lit/make/api/events/player/UpdateWalkingPlayerEvent;", "onToggle", "switchToSlot", "slot", "Make.Life"})
public final class KuraMineTest
extends Module {
    @NotNull
    private Timer strictTimer = new Timer();
    private Setting<Integer> renderSpd = this.rinte("RenderSpeed", 50, 1, 200);
    private Setting<Boolean> packet = this.rbool("PacketOnly", false);
    private Setting<Boolean> swap = this.rbool("SwapMine", true);
    private Setting<Boolean> superGhostHand = this.rbool("GhostHandBypass", false, arg_0 -> KuraMineTest.superGhostHand$lambda-0(this, arg_0));
    private Setting<Boolean> swing = this.rbool("Swing", false);
    private Setting<Boolean> rotate = this.rbool("Rotate", false);
    private Setting<Boolean> render = this.rbool("Render", true);
    private Setting<Boolean> firstIn = this.rbool("FirstIn", true, arg_0 -> KuraMineTest.firstIn$lambda-1(this, arg_0));
    private Setting<Integer> alpha = this.rinte("Alpha", 30, 0, 255, arg_0 -> KuraMineTest.alpha$lambda-2(this, arg_0));
    private Setting<Integer> range = this.rinte("Range", 6, 0, 10);
    private Setting<Boolean> strict = this.rbool("Strict", true);
    private Setting<Boolean> superStrict = this.rbool("SuperStrict", false, arg_0 -> KuraMineTest.superStrict$lambda-3(this, arg_0));
    @NotNull
    private BlockAnimation br;
    @Nullable
    private IBlockState currentBlockState;
    @Nullable
    private EnumFacing facing;
    @JvmField
    @Nullable
    public BlockPos currentPos;

    public KuraMineTest() {
        super("KuraMineTest", "", Module.Category.PLAYER);
        Boolean bl = this.firstIn.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "firstIn.value");
        boolean bl2 = bl;
        Integer n = this.renderSpd.getValue();
        Intrinsics.checkNotNullExpressionValue(n, "renderSpd.value");
        this.br = new BlockAnimation(true, bl2, ((Number)n).intValue());
    }

    @Nullable
    public final EnumFacing getFacing() {
        return this.facing;
    }

    public final void setFacing(@Nullable EnumFacing enumFacing) {
        this.facing = enumFacing;
    }

    @SubscribeEvent
    public final void onDisconnect(@Nullable FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
        this.currentPos = null;
        this.facing = null;
        Boolean bl = this.firstIn.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "firstIn.value");
        boolean bl2 = bl;
        Integer n = this.renderSpd.getValue();
        Intrinsics.checkNotNullExpressionValue(n, "renderSpd.value");
        this.br = new BlockAnimation(true, bl2, ((Number)n).intValue());
    }

    @Override
    public void onToggle() {
        Boolean bl = this.firstIn.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "firstIn.value");
        boolean bl2 = bl;
        Integer n = this.renderSpd.getValue();
        Intrinsics.checkNotNullExpressionValue(n, "renderSpd.value");
        this.br = new BlockAnimation(true, bl2, ((Number)n).intValue());
    }

    private final boolean areSame(ItemStack stack, Item item) {
        return stack != null && this.areSame(item, stack.func_77973_b());
    }

    private final boolean areSame(Item item1, Item item2) {
        return Item.func_150891_b((Item)item1) == Item.func_150891_b((Item)item2);
    }

    private final int findHotbarItem(Item item) {
        if (this.areSame(Module.mc.field_71439_g.func_184592_cb(), item)) {
            return -2;
        }
        int result = -1;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = Module.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (!this.areSame(stack, item)) continue;
            result = i;
            if (Module.mc.field_71439_g.field_71071_by.field_70461_c == i) break;
        }
        return result;
    }

    private final boolean canBreak(BlockPos pos, boolean air) {
        if (pos == null) {
            return false;
        }
        IBlockState blockState = Module.mc.field_71441_e.func_180495_p(pos);
        Block block = blockState.func_177230_c();
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a) {
            return air;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150357_h) {
            return false;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150378_br) {
            return false;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150384_bq) {
            return false;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150355_j) {
            return false;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150358_i) {
            return false;
        }
        if (Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150353_l) {
            return false;
        }
        return Module.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150356_k ? false : !(block.func_176195_g(blockState, (World)Module.mc.field_71441_e, pos) == -1.0f);
    }

    @SubscribeEvent
    public final void onBlockEvent(@NotNull SelfDamageBlockEvent.Port3 event) {
        Intrinsics.checkNotNullParameter((Object)event, "event");
        if (Module.fullNullCheck() || this.findHotbarItem(Items.field_151046_w) == -1) {
            return;
        }
        int oldSlot = Module.mc.field_71439_g.field_71071_by.field_70461_c;
        KuraMineTest kuraMineTest = this;
        try {
            KuraMineTest $this$onBlockEvent_u24lambda_u2d4 = kuraMineTest;
            boolean bl = false;
            if ($this$onBlockEvent_u24lambda_u2d4.currentPos != null) {
                if (!$this$onBlockEvent_u24lambda_u2d4.canBreak($this$onBlockEvent_u24lambda_u2d4.currentPos, false)) {
                    $this$onBlockEvent_u24lambda_u2d4.currentPos = null;
                    return;
                }
                BlockPos blockPos = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                Intrinsics.checkNotNull(blockPos);
                if (blockPos.func_177958_n() == event.pos.func_177958_n()) {
                    BlockPos blockPos2 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                    Intrinsics.checkNotNull(blockPos2);
                    if (blockPos2.func_177956_o() == event.pos.func_177956_o()) {
                        BlockPos blockPos3 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                        Intrinsics.checkNotNull(blockPos3);
                        if (blockPos3.func_177952_p() == event.pos.func_177952_p()) {
                            return;
                        }
                    }
                }
                if (Intrinsics.areEqual($this$onBlockEvent_u24lambda_u2d4.currentPos, event.pos)) {
                    Boolean bl2 = $this$onBlockEvent_u24lambda_u2d4.strict.getValue();
                    Intrinsics.checkNotNullExpressionValue(bl2, "strict.value");
                    if (bl2.booleanValue()) {
                        int oldWindowId = Module.mc.field_71439_g.field_71069_bz.field_75152_c;
                        int pickaxeSlot = $this$onBlockEvent_u24lambda_u2d4.findHotbarItem(Items.field_151046_w);
                        Boolean bl3 = $this$onBlockEvent_u24lambda_u2d4.swap.getValue();
                        Intrinsics.checkNotNullExpressionValue(bl3, "swap.value");
                        if (bl3.booleanValue()) {
                            if (!$this$onBlockEvent_u24lambda_u2d4.superGhostHand.getValue().booleanValue()) {
                                Module.mc.field_71442_b.func_78765_e();
                                $this$onBlockEvent_u24lambda_u2d4.switchToSlot($this$onBlockEvent_u24lambda_u2d4.findHotbarItem(Items.field_151046_w));
                                Module.mc.field_71442_b.func_78765_e();
                            } else {
                                NetHandlerPlayClient netHandlerPlayClient = Module.mc.func_147114_u();
                                Intrinsics.checkNotNull(netHandlerPlayClient);
                                netHandlerPlayClient.func_147297_a((Packet)new CPacketClickWindow(Module.mc.field_71439_g.field_71069_bz.field_75152_c, pickaxeSlot, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(pickaxeSlot), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                            }
                            NetHandlerPlayClient netHandlerPlayClient = Module.mc.field_71439_g.field_71174_a;
                            BlockPos blockPos4 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                            Intrinsics.checkNotNull(blockPos4);
                            EnumFacing enumFacing = $this$onBlockEvent_u24lambda_u2d4.facing;
                            Intrinsics.checkNotNull(enumFacing);
                            netHandlerPlayClient.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, blockPos4, enumFacing));
                            NetHandlerPlayClient netHandlerPlayClient2 = Module.mc.field_71439_g.field_71174_a;
                            BlockPos blockPos5 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                            Intrinsics.checkNotNull(blockPos5);
                            EnumFacing enumFacing2 = $this$onBlockEvent_u24lambda_u2d4.facing;
                            Intrinsics.checkNotNull(enumFacing2);
                            netHandlerPlayClient2.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, blockPos5, enumFacing2));
                            if (!$this$onBlockEvent_u24lambda_u2d4.superGhostHand.getValue().booleanValue()) {
                                Module.mc.field_71442_b.func_78765_e();
                                Module.mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
                                Module.mc.field_71442_b.func_78765_e();
                            } else {
                                NetHandlerPlayClient netHandlerPlayClient3 = Module.mc.func_147114_u();
                                Intrinsics.checkNotNull(netHandlerPlayClient3);
                                netHandlerPlayClient3.func_147297_a((Packet)new CPacketClickWindow(pickaxeSlot, oldWindowId, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(oldWindowId), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                            }
                        } else {
                            NetHandlerPlayClient netHandlerPlayClient = Module.mc.field_71439_g.field_71174_a;
                            BlockPos blockPos6 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                            Intrinsics.checkNotNull(blockPos6);
                            EnumFacing enumFacing = $this$onBlockEvent_u24lambda_u2d4.facing;
                            Intrinsics.checkNotNull(enumFacing);
                            netHandlerPlayClient.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, blockPos6, enumFacing));
                            NetHandlerPlayClient netHandlerPlayClient4 = Module.mc.field_71439_g.field_71174_a;
                            BlockPos blockPos7 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                            Intrinsics.checkNotNull(blockPos7);
                            EnumFacing enumFacing3 = $this$onBlockEvent_u24lambda_u2d4.facing;
                            Intrinsics.checkNotNull(enumFacing3);
                            netHandlerPlayClient4.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, blockPos7, enumFacing3));
                        }
                    }
                }
            }
            $this$onBlockEvent_u24lambda_u2d4.currentPos = event.pos;
            $this$onBlockEvent_u24lambda_u2d4.facing = event.facing;
            WorldClient worldClient = Module.mc.field_71441_e;
            BlockPos blockPos = $this$onBlockEvent_u24lambda_u2d4.currentPos;
            Intrinsics.checkNotNull(blockPos);
            $this$onBlockEvent_u24lambda_u2d4.currentBlockState = worldClient.func_180495_p(blockPos);
            if (Module.mc.func_147114_u() != null && $this$onBlockEvent_u24lambda_u2d4.canBreak($this$onBlockEvent_u24lambda_u2d4.currentPos, false)) {
                BlockAnimation blockAnimation = $this$onBlockEvent_u24lambda_u2d4.br;
                BlockPos blockPos8 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                Intrinsics.checkNotNull(blockPos8);
                blockAnimation.select(blockPos8, true);
                Module.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                NetHandlerPlayClient netHandlerPlayClient = Module.mc.field_71439_g.field_71174_a;
                BlockPos blockPos9 = $this$onBlockEvent_u24lambda_u2d4.currentPos;
                Intrinsics.checkNotNull(blockPos9);
                EnumFacing enumFacing = $this$onBlockEvent_u24lambda_u2d4.facing;
                Intrinsics.checkNotNull(enumFacing);
                netHandlerPlayClient.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, blockPos9, enumFacing));
            }
            event.setCanceled(true);
            Object object = Result.constructor-impl(Unit.INSTANCE);
        }
        catch (Throwable throwable) {
            Object object = Result.constructor-impl(ResultKt.createFailure(throwable));
        }
    }

    private final Vec3d getEyesPos() {
        return new Vec3d(Module.mc.field_71439_g.field_70165_t, Module.mc.field_71439_g.field_70163_u + (double)Module.mc.field_71439_g.func_70047_e(), Module.mc.field_71439_g.field_70161_v);
    }

    @NotNull
    public final float[] getLegitRotations(@NotNull BlockPos vec) {
        Intrinsics.checkNotNullParameter(vec, "vec");
        Vec3d eyesPos = this.getEyesPos();
        double diffX = (double)vec.func_177958_n() - eyesPos.field_72450_a;
        double diffY = (double)vec.func_177956_o() - eyesPos.field_72448_b;
        double diffZ = (double)vec.func_177952_p() - eyesPos.field_72449_c;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = -((float)Math.toDegrees(Math.atan2(diffY, diffXZ)));
        float[] fArray = new float[]{Module.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(yaw - Module.mc.field_71439_g.field_70177_z)), Module.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(pitch - Module.mc.field_71439_g.field_70125_A))};
        return fArray;
    }

    @SubscribeEvent(priority=EventPriority.HIGHEST)
    public final void onTick(@NotNull UpdateWalkingPlayerEvent event) {
        block21: {
            Intrinsics.checkNotNullParameter((Object)event, "event");
            if (Module.fullNullCheck() || this.findHotbarItem(Items.field_151046_w) == -1) {
                return;
            }
            BlockPos blockPos = this.currentPos;
            if (blockPos == null) break block21;
            BlockPos it = blockPos;
            boolean bl = false;
            double d = Module.mc.field_71439_g.func_174818_b(it);
            int n = ((Number)this.range.getValue()).intValue();
            Integer n2 = this.range.getValue();
            Intrinsics.checkNotNullExpressionValue(n2, "range.value");
            if (d > (double)(n * ((Number)n2).intValue())) {
                return;
            }
            if (Module.mc.field_71439_g.field_71071_by.field_70461_c != this.findHotbarItem(Items.field_151046_w) && !this.swap.getValue().booleanValue()) {
                return;
            }
            if (Intrinsics.areEqual(Module.mc.field_71441_e.func_180495_p(it).func_177230_c(), Blocks.field_150357_h) || Intrinsics.areEqual(Module.mc.field_71441_e.func_180495_p(it).func_177230_c(), Blocks.field_150350_a)) {
                Boolean bl2 = this.superStrict.getValue();
                Intrinsics.checkNotNullExpressionValue(bl2, "superStrict.value");
                if (bl2.booleanValue()) {
                    this.strictTimer.reset();
                }
                return;
            }
            this.br.update();
            if (Intrinsics.areEqual(Module.mc.field_71441_e.func_180495_p(it).func_177230_c(), Blocks.field_150350_a)) {
                return;
            }
            int oldSlot = Module.mc.field_71439_g.field_71071_by.field_70461_c;
            int oldWindowId = Module.mc.field_71439_g.field_71069_bz.field_75152_c;
            int pickaxeSlot = this.findHotbarItem(Items.field_151046_w);
            Boolean bl3 = this.rotate.getValue();
            Intrinsics.checkNotNullExpressionValue(bl3, "rotate.value");
            if (bl3.booleanValue()) {
                BlockPos blockPos2 = it.func_177963_a(0.5, 0.5, 0.5);
                Intrinsics.checkNotNullExpressionValue(blockPos2, "it.add(0.5,0.5,0.5)");
                float f = this.getLegitRotations(blockPos2)[0];
                BlockPos blockPos3 = it.func_177963_a(0.5, 0.5, 0.5);
                Intrinsics.checkNotNullExpressionValue(blockPos3, "it.add(0.5,0.5,0.5)");
                Client.rotationManager.setRotation(f, this.getLegitRotations(blockPos3)[1]);
            }
            Boolean bl4 = this.swing.getValue();
            Intrinsics.checkNotNullExpressionValue(bl4, "swing.value");
            if (bl4.booleanValue()) {
                Module.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            }
            Module.mc.field_71442_b.func_78765_e();
            Boolean bl5 = this.swap.getValue();
            Intrinsics.checkNotNullExpressionValue(bl5, "swap.value");
            if (bl5.booleanValue()) {
                if (!this.superGhostHand.getValue().booleanValue()) {
                    this.switchToSlot(this.findHotbarItem(Items.field_151046_w));
                } else {
                    NetHandlerPlayClient netHandlerPlayClient = Module.mc.func_147114_u();
                    Intrinsics.checkNotNull(netHandlerPlayClient);
                    netHandlerPlayClient.func_147297_a((Packet)new CPacketClickWindow(Module.mc.field_71439_g.field_71069_bz.field_75152_c, pickaxeSlot, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(pickaxeSlot), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                }
            }
            NetHandlerPlayClient netHandlerPlayClient = Module.mc.field_71439_g.field_71174_a;
            EnumFacing enumFacing = this.facing;
            Intrinsics.checkNotNull(enumFacing);
            netHandlerPlayClient.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, it, enumFacing));
            Boolean bl6 = this.swap.getValue();
            Intrinsics.checkNotNullExpressionValue(bl6, "swap.value");
            if (bl6.booleanValue()) {
                if (!this.superGhostHand.getValue().booleanValue()) {
                    Module.mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
                } else {
                    NetHandlerPlayClient netHandlerPlayClient2 = Module.mc.func_147114_u();
                    Intrinsics.checkNotNull(netHandlerPlayClient2);
                    netHandlerPlayClient2.func_147297_a((Packet)new CPacketClickWindow(pickaxeSlot, oldWindowId, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(oldWindowId), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                }
            }
            Module.mc.field_71442_b.func_78765_e();
            Boolean bl7 = this.swap.getValue();
            Intrinsics.checkNotNullExpressionValue(bl7, "swap.value");
            if (bl7.booleanValue()) {
                if (!this.superGhostHand.getValue().booleanValue()) {
                    this.switchToSlot(this.findHotbarItem(Items.field_151046_w));
                } else {
                    NetHandlerPlayClient netHandlerPlayClient3 = Module.mc.func_147114_u();
                    Intrinsics.checkNotNull(netHandlerPlayClient3);
                    netHandlerPlayClient3.func_147297_a((Packet)new CPacketClickWindow(Module.mc.field_71439_g.field_71069_bz.field_75152_c, pickaxeSlot, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(pickaxeSlot), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                }
            }
            NetHandlerPlayClient netHandlerPlayClient4 = Module.mc.field_71439_g.field_71174_a;
            EnumFacing enumFacing2 = this.facing;
            Intrinsics.checkNotNull(enumFacing2);
            netHandlerPlayClient4.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, it, enumFacing2));
            Module.mc.field_71442_b.func_78765_e();
            Boolean bl8 = this.swap.getValue();
            Intrinsics.checkNotNullExpressionValue(bl8, "swap.value");
            if (bl8.booleanValue()) {
                if (!this.superGhostHand.getValue().booleanValue()) {
                    Module.mc.field_71439_g.field_71071_by.field_70461_c = oldSlot;
                } else {
                    NetHandlerPlayClient netHandlerPlayClient5 = Module.mc.func_147114_u();
                    Intrinsics.checkNotNull(netHandlerPlayClient5);
                    netHandlerPlayClient5.func_147297_a((Packet)new CPacketClickWindow(pickaxeSlot, oldWindowId, Module.mc.field_71442_b.field_78777_l, ClickType.SWAP, Module.mc.field_71439_g.field_71071_by.func_70301_a(oldWindowId), Module.mc.field_71439_g.field_71070_bA.func_75136_a(Module.mc.field_71439_g.field_71071_by)));
                }
            }
            Module.mc.field_71442_b.func_78765_e();
            Boolean bl9 = this.packet.getValue();
            Intrinsics.checkNotNullExpressionValue(bl9, "packet.value");
            if (bl9.booleanValue()) {
                this.currentPos = null;
            }
            this.strictTimer.reset();
        }
    }

    @Override
    public void onRender3D(@Nullable Render3DEvent event) {
        if (Module.fullNullCheck()) {
            return;
        }
        Boolean bl = this.render.getValue();
        if (bl == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Boolean");
        }
        if (bl.booleanValue() && this.currentPos != null && this.canBreak(this.currentPos, true)) {
            Integer n = this.alpha.getValue();
            Intrinsics.checkNotNullExpressionValue(n, "alpha.value");
            this.br.draw(BlockAnimation.DrawMode.GenAABBMode.WATER, new BlockAnimation.Color2(Color.MAGENTA, ((Number)n).intValue()), true, true);
        } else if (this.currentPos == null) {
            this.br.select(null, true);
        }
    }

    @Override
    public void onDisable() {
        if (Module.fullNullCheck()) {
            return;
        }
        this.currentPos = null;
        this.facing = null;
    }

    @Override
    public void onEnable() {
        if (Module.fullNullCheck()) {
            return;
        }
        this.currentPos = null;
        this.facing = null;
    }

    @Override
    @NotNull
    public String getDisplayInfo() {
        Boolean bl = this.packet.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "packet.value");
        return bl != false ? "Packet" : "Instant";
    }

    private final void switchToSlot(int slot) {
        Module.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
        Module.mc.field_71439_g.field_71071_by.field_70461_c = slot;
        Module.mc.field_71442_b.func_78765_e();
    }

    private static final boolean superGhostHand$lambda-0(KuraMineTest this$0, Boolean bl) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Boolean bl2 = this$0.swap.getValue();
        Intrinsics.checkNotNullExpressionValue(bl2, "swap.value");
        return bl2;
    }

    private static final boolean firstIn$lambda-1(KuraMineTest this$0, Boolean bl) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Boolean bl2 = this$0.render.getValue();
        Intrinsics.checkNotNullExpressionValue(bl2, "render.value");
        return bl2;
    }

    private static final boolean alpha$lambda-2(KuraMineTest this$0, Integer n) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Boolean bl = this$0.render.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "render.value");
        return bl;
    }

    private static final boolean superStrict$lambda-3(KuraMineTest this$0, Boolean bl) {
        Intrinsics.checkNotNullParameter(this$0, "this$0");
        Boolean bl2 = this$0.strict.getValue();
        Intrinsics.checkNotNullExpressionValue(bl2, "strict.value");
        return bl2;
    }
}

