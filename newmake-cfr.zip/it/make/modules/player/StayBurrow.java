/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package it.make.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.api.events.render.Render3DEvent;
import it.make.api.managers.CommandManager;
import it.make.api.setting.Setting;
import it.make.api.utils.BlockUtil;
import it.make.api.utils.second.skid.EntityUtil;
import it.make.api.utils.second.skid.InventoryUtil;
import it.make.api.utils.second.skid.two.SeijaBlockUtil;
import it.make.modules.Module;
import java.util.Comparator;
import java.util.stream.Collectors;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class StayBurrow
extends Module {
    private final Setting<Boolean> breakCrystal = this.rbool("BreakCrystal", true);
    private final Setting<Boolean> onlyOnGround = this.rbool("OnlyOnGround", true);
    private final Setting<Boolean> rotate = this.rbool("Rotate", true);
    private final Setting<Boolean> smartOffset = this.rbool("SmartOffset", true);
    private final Setting<Double> offsetX = this.rdoub("OffsetX", -7.0, -10.0, 10.0);
    private final Setting<Double> offsetY = this.rdoub("OffsetY", -7.0, -10.0, 10.0);
    private final Setting<Double> offsetZ = this.rdoub("OffsetZ", -7.0, -10.0, 10.0);
    private final Setting<Boolean> fristObby = this.rbool("FristObby", true);
    public Setting<Boolean> tpcenter = this.rbool("TPCenter", false);
    private boolean isSneaking = false;

    public StayBurrow() {
        super("StayBurrow", "qwq", Module.Category.PLAYER);
    }

    public static BlockPos getPlayerPosFixY(EntityPlayer player) {
        return new BlockPos(Math.floor(player.field_70165_t), (double)Math.round(player.field_70163_u), Math.floor(player.field_70161_v));
    }

    public static void back() {
        for (Entity crystal : StayBurrow.mc.field_71441_e.field_72996_f.stream().filter(e -> e instanceof EntityEnderCrystal && !e.field_70128_L).sorted(Comparator.comparing(e -> Float.valueOf(StayBurrow.mc.field_71439_g.func_70032_d(e)))).collect(Collectors.toList())) {
            if (!(crystal instanceof EntityEnderCrystal)) continue;
            StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(crystal));
            StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
        }
    }

    @Override
    public void onDisable() {
        this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void onTick() {
        block27: {
            boolean defaultOffset;
            block25: {
                block26: {
                    block24: {
                        int a;
                        block23: {
                            block22: {
                                block19: {
                                    int n;
                                    EnumFacing[] enumFacingArray;
                                    block21: {
                                        block20: {
                                            if (this.onlyOnGround.getValue() & (!StayBurrow.mc.field_71439_g.field_70122_E | StayBurrow.mc.field_71441_e.func_180495_p(SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177972_a(EnumFacing.DOWN)).func_177230_c().equals(Blocks.field_150350_a))) {
                                                return;
                                            }
                                            this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
                                            if (this.breakCrystal.getValue().booleanValue() && this.breakCrystal.getValue().booleanValue()) {
                                                StayBurrow.back();
                                            }
                                            if (!StayBurrow.mc.field_71441_e.func_175667_e(StayBurrow.mc.field_71439_g.func_180425_c())) {
                                                return;
                                            }
                                            if (InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)) == -1 && InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB)) == -1) {
                                                this.sendModuleMessage(ChatFormatting.RED + "Obsidian/Ender Chest ?");
                                                this.disable();
                                                return;
                                            }
                                            if (this.tpcenter.getValue().booleanValue()) {
                                                BlockPos startPos = EntityUtil.getRoundedBlockPos((Entity)StayBurrow.mc.field_71439_g);
                                                CommandManager.setPositionPacket((double)startPos.func_177958_n() + 0.5, startPos.func_177956_o(), (double)startPos.func_177952_p() + 0.5, true, true, true);
                                            }
                                            if (SeijaBlockUtil.fakeBBoxCheck((EntityPlayer)StayBurrow.mc.field_71439_g, new Vec3d(0.0, 0.0, 0.0), true)) break block20;
                                            BlockPos pos = this.getOffsetBlock((EntityPlayer)StayBurrow.mc.field_71439_g);
                                            if (!StayBurrow.mc.field_71441_e.func_180495_p(SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177967_a(EnumFacing.UP, 2)).func_177230_c().equals(Blocks.field_150350_a)) {
                                                enumFacingArray = EnumFacing.field_82609_l;
                                                n = enumFacingArray.length;
                                                break block21;
                                            } else if (pos != null && StayBurrow.mc.field_71441_e.func_180495_p(SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177967_a(EnumFacing.UP, 2)).func_177230_c().equals(Blocks.field_150350_a)) {
                                                double offX = (double)pos.func_177958_n() + 0.5 - StayBurrow.mc.field_71439_g.field_70165_t;
                                                double offZ = (double)pos.func_177952_p() + 0.5 - StayBurrow.mc.field_71439_g.field_70161_v;
                                                StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + offX * 0.25, StayBurrow.mc.field_71439_g.field_70163_u + 0.419999986886978, StayBurrow.mc.field_71439_g.field_70161_v + offZ * 0.25, false));
                                                StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + offX * 0.5, StayBurrow.mc.field_71439_g.field_70163_u + 0.7531999805212015, StayBurrow.mc.field_71439_g.field_70161_v + offZ * 0.5, false));
                                                StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + offX * 0.75, StayBurrow.mc.field_71439_g.field_70163_u + 1.001335979112147, StayBurrow.mc.field_71439_g.field_70161_v + offZ * 0.75, false));
                                                StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position((double)pos.func_177958_n() + 0.5, StayBurrow.mc.field_71439_g.field_70163_u + 1.166109260938214, (double)pos.func_177952_p() + 0.5, false));
                                                break block19;
                                            } else {
                                                this.disable();
                                                return;
                                            }
                                        }
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t, StayBurrow.mc.field_71439_g.field_70163_u + 0.419999986886978, StayBurrow.mc.field_71439_g.field_70161_v, false));
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t, StayBurrow.mc.field_71439_g.field_70163_u + 0.7531999805212015, StayBurrow.mc.field_71439_g.field_70161_v, false));
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t, StayBurrow.mc.field_71439_g.field_70163_u + 1.001335979112147, StayBurrow.mc.field_71439_g.field_70161_v, false));
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t, StayBurrow.mc.field_71439_g.field_70163_u + 1.166109260938214, StayBurrow.mc.field_71439_g.field_70161_v, false));
                                        break block19;
                                    }
                                    for (int i = 0; i < n; ++i) {
                                        BlockPos offPos;
                                        EnumFacing facing = enumFacingArray[i];
                                        if (facing == EnumFacing.UP || facing == EnumFacing.DOWN || !BlockUtil.isAir(offPos = SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177972_a(facing)) || !BlockUtil.isAir(offPos.func_177972_a(EnumFacing.UP))) continue;
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + ((double)offPos.func_177958_n() + 0.5 - StayBurrow.mc.field_71439_g.field_70165_t) / 2.0, StayBurrow.mc.field_71439_g.field_70163_u + 0.188383748, StayBurrow.mc.field_71439_g.field_70161_v + ((double)offPos.func_177952_p() + 0.5 - StayBurrow.mc.field_71439_g.field_70161_v) / 2.0, false));
                                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + ((double)offPos.func_177958_n() + 0.5 - StayBurrow.mc.field_71439_g.field_70165_t), StayBurrow.mc.field_71439_g.field_70163_u + 0.123232, StayBurrow.mc.field_71439_g.field_70161_v + ((double)offPos.func_177952_p() + 0.5 - StayBurrow.mc.field_71439_g.field_70161_v), false));
                                    }
                                }
                                a = StayBurrow.mc.field_71439_g.field_71071_by.field_70461_c;
                                if (!this.fristObby.getValue().booleanValue()) break block22;
                                if (InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)) != -1) {
                                    InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)), false);
                                    break block23;
                                } else if (InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB)) != -1) {
                                    InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB)), false);
                                }
                                break block23;
                            }
                            if (InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB)) != -1) {
                                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150477_bB)), false);
                            } else if (InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)) != -1) {
                                InventoryUtil.switchToHotbarSlot(InventoryUtil.getItemHotbar(Item.func_150898_a((Block)Blocks.field_150343_Z)), false);
                            }
                        }
                        this.isSneaking = BlockUtil.placeBlock(new BlockPos((Vec3i)StayBurrow.getPlayerPosFixY((EntityPlayer)StayBurrow.mc.field_71439_g)), EnumHand.MAIN_HAND, this.rotate.getValue(), true, this.isSneaking);
                        StayBurrow.mc.field_71442_b.func_78765_e();
                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(a));
                        StayBurrow.mc.field_71439_g.field_71071_by.field_70461_c = a;
                        StayBurrow.mc.field_71442_b.func_78765_e();
                        StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(new BlockPos(StayBurrow.mc.field_71439_g.field_70165_t, StayBurrow.mc.field_71439_g.field_70163_u - 1.0, StayBurrow.mc.field_71439_g.field_70161_v), EnumFacing.UP, EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
                        if (!this.smartOffset.getValue().booleanValue()) break block24;
                        defaultOffset = true;
                        if (!(StayBurrow.mc.field_71439_g.field_70163_u >= 3.0)) break block25;
                        break block26;
                    }
                    StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + this.offsetX.getValue(), StayBurrow.mc.field_71439_g.field_70163_u + this.offsetY.getValue(), StayBurrow.mc.field_71439_g.field_70161_v + this.offsetZ.getValue(), false));
                    break block27;
                }
                for (int i = -10; i < 10; ++i) {
                    if (i == -1) {
                        i = 4;
                    }
                    if (!StayBurrow.mc.field_71441_e.func_180495_p(SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177982_a(0, i, 0)).func_177230_c().equals(Blocks.field_150350_a) || !StayBurrow.mc.field_71441_e.func_180495_p(SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177982_a(0, i + 1, 0)).func_177230_c().equals(Blocks.field_150350_a)) continue;
                    BlockPos pos = SeijaBlockUtil.getFlooredPosition((Entity)StayBurrow.mc.field_71439_g).func_177982_a(0, i, 0);
                    StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position((double)pos.func_177958_n() + 0.3, (double)pos.func_177956_o(), (double)pos.func_177952_p() + 0.3, false));
                    defaultOffset = false;
                    break;
                }
            }
            if (defaultOffset) {
                StayBurrow.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(StayBurrow.mc.field_71439_g.field_70165_t + this.offsetX.getValue(), StayBurrow.mc.field_71439_g.field_70163_u + this.offsetY.getValue(), StayBurrow.mc.field_71439_g.field_70161_v + this.offsetZ.getValue(), false));
            }
        }
        this.disable();
    }

    public BlockPos getOffsetBlock(EntityPlayer player) {
        Vec3d vec3d1 = new Vec3d(player.field_70121_D.field_72340_a, player.field_70121_D.field_72338_b, player.field_70121_D.field_72339_c);
        if (this.canBur(vec3d1)) {
            return SeijaBlockUtil.vec3toBlockPos(vec3d1);
        }
        Vec3d vec3d2 = new Vec3d(player.field_70121_D.field_72336_d, player.field_70121_D.field_72338_b, player.field_70121_D.field_72339_c);
        if (this.canBur(vec3d2)) {
            return SeijaBlockUtil.vec3toBlockPos(vec3d2);
        }
        Vec3d vec3d3 = new Vec3d(player.field_70121_D.field_72340_a, player.field_70121_D.field_72338_b, player.field_70121_D.field_72334_f);
        if (this.canBur(vec3d3)) {
            return SeijaBlockUtil.vec3toBlockPos(vec3d3);
        }
        Vec3d vec3d4 = new Vec3d(player.field_70121_D.field_72336_d, player.field_70121_D.field_72338_b, player.field_70121_D.field_72334_f);
        if (this.canBur(vec3d4)) {
            return SeijaBlockUtil.vec3toBlockPos(vec3d4);
        }
        return null;
    }

    public boolean canBur(Vec3d vec3d) {
        BlockPos pos = SeijaBlockUtil.vec3toBlockPos(vec3d);
        return BlockUtil.isAir(pos) && BlockUtil.isAir(pos.func_177972_a(EnumFacing.UP)) && BlockUtil.isAir(pos.func_177967_a(EnumFacing.UP, 2));
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (this.breakCrystal.getValue().booleanValue()) {
            StayBurrow.back();
        }
    }
}

