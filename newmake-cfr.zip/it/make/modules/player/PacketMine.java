/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Enchantments
 *  net.minecraft.init.Items
 *  net.minecraft.init.MobEffects
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.ItemAir
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.EventPriority
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.api.events.block.BlockEvent;
import it.make.api.events.network.PacketEvent;
import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.api.utils.BlockUtil;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.FadeUtils;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.RenderUtil;
import it.make.modules.Module;
import it.make.modules.combat.PullCrystal;
import it.make.modules.misc.PacketTranslation;
import it.make.modules.misc.SpoofGround;
import java.awt.Color;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemAir;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PacketMine
extends Module {
    public static final List<Block> godBlocks = Arrays.asList(Blocks.field_150483_bI, Blocks.field_150356_k, Blocks.field_150353_l, Blocks.field_150358_i, Blocks.field_150355_j, Blocks.field_150357_h, Blocks.field_180401_cv);
    private final Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 100, 0, 1000));
    private final Setting<Float> damage = this.register(new Setting<Float>("Damage", Float.valueOf(0.7f), Float.valueOf(0.0f), Float.valueOf(2.0f)));
    private final Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(7.0f), Float.valueOf(3.0f), Float.valueOf(10.0f)));
    private final Setting<Integer> maxBreak = this.register(new Setting<Integer>("MaxBreak", 2, 0, 20));
    private final Setting<Boolean> instant = this.register(new Setting<Boolean>("Instant", false));
    private final Setting<Boolean> wait = this.register(new Setting<Boolean>("Wait", Boolean.valueOf(true), v -> this.instant.getValue() == false));
    private final Setting<Boolean> mineAir = this.register(new Setting<Boolean>("MineAir", Boolean.valueOf(true), v -> this.wait.getValue()));
    public final Setting<Boolean> godCancel = this.register(new Setting<Boolean>("GodCancel", true));
    public final Setting<Boolean> hotBar = this.register(new Setting<Boolean>("HotBar", false));
    private final Setting<Boolean> tpsSync = this.register(new Setting<Boolean>("TpsSync", true));
    private final Setting<Boolean> checkGround = this.register(new Setting<Boolean>("CheckGround", true));
    private final Setting<Boolean> onlyGround = this.register(new Setting<Boolean>("OnlyGround", true));
    private final Setting<Boolean> allowWeb = this.register(new Setting<Boolean>("AllowWeb", Boolean.valueOf(true), v -> this.onlyGround.getValue()));
    private final Setting<Boolean> doubleBreak = this.register(new Setting<Boolean>("DoubleBreak", true));
    private final Setting<Boolean> swing = this.register(new Setting<Boolean>("Swing", true));
    private final Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));
    private final Setting<Integer> time = this.register(new Setting<Integer>("Time", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(2000), v -> this.rotate.getValue()));
    private final Setting<Boolean> switchReset = this.register(new Setting<Boolean>("SwitchReset", false));
    private final Setting<Boolean> render = this.register(new Setting<Boolean>("Render", true));
    private final Setting<Mode> animationMode = this.register(new Setting<Mode>("AnimationMode", Mode.Up, v -> this.render.getValue()));
    private final Setting<Float> fillStart = this.register(new Setting<Float>("FillStart", Float.valueOf(0.2f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.render.getValue() != false && this.animationMode.getValue() == Mode.Custom));
    private final Setting<Float> boxStart = this.register(new Setting<Float>("BoxStart", Float.valueOf(0.4f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.render.getValue() != false && this.animationMode.getValue() == Mode.Custom));
    private final Setting<Float> boxExtend = this.register(new Setting<Float>("BoxExtend", Float.valueOf(0.2f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.render.getValue() != false && this.animationMode.getValue() == Mode.Custom));
    private final Setting<Boolean> text = this.register(new Setting<Boolean>("Text", Boolean.valueOf(true), v -> this.render.getValue()));
    private final Setting<TextMode> textMode = this.register(new Setting<TextMode>("TextMode", TextMode.Progress, v -> this.render.getValue() != false && this.text.getValue() != false));
    private final Setting<Boolean> showMax = this.register(new Setting<Boolean>("ShowMax", Boolean.valueOf(true), v -> this.render.getValue() != false && this.text.getValue() != false && (this.textMode.getValue() == TextMode.Time || this.textMode.getValue() == TextMode.Tick)));
    private final Setting<ColorMode> textColorMode = this.register(new Setting<ColorMode>("TextColorMode", ColorMode.Progress, v -> this.render.getValue() != false && this.text.getValue() != false));
    private final Setting<Integer> textColorR = this.rcolo("TextColorR");
    private final Setting<Integer> textColorG = this.rcolo("TextColorG");
    private final Setting<Integer> textColorB = this.rcolo("TextColorB");
    private final Setting<Boolean> box = this.register(new Setting<Boolean>("Box", Boolean.valueOf(true), v -> this.render.getValue()));
    private final Setting<Integer> boxAlpha = this.register(new Setting<Integer>("BoxAlpha", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(255), v -> this.box.getValue() != false && this.render.getValue() != false));
    private final Setting<Boolean> outline = this.register(new Setting<Boolean>("Outline", Boolean.valueOf(true), v -> this.render.getValue()));
    private final Setting<Integer> outlineAlpha = this.register(new Setting<Integer>("OutlineAlpha", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(255), v -> this.outline.getValue() != false && this.render.getValue() != false));
    private final Setting<ColorMode> colorMode = this.register(new Setting<ColorMode>("ColorMode", ColorMode.Progress, v -> this.render.getValue()));
    private final Setting<Integer> colorR = this.rcolo("ColorR");
    private final Setting<Integer> colorG = this.rcolo("ColorG");
    private final Setting<Integer> colorB = this.rcolo("ColorB");
    private final Setting<Boolean> crystal = this.register(new Setting<Boolean>("Crystal", true));
    private final Setting<Boolean> waitPlace = this.register(new Setting<Boolean>("WaitPlace", Boolean.valueOf(false), v -> this.crystal.getValue()));
    private final Setting<Boolean> fast = this.register(new Setting<Boolean>("Fast", Boolean.valueOf(false), v -> this.crystal.getValue()));
    private final Setting<Boolean> afterBreak = this.register(new Setting<Boolean>("AfterBreak", Boolean.valueOf(true), v -> this.crystal.getValue()));
    private final Setting<Boolean> checkDamage = this.register(new Setting<Boolean>("CheckDamage", Boolean.valueOf(true), v -> this.crystal.getValue()));
    private final Setting<Float> crystalDamage = this.register(new Setting<Float>("CrystalDamage", Float.valueOf(0.7f), Float.valueOf(0.0f), Float.valueOf(1.0f), v -> this.crystal.getValue() != false && this.checkDamage.getValue() != false));
    private final Setting<Boolean> eatPause = this.register(new Setting<Boolean>("EatingPause", Boolean.valueOf(true), v -> this.crystal.getValue()));
    private final Setting<Bind> enderChest = this.register(new Setting<Bind>("EnderChest", new Bind(-1)));
    private final Setting<Bind> obsidian = this.register(new Setting<Bind>("Obsidian", new Bind(-1)));
    private final Setting<Integer> placeDelay = this.register(new Setting<Integer>("PlaceDelay", 300, 0, 1000));
    private final Setting<Boolean> debug = this.register(new Setting<Boolean>("Debug", false));
    private final Setting<Boolean> placeInFire = this.rbool("PlaceInFire", true);
    public static PacketMine INSTANCE;
    public static BlockPos breakPos;
    private final Timer mineTimer = new Timer();
    private FadeUtils animationTime = new FadeUtils(1000L);
    private boolean startMine = false;
    private int breakNumber = 0;
    private final Timer placeTimer = new Timer();
    private final Timer delayTimer = new Timer();
    private final Timer firstTimer = new Timer();
    int lastSlot = -1;

    public PacketMine() {
        super(new I18NInfo("PacketMine").bind(EnumI18N.Chinese, "\u6885\u6885\u6316\u6398"), "1", Module.Category.PLAYER);
        INSTANCE = this;
    }

    @Override
    public void onDisable() {
        this.startMine = false;
        breakPos = null;
    }

    @Override
    public void onTick() {
        this.update();
    }

    public void update() {
        if (breakPos == null) {
            this.breakNumber = 0;
            this.startMine = false;
        } else if (!(PacketMine.mc.field_71439_g.func_184812_l_() || PacketMine.mc.field_71439_g.func_70011_f((double)breakPos.func_177958_n() + 0.5, (double)breakPos.func_177956_o() + 0.5, (double)breakPos.func_177952_p() + 0.5) > (double)this.range.getValue().floatValue() || this.breakNumber > this.maxBreak.getValue() - 1 && this.maxBreak.getValue() > 0 || !this.wait.getValue().booleanValue() && PacketMine.mc.field_71441_e.func_175623_d(breakPos) && !this.instant.getValue().booleanValue())) {
            if (godBlocks.contains(PacketMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
                if (this.godCancel.getValue().booleanValue()) {
                    breakPos = null;
                    this.startMine = false;
                }
            } else {
                int oldSlot;
                int slot = this.getTool(breakPos);
                if (slot == -1) {
                    slot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c + 36;
                }
                if (PacketMine.mc.field_71441_e.func_175623_d(breakPos)) {
                    if (this.crystal.getValue().booleanValue()) {
                        for (EnumFacing facing : EnumFacing.field_82609_l) {
                            RebirthUtil.attackCrystal(breakPos.func_177972_a(facing), (boolean)this.rotate.getValue(), (boolean)this.eatPause.getValue());
                        }
                    }
                    if (this.placeTimer.passedMs(this.placeDelay.getValue().intValue()) && RebirthUtil.canPlace(breakPos)) {
                        int obsidian;
                        if (this.enderChest.getValue().isDown() && PacketMine.mc.field_71462_r == null) {
                            int eChest = RebirthUtil.findHotbarBlock(Blocks.field_150477_bB);
                            if (eChest != -1) {
                                oldSlot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                                RebirthUtil.doSwap(eChest);
                                RebirthUtil.placeBlock(breakPos, EnumHand.MAIN_HAND, this.rotate.getValue(), true);
                                RebirthUtil.doSwap(oldSlot);
                                this.placeTimer.reset();
                            }
                        } else if (this.obsidian.getValue().isDown() && PacketMine.mc.field_71462_r == null && (obsidian = RebirthUtil.findHotbarBlock(Blocks.field_150343_Z)) != -1) {
                            boolean hasCrystal = false;
                            if (this.crystal.getValue().booleanValue()) {
                                for (Entity entity : PacketMine.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(breakPos.func_177984_a()))) {
                                    if (!(entity instanceof EntityEnderCrystal)) continue;
                                    hasCrystal = true;
                                    break;
                                }
                            }
                            if (!hasCrystal || this.fast.getValue().booleanValue()) {
                                int oldSlot2 = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                                RebirthUtil.doSwap(obsidian);
                                RebirthUtil.placeBlock(breakPos, EnumHand.MAIN_HAND, this.rotate.getValue(), true);
                                RebirthUtil.doSwap(oldSlot2);
                                this.placeTimer.reset();
                            }
                        }
                    }
                    this.breakNumber = 0;
                } else if (this.canPlaceCrystal(breakPos.func_177984_a(), true) && this.crystal.getValue().booleanValue()) {
                    if (this.placeTimer.passedMs(this.placeDelay.getValue().intValue())) {
                        if (this.checkDamage.getValue().booleanValue()) {
                            int crystal;
                            if ((float)this.mineTimer.getPassedTimeMs() / PacketMine.getBreakTime(breakPos, slot) >= this.crystalDamage.getValue().floatValue() && (crystal = RebirthUtil.findItemInHotbar(Items.field_185158_cP)) != -1) {
                                oldSlot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                                RebirthUtil.doSwap(crystal);
                                RebirthUtil.placeCrystal(breakPos.func_177984_a(), this.rotate.getValue());
                                RebirthUtil.doSwap(oldSlot);
                                this.placeTimer.reset();
                                if (this.waitPlace.getValue().booleanValue()) {
                                    return;
                                }
                            }
                        } else {
                            int crystal = RebirthUtil.findItemInHotbar(Items.field_185158_cP);
                            if (crystal != -1) {
                                oldSlot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                                RebirthUtil.doSwap(crystal);
                                RebirthUtil.placeCrystal(breakPos.func_177984_a(), this.rotate.getValue());
                                RebirthUtil.doSwap(oldSlot);
                                this.placeTimer.reset();
                                if (this.waitPlace.getValue().booleanValue()) {
                                    return;
                                }
                            }
                        }
                    } else if (this.startMine) {
                        return;
                    }
                }
                if (this.delayTimer.passedMs(this.delay.getValue().intValue())) {
                    if (this.startMine) {
                        if (PacketMine.mc.field_71441_e.func_175623_d(breakPos)) {
                            return;
                        }
                        if (!(!this.onlyGround.getValue().booleanValue() || PacketMine.mc.field_71439_g.field_70122_E || this.allowWeb.getValue().booleanValue() && PacketMine.mc.field_71439_g.field_70134_J)) {
                            return;
                        }
                        if (PullCrystal.INSTANCE.isOn() && breakPos.equals((Object)PullCrystal.powerPos) && PullCrystal.crystalPos != null && !RebirthUtil.posHasCrystal(PullCrystal.crystalPos)) {
                            return;
                        }
                        if (this.mineTimer.passedMs((long)PacketMine.getBreakTime(breakPos, slot))) {
                            boolean shouldSwitch;
                            int old = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                            boolean bl = shouldSwitch = old + 36 != slot;
                            if (shouldSwitch) {
                                if (this.hotBar.getValue().booleanValue()) {
                                    RebirthUtil.doSwap(slot - 36);
                                } else {
                                    PacketMine.mc.field_71442_b.func_187098_a(0, slot, old, ClickType.SWAP, (EntityPlayer)PacketMine.mc.field_71439_g);
                                }
                            }
                            if (this.rotate.getValue().booleanValue()) {
                                RebirthUtil.facePosFacing(breakPos, BlockUtil.getRayTraceFacing(breakPos));
                            }
                            if (this.swing.getValue().booleanValue()) {
                                PacketMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                            }
                            PacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                            if (shouldSwitch) {
                                if (this.hotBar.getValue().booleanValue()) {
                                    RebirthUtil.doSwap(old);
                                } else {
                                    PacketMine.mc.field_71442_b.func_187098_a(0, slot, old, ClickType.SWAP, (EntityPlayer)PacketMine.mc.field_71439_g);
                                }
                            }
                            ++this.breakNumber;
                            this.delayTimer.reset();
                            if (this.afterBreak.getValue().booleanValue() && this.crystal.getValue().booleanValue()) {
                                for (EnumFacing facing : EnumFacing.field_82609_l) {
                                    RebirthUtil.attackCrystal(breakPos.func_177972_a(facing), (boolean)this.rotate.getValue(), (boolean)this.eatPause.getValue());
                                }
                            }
                        }
                    } else {
                        if (!this.mineAir.getValue().booleanValue() && PacketMine.mc.field_71441_e.func_175623_d(breakPos)) {
                            return;
                        }
                        this.animationTime = new FadeUtils((long)PacketMine.getBreakTime(breakPos, slot));
                        this.mineTimer.reset();
                        if (this.swing.getValue().booleanValue()) {
                            PacketMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        }
                        PacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                        this.delayTimer.reset();
                    }
                }
            }
        } else {
            this.startMine = false;
            this.breakNumber = 0;
            breakPos = null;
        }
    }

    @SubscribeEvent(priority=EventPriority.LOW)
    public void onMotion(UpdateWalkingPlayerEvent event) {
        if (!PacketMine.fullNullCheck() && (!this.onlyGround.getValue().booleanValue() || PacketMine.mc.field_71439_g.field_70122_E || this.allowWeb.getValue().booleanValue() && PacketMine.mc.field_71439_g.field_70134_J) && this.rotate.getValue().booleanValue() && breakPos != null && !PacketMine.mc.field_71441_e.func_175623_d(breakPos) && this.time.getValue() > 0) {
            float breakTime;
            int slot = this.getTool(breakPos);
            if (slot == -1) {
                slot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c + 36;
            }
            if ((breakTime = PacketMine.getBreakTime(breakPos, slot) - (float)this.time.getValue().intValue()) <= 0.0f || this.mineTimer.passedMs((long)breakTime)) {
                PacketMine.facePosFacing(breakPos, BlockUtil.getRayTraceFacing(breakPos));
            }
        }
    }

    public static float getBreakTime(BlockPos pos, int slot) {
        return 1.0f / PacketMine.getBlockStrength(pos, (ItemStack)PacketMine.mc.field_71439_g.field_71069_bz.func_75138_a().get(slot)) / 20.0f * 1000.0f * PacketMine.INSTANCE.damage.getValue().floatValue() * (PacketMine.INSTANCE.tpsSync.getValue() != false ? Client.serverManager.getTPS() / 20.0f : 1.0f);
    }

    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void onSend(PacketEvent.Send event) {
        if (!PacketMine.fullNullCheck() && !PacketMine.mc.field_71439_g.func_184812_l_() && this.debug.getValue().booleanValue() && event.getPacket() instanceof CPacketPlayerDigging) {
            this.sendModuleMessage(((CPacketPlayerDigging)event.getPacket()).func_180762_c().name());
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (!PacketMine.fullNullCheck() && !PacketMine.mc.field_71439_g.func_184812_l_()) {
            if (event.getPacket() instanceof CPacketHeldItemChange) {
                if (((CPacketHeldItemChange)event.getPacket()).func_149614_c() != this.lastSlot) {
                    this.lastSlot = ((CPacketHeldItemChange)event.getPacket()).func_149614_c();
                    if (this.switchReset.getValue().booleanValue()) {
                        this.startMine = false;
                        this.mineTimer.reset();
                        this.animationTime.reset();
                    }
                }
            } else if (event.getPacket() instanceof CPacketPlayerDigging) {
                if (((CPacketPlayerDigging)event.getPacket()).func_180762_c() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                    if (breakPos == null || !((CPacketPlayerDigging)event.getPacket()).func_179715_a().equals((Object)breakPos)) {
                        event.setCanceled(true);
                        return;
                    }
                    this.startMine = true;
                } else if (((CPacketPlayerDigging)event.getPacket()).func_180762_c() == CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                    if (breakPos == null || !((CPacketPlayerDigging)event.getPacket()).func_179715_a().equals((Object)breakPos)) {
                        event.setCanceled(true);
                        return;
                    }
                    if (!this.instant.getValue().booleanValue()) {
                        this.startMine = false;
                    }
                }
            }
        }
    }

    public static void facePosFacing(BlockPos pos, EnumFacing side) {
        Vec3d hitVec = new Vec3d((Vec3i)pos).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(side.func_176730_m()).func_186678_a(0.5));
        PacketMine.faceVector(hitVec);
    }

    private static void faceVector(Vec3d vec) {
        float[] rotations = RebirthUtil.getLegitRotations(vec);
        RebirthUtil.faceYawAndPitch(rotations[0], rotations[1]);
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        this.update();
        if (!PacketMine.mc.field_71439_g.func_184812_l_() && breakPos != null) {
            if (this.debug.getValue().booleanValue()) {
                RenderUtil.drawBBFill(new AxisAlignedBB(breakPos.func_177972_a(BlockUtil.getRayTraceFacing(breakPos))), new Color(255, 255, 255), 70);
            }
            if (this.render.getValue().booleanValue()) {
                if (PacketMine.mc.field_71441_e.func_175623_d(breakPos) && !this.wait.getValue().booleanValue() && !this.instant.getValue().booleanValue()) {
                    return;
                }
                if (godBlocks.contains(PacketMine.mc.field_71441_e.func_180495_p(breakPos).func_177230_c())) {
                    this.draw(breakPos, 1.0, this.colorMode.getValue() == ColorMode.Custom ? this.getColor() : new Color(255, 0, 0, 255), true);
                    if (this.text.getValue().booleanValue()) {
                        AxisAlignedBB renderBB = PacketMine.mc.field_71441_e.func_180495_p(breakPos).func_185918_c((World)PacketMine.mc.field_71441_e, breakPos);
                        RebirthUtil.drawText(renderBB, ChatFormatting.RED + "GodBlock");
                    }
                } else {
                    int slot = this.getTool(breakPos);
                    if (slot == -1) {
                        slot = PacketMine.mc.field_71439_g.field_71071_by.field_70461_c + 36;
                    }
                    this.animationTime.setLength((long)PacketMine.getBreakTime(breakPos, slot));
                    this.draw(breakPos, PacketMine.mc.field_71441_e.func_175623_d(breakPos) ? 1.0 : this.animationTime.easeOutQuad(), this.colorMode.getValue() == ColorMode.Custom ? this.getColor() : new Color((int)(255.0 * Math.abs(this.animationTime.easeOutQuad() - 1.0)), (int)(255.0 * this.animationTime.easeOutQuad()), 0), PacketMine.mc.field_71441_e.func_175623_d(breakPos));
                    if (this.text.getValue().booleanValue()) {
                        AxisAlignedBB renderBB = PacketMine.mc.field_71441_e.func_180495_p(breakPos).func_185918_c((World)PacketMine.mc.field_71441_e, breakPos);
                        if (!PacketMine.mc.field_71441_e.func_175623_d(breakPos)) {
                            if (this.textMode.getValue() == TextMode.Progress) {
                                if ((float)((int)this.mineTimer.getPassedTimeMs()) < PacketMine.getBreakTime(breakPos, slot)) {
                                    double num1 = (double)this.mineTimer.getPassedTimeMs() / (double)(1.0f / PacketMine.getBlockStrength(breakPos, (ItemStack)PacketMine.mc.field_71439_g.field_71069_bz.func_75138_a().get(slot)) / 20.0f * 1000.0f * this.damage.getValue().floatValue() / 100.0f);
                                    DecimalFormat df = new DecimalFormat("0.0");
                                    RebirthUtil.drawText(renderBB, df.format(num1) + "%", this.textColorMode.getValue() == ColorMode.Progress ? new Color((int)(255.0 * Math.abs(this.animationTime.easeOutQuad() - 1.0)), (int)(255.0 * this.animationTime.easeOutQuad()), 0, 255) : this.getTextColor());
                                } else {
                                    RebirthUtil.drawText(renderBB, "100.0%", this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                                }
                            } else if (this.textMode.getValue() == TextMode.Time) {
                                if ((float)((int)this.mineTimer.getPassedTimeMs()) < PacketMine.getBreakTime(breakPos, slot)) {
                                    RebirthUtil.drawText(renderBB, this.mineTimer.getPassedTimeMs() + (this.showMax.getValue() != false ? "/" + (int)PacketMine.getBreakTime(breakPos, slot) : ""), this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                                } else {
                                    RebirthUtil.drawText(renderBB, String.valueOf((int)PacketMine.getBreakTime(breakPos, slot)), this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                                }
                            } else if (this.textMode.getValue() == TextMode.Tick) {
                                if ((float)((int)this.mineTimer.getPassedTimeMs()) < PacketMine.getBreakTime(breakPos, slot)) {
                                    RebirthUtil.drawText(renderBB, (int)(this.mineTimer.getPassedTimeMs() / 50L) + (this.showMax.getValue() != false ? "/" + (int)(PacketMine.getBreakTime(breakPos, slot) / 50.0f) : ""), this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                                } else {
                                    RebirthUtil.drawText(renderBB, String.valueOf((int)(PacketMine.getBreakTime(breakPos, slot) / 50.0f)), this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                                }
                            }
                        } else {
                            RebirthUtil.drawText(renderBB, "Waiting", this.textColorMode.getValue() == ColorMode.Progress ? new Color(0, 255, 0, 255) : this.getTextColor());
                        }
                    }
                }
            }
        }
    }

    public void draw(BlockPos pos, double size, Color color, boolean full) {
        if (this.animationMode.getValue() != Mode.Both && this.animationMode.getValue() != Mode.Custom) {
            AxisAlignedBB axisAlignedBB;
            if (full) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
            } else if (this.animationMode.getValue() == Mode.InToOut) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
            } else if (this.animationMode.getValue() == Mode.Up) {
                AxisAlignedBB bb = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
                axisAlignedBB = new AxisAlignedBB(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * size, bb.field_72334_f);
            } else if (this.animationMode.getValue() == Mode.Down) {
                AxisAlignedBB bb = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
                axisAlignedBB = new AxisAlignedBB(bb.field_72340_a, bb.field_72337_e - (bb.field_72337_e - bb.field_72338_b) * size, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f);
            } else if (this.animationMode.getValue() == Mode.OutToIn) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g(-Math.abs(size / 2.0 - 1.0));
            } else if (this.animationMode.getValue() == Mode.None) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
            } else {
                AxisAlignedBB bb = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
                AxisAlignedBB bb2 = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
                axisAlignedBB = this.animationMode.getValue() == Mode.Horizontal ? new AxisAlignedBB(bb2.field_72340_a, bb.field_72338_b, bb2.field_72339_c, bb2.field_72336_d, bb.field_72337_e, bb2.field_72334_f) : new AxisAlignedBB(bb.field_72340_a, bb2.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb2.field_72337_e, bb.field_72334_f);
            }
            if (this.outline.getValue().booleanValue()) {
                RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
        } else if (this.animationMode.getValue() == Mode.Custom) {
            AxisAlignedBB axisAlignedBB;
            if (full) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
                if (this.outline.getValue().booleanValue()) {
                    RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
                }
            } else {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g((double)(-this.fillStart.getValue().floatValue()) - size * (double)(1.0f - this.fillStart.getValue().floatValue()));
                double boxSize = size + (double)this.boxExtend.getValue().floatValue();
                if (boxSize > 1.0) {
                    boxSize = 1.0;
                }
                AxisAlignedBB axisAlignedBB2 = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g((double)(-this.boxStart.getValue().floatValue()) - boxSize * (double)(1.0f - this.boxStart.getValue().floatValue()));
                if (this.outline.getValue().booleanValue()) {
                    RenderUtil.drawBBBox(axisAlignedBB2, color, this.outlineAlpha.getValue());
                }
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
        } else {
            AxisAlignedBB axisAlignedBB;
            if (full) {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos);
            } else {
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g(size / 2.0 - 0.5);
                if (this.outline.getValue().booleanValue()) {
                    RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
                }
                if (this.box.getValue().booleanValue()) {
                    RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
                }
                axisAlignedBB = PacketMine.mc.field_71441_e.func_180495_p(pos).func_185918_c((World)PacketMine.mc.field_71441_e, pos).func_186662_g(-Math.abs(size / 2.0 - 1.0));
            }
            if (this.outline.getValue().booleanValue()) {
                RenderUtil.drawBBBox(axisAlignedBB, color, this.outlineAlpha.getValue());
            }
            if (this.box.getValue().booleanValue()) {
                RenderUtil.drawBBFill(axisAlignedBB, color, this.boxAlpha.getValue());
            }
        }
    }

    private int getTool(BlockPos pos) {
        if (this.hotBar.getValue().booleanValue()) {
            int index = -1;
            float CurrentFastest = 1.0f;
            for (int i = 0; i < 9; ++i) {
                float destroySpeed;
                float digSpeed;
                ItemStack stack = PacketMine.mc.field_71439_g.field_71071_by.func_70301_a(i);
                if (stack == ItemStack.field_190927_a || !((digSpeed = (float)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185305_q, (ItemStack)stack)) + (destroySpeed = stack.func_150997_a(PacketMine.mc.field_71441_e.func_180495_p(pos))) > CurrentFastest)) continue;
                CurrentFastest = digSpeed + destroySpeed;
                index = 36 + i;
            }
            return index;
        }
        AtomicInteger slot = new AtomicInteger();
        slot.set(-1);
        float CurrentFastest = 1.0f;
        for (Map.Entry<Integer, ItemStack> entry : RebirthUtil.getInventoryAndHotbarSlots().entrySet()) {
            float destroySpeed;
            float digSpeed;
            if (entry.getValue().func_77973_b() instanceof ItemAir || !((digSpeed = (float)EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185305_q, (ItemStack)entry.getValue())) + (destroySpeed = entry.getValue().func_150997_a(PacketMine.mc.field_71441_e.func_180495_p(pos))) > CurrentFastest)) continue;
            CurrentFastest = digSpeed + destroySpeed;
            slot.set(entry.getKey());
        }
        return slot.get();
    }

    @SubscribeEvent
    public void onClickBlock(BlockEvent event) {
        if (!PacketMine.fullNullCheck() && !PacketMine.mc.field_71439_g.func_184812_l_()) {
            event.setCanceled(true);
            if (!(godBlocks.contains(PacketMine.mc.field_71441_e.func_180495_p(event.pos).func_177230_c()) && this.godCancel.getValue().booleanValue() || event.pos.equals((Object)breakPos))) {
                breakPos = event.pos;
                this.mineTimer.reset();
                this.animationTime.reset();
                if (!godBlocks.contains(PacketMine.mc.field_71441_e.func_180495_p(event.pos).func_177230_c())) {
                    this.firstTimer.reset();
                    PacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                    if (this.doubleBreak.getValue().booleanValue()) {
                        PacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                        PacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, BlockUtil.getRayTraceFacing(breakPos)));
                    }
                    this.breakNumber = 0;
                }
            }
        }
    }

    private static boolean canBreak(BlockPos pos) {
        IBlockState blockState = PacketMine.mc.field_71441_e.func_180495_p(pos);
        Block block = blockState.func_177230_c();
        return block.func_176195_g(blockState, (World)PacketMine.mc.field_71441_e, pos) != -1.0f;
    }

    public static float getBlockStrength(BlockPos position, ItemStack itemStack) {
        IBlockState state = PacketMine.mc.field_71441_e.func_180495_p(position);
        float hardness = state.func_185887_b((World)PacketMine.mc.field_71441_e, position);
        if (hardness < 0.0f) {
            return 0.0f;
        }
        return !PacketMine.canBreak(position) ? PacketMine.getDigSpeed(state, itemStack) / hardness / 100.0f : PacketMine.getDigSpeed(state, itemStack) / hardness / 30.0f;
    }

    public static float getDigSpeed(IBlockState state, ItemStack itemStack) {
        int efficiencyModifier;
        float digSpeed = PacketMine.getDestroySpeed(state, itemStack);
        if (digSpeed > 1.0f && (efficiencyModifier = EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185305_q, (ItemStack)itemStack)) > 0 && !itemStack.func_190926_b()) {
            digSpeed = (float)((double)digSpeed + StrictMath.pow(efficiencyModifier, 2.0) + 1.0);
        }
        if (PacketMine.mc.field_71439_g.func_70644_a(MobEffects.field_76422_e)) {
            digSpeed *= 1.0f + (float)(PacketMine.mc.field_71439_g.func_70660_b(MobEffects.field_76422_e).func_76458_c() + 1) * 0.2f;
        }
        if (PacketMine.mc.field_71439_g.func_70644_a(MobEffects.field_76419_f)) {
            float fatigueScale;
            switch (PacketMine.mc.field_71439_g.func_70660_b(MobEffects.field_76419_f).func_76458_c()) {
                case 0: {
                    fatigueScale = 0.3f;
                    break;
                }
                case 1: {
                    fatigueScale = 0.09f;
                    break;
                }
                case 2: {
                    fatigueScale = 0.0027f;
                    break;
                }
                default: {
                    fatigueScale = 8.1E-4f;
                }
            }
            digSpeed *= fatigueScale;
        }
        if (PacketMine.mc.field_71439_g.func_70055_a(Material.field_151586_h) && !EnchantmentHelper.func_185287_i((EntityLivingBase)PacketMine.mc.field_71439_g)) {
            digSpeed /= 5.0f;
        }
        if ((!PacketMine.mc.field_71439_g.field_70122_E || PacketMine.isInSpoofGround()) && PacketMine.INSTANCE.checkGround.getValue().booleanValue()) {
            digSpeed /= 5.0f;
        }
        return digSpeed < 0.0f ? 0.0f : digSpeed;
    }

    public static boolean isInSpoofGround() {
        return SpoofGround.INSTANCE.isOn() || PacketTranslation.INSTANCE.cPlayer_OnGround.getValue() == PacketTranslation.OnGroundForce.False;
    }

    public static float getDestroySpeed(IBlockState state, ItemStack itemStack) {
        float destroySpeed = 1.0f;
        if (itemStack != null && !itemStack.func_190926_b()) {
            destroySpeed *= itemStack.func_150997_a(state);
        }
        return destroySpeed;
    }

    public boolean canPlaceCrystal(BlockPos pos, boolean ignoreItem) {
        BlockPos obsPos = pos.func_177977_b();
        BlockPos boost = obsPos.func_177984_a();
        BlockPos boost2 = obsPos.func_177981_b(2);
        return (PacketMine.getBlock(obsPos) == Blocks.field_150357_h || PacketMine.getBlock(obsPos) == Blocks.field_150343_Z) && (PacketMine.getBlock(boost) == Blocks.field_150350_a || PacketMine.getBlock(boost) == Blocks.field_150480_ab && this.placeInFire.getValue() != false) && PacketMine.noEntity(boost, ignoreItem) && PacketMine.getBlock(boost2) == Blocks.field_150350_a && PacketMine.noEntity(boost2, ignoreItem);
    }

    public static boolean noEntity(BlockPos pos, boolean ignoreItem) {
        for (Entity entity : PacketMine.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos))) {
            if (entity instanceof EntityItem && ignoreItem) continue;
            return false;
        }
        return true;
    }

    public static Block getBlock(BlockPos pos) {
        return PacketMine.mc.field_71441_e.func_180495_p(pos).func_177230_c();
    }

    public Color getTextColor() {
        return new Color(this.textColorR.getValue(), this.textColorG.getValue(), this.textColorB.getValue());
    }

    public Color getColor() {
        return new Color(this.colorR.getValue(), this.colorG.getValue(), this.colorB.getValue());
    }

    public static enum TextMode {
        Time,
        Tick,
        Progress;

    }

    public static enum Mode {
        Down,
        Up,
        InToOut,
        OutToIn,
        Both,
        Vertical,
        Horizontal,
        Custom,
        None;

    }

    public static enum ColorMode {
        Custom,
        Progress;

    }
}

