/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketConfirmTransaction
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketPlayer$PositionRotation
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.player;

import it.make.api.events.network.PacketEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;
import java.util.LinkedList;
import java.util.concurrent.LinkedBlockingQueue;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketConfirmTransaction;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0013\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\b\u0010\u0017\u001a\u00020\u0018H\u0016J\b\u0010\u0019\u001a\u00020\u0016H\u0016J\b\u0010\u001a\u001a\u00020\u0016H\u0016J\u0010\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001c\u001a\u00020\u001dH\u0007J\b\u0010\u001e\u001a\u00020\u0016H\u0016R2\u0010\u0003\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0018\u0010\n\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\f0\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R2\u0010\u0010\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00110\u0011 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00110\u0011\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004\u00a2\u0006\u0002\n\u0000R2\u0010\u0014\u001a&\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005 \u0006*\u0012\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0018\u00010\u00040\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u001f"}, d2={"Lit/make/modules/player/Blink;", "Lit/make/modules/Module;", "()V", "cancelC0f", "Lit/make/api/setting/Setting;", "", "kotlin.jvm.PlatformType", "disableLogger", "fakePlayer", "Lnet/minecraft/client/entity/EntityOtherPlayerMP;", "packets", "Ljava/util/concurrent/LinkedBlockingQueue;", "Lnet/minecraft/network/Packet;", "positions", "Ljava/util/LinkedList;", "", "pulseDelayValue", "", "pulseTimer", "Lit/make/api/utils/Timer;", "pulseValue", "blink", "", "getDisplayInfo", "", "onDisable", "onEnable", "onPacket", "event", "Lit/make/api/events/network/PacketEvent;", "onUpdate", "Make.Life"})
public final class Blink
extends Module {
    @NotNull
    private final LinkedBlockingQueue<Packet<?>> packets = new LinkedBlockingQueue();
    @Nullable
    private EntityOtherPlayerMP fakePlayer;
    private boolean disableLogger;
    @NotNull
    private final LinkedList<double[]> positions = new LinkedList();
    private final Setting<Boolean> pulseValue = this.rbool("Pulse", false);
    private final Setting<Integer> pulseDelayValue = this.rinte("PulseDelay", 1000, 500, 5000);
    @NotNull
    private final Timer pulseTimer = new Timer();
    private final Setting<Boolean> cancelC0f = this.rbool("AntiCheat", true);

    public Blink() {
        super("Blink", "OpenSkyrim", Module.Category.PLAYER);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onEnable() {
        EntityPlayerSP entityPlayerSP = Module.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        if (!this.pulseValue.getValue().booleanValue()) {
            WorldClient worldClient = Module.mc.field_71441_e;
            Intrinsics.checkNotNull(worldClient);
            EntityOtherPlayerMP faker = new EntityOtherPlayerMP((World)worldClient, thePlayer.func_146103_bH());
            faker.field_70759_as = thePlayer.field_70759_as;
            faker.field_70761_aq = thePlayer.field_70761_aq;
            faker.func_82149_j((Entity)thePlayer);
            faker.field_70759_as = thePlayer.field_70759_as;
            WorldClient worldClient2 = Module.mc.field_71441_e;
            Intrinsics.checkNotNull(worldClient2);
            worldClient2.func_73027_a(-1337, (Entity)faker);
            this.fakePlayer = faker;
        }
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            double[] dArray = new double[]{thePlayer.field_70165_t, thePlayer.func_174813_aQ().field_72338_b + (double)(thePlayer.eyeHeight / (float)2), thePlayer.field_70161_v};
            this.positions.add(dArray);
            dArray = new double[]{thePlayer.field_70165_t, thePlayer.func_174813_aQ().field_72338_b, thePlayer.field_70161_v};
            boolean bl2 = this.positions.add(dArray);
        }
        this.pulseTimer.reset();
    }

    @Override
    public void onDisable() {
        if (Module.mc.field_71439_g == null) {
            return;
        }
        this.blink();
        EntityOtherPlayerMP faker = this.fakePlayer;
        if (faker != null) {
            WorldClient worldClient = Module.mc.field_71441_e;
            if (worldClient != null) {
                worldClient.func_73028_b(faker.field_145783_c);
            }
            this.fakePlayer = null;
        }
    }

    @SubscribeEvent
    public final void onPacket(@NotNull PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, "event");
        Object packet = event.getPacket();
        if (Module.mc.field_71439_g == null || this.disableLogger) {
            return;
        }
        if (packet instanceof CPacketPlayer) {
            event.setCanceled(true);
        }
        if (packet instanceof CPacketPlayer.Position || packet instanceof CPacketPlayer.PositionRotation || packet instanceof CPacketPlayerTryUseItemOnBlock || packet instanceof CPacketAnimation || packet instanceof CPacketEntityAction || packet instanceof CPacketUseEntity) {
            event.setCanceled(true);
            this.packets.add((Packet<?>)packet);
        }
        if (packet instanceof CPacketConfirmTransaction) {
            Boolean bl = this.cancelC0f.getValue();
            Intrinsics.checkNotNullExpressionValue(bl, "cancelC0f.value");
            if (bl.booleanValue()) {
                event.setCanceled(true);
                this.packets.add((Packet<?>)packet);
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = Module.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            double[] dArray = new double[]{thePlayer.field_70165_t, thePlayer.func_174813_aQ().field_72338_b, thePlayer.field_70161_v};
            boolean bl2 = this.positions.add(dArray);
        }
        Boolean bl = this.pulseValue.getValue();
        Intrinsics.checkNotNullExpressionValue(bl, "pulseValue.value");
        if (bl.booleanValue() && this.pulseTimer.passedMs(((Number)this.pulseDelayValue.getValue()).intValue())) {
            this.blink();
            this.pulseTimer.reset();
        }
    }

    @Override
    @NotNull
    public String getDisplayInfo() {
        return String.valueOf(this.packets.size());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void blink() {
        try {
            this.disableLogger = true;
            while (!this.packets.isEmpty()) {
                Module.mc.field_71439_g.field_71174_a.func_147297_a(this.packets.take());
            }
            this.disableLogger = false;
        }
        catch (Exception e) {
            e.printStackTrace();
            this.disableLogger = false;
        }
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            this.positions.clear();
            Unit unit = Unit.INSTANCE;
        }
    }
}

