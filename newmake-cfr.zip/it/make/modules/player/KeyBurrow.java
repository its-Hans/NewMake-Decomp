/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockPistonExtension
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 */
package it.make.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.api.Wrapper;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.api.utils.second.skid.two.BlockUtil;
import it.make.modules.Module;
import it.make.modules.player.StayBurrow;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPistonExtension;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class KeyBurrow
extends Module {
    public static KeyBurrow INSTANCE;
    Timer timer = new Timer();
    Setting<Page> page = this.rother("Page", Page.General);
    Setting<Double> offset1 = this.rdoub("Offset", 1.2, -5.0, 10.0, v -> this.page.getValue() == Page.General);
    Setting<Bind> key = this.rbind("Key", Bind.none(), v -> this.page.getValue() == Page.General);
    Setting<Integer> delay = this.rinte("Delay", 80, 0, 2000, v -> this.page.getValue() == Page.General);
    Setting<Boolean> swing = this.rbool("Swing", true, v -> this.page.getValue() == Page.General);
    Setting<Boolean> tips = this.rbool("Tips", true, v -> this.page.getValue() == Page.General);
    Setting<FakeJumpMode> mode = this.rother("FakeJumpMode", FakeJumpMode.StayOld);
    Setting<Boolean> check1 = this.rbool("YIn", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check2 = this.rbool("Ground", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check3 = this.rbool("Trap", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check4 = this.rbool("Web", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check5 = this.rbool("Liquid", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check6 = this.rbool("Screen", true, v -> this.page.getValue() == Page.Check);
    Setting<Boolean> check7 = this.rbool("PistonHead", true, v -> this.page.getValue() == Page.Check);

    public KeyBurrow() {
        super("KeyBurrow", "idk", Module.Category.PLAYER);
        INSTANCE = this;
    }

    public static Set<BlockPos> burPosList() {
        Vec3d playerPos = KeyBurrow.mc.field_71439_g.func_174791_d();
        return new TreeSet<BlockPos>(Arrays.asList(new BlockPos(playerPos.func_72441_c(0.3, 0.0, 0.3)), new BlockPos(playerPos.func_72441_c(0.3, 0.0, -0.3)), new BlockPos(playerPos.func_72441_c(-0.3, 0.0, 0.3)), new BlockPos(playerPos.func_72441_c(-0.3, 0.0, -0.3))));
    }

    public static int getCombatBlockSlot() {
        int bc = UtilsRewrite.UInventory.itemSlot(Item.func_150898_a((Block)Blocks.field_150461_bJ));
        if (bc != -1) {
            return bc;
        }
        int ob = UtilsRewrite.UInventory.itemSlot(Item.func_150898_a((Block)Blocks.field_150343_Z));
        if (ob != -1) {
            return ob;
        }
        return UtilsRewrite.UInventory.itemSlot(Item.func_150898_a((Block)Blocks.field_150477_bB));
    }

    public static int switchPre(int slot) {
        int post = KeyBurrow.mc.field_71439_g.field_71071_by.field_70461_c;
        KeyBurrow.switchToSlot(slot);
        return post;
    }

    public static void switchToSlot(int slot) {
        UtilsRewrite.UInventory.heldItemChange(slot, true, false, true);
    }

    @Override
    public void onToggle() {
        this.timer.reset();
    }

    @Override
    public void onUpdate() {
        if (KeyBurrow.fullNullCheck() || !this.checks() || !this.key.getValue().isDown()) {
            return;
        }
        if (!this.timer.passedMs(this.delay.getValue().intValue())) {
            return;
        }
        this.timer.reset();
        int slot = KeyBurrow.getCombatBlockSlot();
        if (slot == -1) {
            if (this.tips.getValue().booleanValue()) {
                this.sendModuleMessage("No block found");
            }
            return;
        }
        if (this.findPlaceable().isEmpty()) {
            if (this.tips.getValue().booleanValue()) {
                this.sendModuleMessage("No pos found");
            }
            return;
        }
        StayBurrow.back();
        int post = KeyBurrow.switchPre(slot);
        FakeJumpMode mode = this.mode.getValue();
        mode.pre.run();
        for (BlockPos pos : this.findPlaceable()) {
            BlockUtil.placeSync(pos, EnumHand.MAIN_HAND, true, true, this.swing.getValue());
            if (this.tips.getValue().booleanValue()) {
                KeyBurrow.notiMessage(ChatFormatting.GRAY + "[" + ChatFormatting.RESET + this.getDisplayName() + ChatFormatting.GRAY + "] burr on " + UtilsRewrite.UBlock.getPosString(pos, ", "));
            }
            if (this.delay.getValue() == 0) continue;
            break;
        }
        KeyBurrow.switchToSlot(post);
        mode.post.run();
    }

    public Set<BlockPos> findPlaceable() {
        HashSet<BlockPos> placeable = new HashSet<BlockPos>();
        for (BlockPos pos : KeyBurrow.burPosList()) {
            if (!this.placeableCheck(pos)) continue;
            placeable.add(pos);
        }
        return placeable;
    }

    public static double getYMore() {
        return KeyBurrow.mc.field_71439_g.field_70163_u - (double)((int)KeyBurrow.mc.field_71439_g.field_70163_u);
    }

    public boolean checks() {
        boolean one = KeyBurrow.getYMore() <= 0.251;
        boolean two = KeyBurrow.mc.field_71439_g.field_70122_E;
        boolean three = !this.isTrapped();
        boolean four = !KeyBurrow.mc.field_71439_g.field_70134_J;
        boolean five = !KeyBurrow.mc.field_71439_g.func_180799_ab() && !KeyBurrow.mc.field_71439_g.func_70090_H();
        boolean six = KeyBurrow.mc.field_71462_r == null;
        boolean seven = !this.isInPistonHead();
        return !(!one && this.check1.getValue() != false || !two && this.check2.getValue() != false || !three && this.check3.getValue() != false || !four && this.check4.getValue() != false || !five && this.check5.getValue() != false || !six && this.check6.getValue() != false || !seven && this.check7.getValue() != false);
    }

    public boolean isTrapped() {
        for (BlockPos pos : KeyBurrow.burPosList()) {
            if (UtilsRewrite.UBlock.getBlock(pos.func_177981_b(2)) == Blocks.field_150350_a) continue;
            return true;
        }
        return false;
    }

    public boolean isInPistonHead() {
        for (BlockPos pos : KeyBurrow.burPosList()) {
            if (!(UtilsRewrite.UBlock.getState(pos) instanceof BlockPistonExtension)) continue;
            return true;
        }
        return false;
    }

    public boolean placeableCheck(BlockPos pos) {
        boolean one = UtilsRewrite.UBlock.getState(pos).func_185904_a().func_76222_j();
        boolean two = UtilsRewrite.UBlock.getBlock(pos.func_177977_b()) != Blocks.field_150350_a;
        return one && two;
    }

    static enum FakeJumpMode {
        M3dC3t(() -> {
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.41999998688698, Wrapper.mc.field_71439_g.field_70161_v, true));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.7531999805211997, Wrapper.mc.field_71439_g.field_70161_v, true));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.99948615796915, Wrapper.mc.field_71439_g.field_70161_v, true));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.06610926093821, Wrapper.mc.field_71439_g.field_70161_v, true));
        }, () -> Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + KeyBurrow.INSTANCE.offset1.getValue(), Wrapper.mc.field_71439_g.field_70161_v, false))),
        Tcy(() -> {
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.4199999868869781, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.7531999805212017, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.9999957640154541, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.1661092609382138, Wrapper.mc.field_71439_g.field_70161_v, false));
        }, () -> Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, -7.0, Wrapper.mc.field_71439_g.field_70161_v, false))),
        StayOld(() -> {
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.419999986886978, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.7531999805212015, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.001335979112147, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.166109260938214, Wrapper.mc.field_71439_g.field_70161_v, false));
        }, () -> Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + KeyBurrow.INSTANCE.offset1.getValue(), Wrapper.mc.field_71439_g.field_70161_v, false))),
        MadCat(() -> {
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.4199999868869781, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.7531999805212017, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.9999957640154541, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.1661092609382138, Wrapper.mc.field_71439_g.field_70161_v, false));
        }, () -> Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, -7.0, Wrapper.mc.field_71439_g.field_70161_v, false))),
        Rebirth(() -> {
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.4199999868869781, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.7531999805212017, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 0.9999957640154541, Wrapper.mc.field_71439_g.field_70161_v, false));
            Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, Wrapper.mc.field_71439_g.field_70163_u + 1.1661092609382138, Wrapper.mc.field_71439_g.field_70161_v, false));
        }, () -> Wrapper.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Wrapper.mc.field_71439_g.field_70165_t, -7.0, Wrapper.mc.field_71439_g.field_70161_v, false)));

        final Runnable pre;
        final Runnable post;

        private FakeJumpMode(Runnable pre, Runnable post) {
            this.pre = pre;
            this.post = post;
        }
    }

    static enum Page {
        General,
        Check;

    }
}

