/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketEntityVelocity
 *  net.minecraft.network.play.server.SPacketExplosion
 *  net.minecraftforge.client.event.InputUpdateEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.player;

import it.make.api.events.network.PacketEvent;
import it.make.api.events.player.PushEvent;
import it.make.api.events.player.StopGuiMoveEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PlayerTweaks
extends Module {
    private static PlayerTweaks INSTANCE;
    public Setting<Boolean> chatOnPortal = this.rbool("PortalChat", false);
    public Setting<Boolean> sprint = this.rbool("Sprint", false);
    public Setting<Boolean> guiMove = this.rbool("GuiMove", false);
    public Setting<Boolean> multiTask = this.rbool("MultiTask", false);
    public Setting<Boolean> noKb = this.rbool("No Kb", false);
    public Setting<Boolean> noSlow = this.rbool("No Slow", false);
    public Setting<Boolean> noPush = this.rbool("No Push", false);

    public PlayerTweaks() {
        super(new I18NInfo("PlayerTweaks").bind(EnumI18N.Chinese, "\u73a9\u5bb6\u8c03\u8bd5"), "tweaks", Module.Category.PLAYER);
        INSTANCE = this;
    }

    public static PlayerTweaks getInstance() {
        return INSTANCE;
    }

    @SubscribeEvent
    public void Slow(InputUpdateEvent event) {
        if (this.noSlow.getValue().booleanValue() && PlayerTweaks.mc.field_71439_g.func_184587_cr() && !PlayerTweaks.mc.field_71439_g.func_184218_aH()) {
            event.getMovementInput().field_78902_a *= 5.0f;
            event.getMovementInput().field_192832_b *= 5.0f;
        }
    }

    @SubscribeEvent
    public void onIfMoveStopable(StopGuiMoveEvent event) {
        if (event.isNormal() && this.guiMove.getValue().booleanValue()) {
            event.setMoveable();
        }
    }

    @SubscribeEvent
    public void onPacketReceived(PacketEvent.Receive event) {
        if (PlayerTweaks.fullNullCheck()) {
            return;
        }
        if (this.noKb.getValue().booleanValue()) {
            if (event.getPacket() instanceof SPacketEntityVelocity && ((SPacketEntityVelocity)event.getPacket()).func_149412_c() == PlayerTweaks.mc.field_71439_g.func_145782_y()) {
                event.setCanceled(true);
            }
            if (event.getPacket() instanceof SPacketExplosion) {
                event.setCanceled(true);
            }
        }
    }

    @Override
    public void onUpdate() {
        if (PlayerTweaks.fullNullCheck()) {
            return;
        }
        if (this.sprint.getValue().booleanValue() && PlayerTweaks.mc.field_71474_y.field_74351_w.func_151470_d() && !PlayerTweaks.mc.field_71439_g.func_70093_af() && !PlayerTweaks.mc.field_71439_g.field_70123_F && !((float)PlayerTweaks.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f)) {
            PlayerTweaks.mc.field_71439_g.func_70031_b(true);
        }
        if (this.chatOnPortal.getValue().booleanValue() && PlayerTweaks.mc.field_71439_g.field_71087_bX) {
            PlayerTweaks.mc.field_71439_g.field_71087_bX = false;
        }
    }

    @SubscribeEvent
    public void onPush(PushEvent event) {
        if (this.noPush.getValue().booleanValue() && !PlayerTweaks.fullNullCheck()) {
            if (event.getStage() == 0) {
                if (event.entity.equals((Object)PlayerTweaks.mc.field_71439_g)) {
                    event.x = -event.x * 0.0;
                    event.y = -event.y * 0.0;
                    event.z = -event.z * 0.0;
                }
            } else if (event.getStage() == 1) {
                event.setCanceled(true);
            } else if (event.getStage() == 2 && event.entity.equals((Object)PlayerTweaks.mc.field_71439_g)) {
                event.setCanceled(true);
            }
        }
    }
}

