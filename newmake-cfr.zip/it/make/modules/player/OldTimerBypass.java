/*
 * Decompiled with CFR 0.152.
 */
package it.make.modules.player;

import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.modules.Module;

public class OldTimerBypass
extends Module {
    private final Setting<Boolean> tickMode = this.register(new Setting<Boolean>("TickMode", false));
    public final Setting<Integer> disableTicks = this.register(new Setting<Integer>("Disable Ticks", Integer.valueOf(30), Integer.valueOf(1), Integer.valueOf(100), v -> this.tickMode.getValue()));
    public final Setting<Integer> noPauseTicks = this.register(new Setting<Integer>("UnPause Ticks", Integer.valueOf(30), Integer.valueOf(1), Integer.valueOf(100), v -> this.tickMode.getValue()));
    public int ticksPassed = 0;
    public int unPauseTicks = 0;
    public boolean pause = false;
    public final Setting<Float> tickNormal = this.register(new Setting<Float>("Speed", Float.valueOf(1.2f), Float.valueOf(1.0f), Float.valueOf(10.0f)));
    private final Setting<Boolean> bypass = this.register(new Setting<Boolean>("Bypass", Boolean.valueOf(true), v -> this.tickMode.getValue() == false));
    public final Setting<Float> speedvalue = this.register(new Setting<Float>("SpeedValue", Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(100.0f), v -> this.tickMode.getValue() == false && this.bypass.getValue() != false));
    public int i = 0;
    public int x = 0;
    private final Timer timer = new Timer();

    public OldTimerBypass() {
        super("OldTimerBypass", "Change client running speed.", Module.Category.PLAYER, true, false, false);
    }

    @Override
    public void onDisable() {
        OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f;
    }

    @Override
    public void onEnable() {
        OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f;
    }

    @Override
    public void onUpdate() {
        if (this.tickMode.getValue().booleanValue()) {
            ++this.ticksPassed;
            if (!this.pause) {
                OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f / this.tickNormal.getValue().floatValue();
            }
            if (this.pause) {
                ++this.unPauseTicks;
                OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f;
            }
            if (this.ticksPassed >= this.disableTicks.getValue()) {
                this.ticksPassed = 0;
                if (this.unPauseTicks <= this.noPauseTicks.getValue()) {
                    this.pause = true;
                } else if (this.unPauseTicks >= this.noPauseTicks.getValue()) {
                    this.pause = false;
                    this.unPauseTicks = 0;
                }
            }
        } else if (this.bypass.getValue().booleanValue()) {
            if ((float)this.i <= this.speedvalue.getValue().floatValue()) {
                ++this.i;
                OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f / this.tickNormal.getValue().floatValue();
                this.x = 0;
            } else if ((float)this.x <= this.speedvalue.getValue().floatValue() - this.speedvalue.getValue().floatValue() / 2.0f / 2.0f) {
                ++this.x;
                OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f;
            } else {
                this.i = 0;
            }
        } else {
            OldTimerBypass.mc.field_71428_T.field_194149_e = 50.0f / this.tickNormal.getValue().floatValue();
        }
    }

    @Override
    public void onLogin() {
        this.timer.reset();
    }
}

