/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.math.MathHelper
 */
package it.make.modules.player;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.EntityUtil;
import it.make.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;

public class Shake
extends Module {
    private int packets;
    public static Shake INSTANCE;
    Setting<String> input1 = this.register(new Setting<String>("i1", "0.301"));
    Setting<String> input2 = this.register(new Setting<String>("i2", "0.699"));
    Setting<String> input3 = this.register(new Setting<String>("i3", "0.23"));
    Setting<String> input4 = this.register(new Setting<String>("i4", "0.77"));

    private double roundToClosest(double d, double d2, double d3) {
        double d4 = d3 - d;
        double d5 = d - d2;
        if (d4 > d5) {
            return d2;
        }
        return d3;
    }

    public Shake() {
        super(new I18NInfo("Shake").bind(EnumI18N.Chinese, "\u81ea\u5b9a\u4e49\u5361\u5899"), "clip", Module.Category.PLAYER);
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        if (EntityUtil.isMoving()) {
            return;
        }
        Double pp1 = Shake.stringToDouble(this.input1.getValue());
        Double pp2 = Shake.stringToDouble(this.input2.getValue());
        Double pp3 = Shake.stringToDouble(this.input3.getValue());
        Double pp4 = Shake.stringToDouble(this.input4.getValue());
        if (pp1 == null || pp2 == null || pp3 == null || pp4 == null) {
            this.sendModuleMessage("not a number input!");
            return;
        }
        if (Shake.mc.field_71441_e.func_184144_a((Entity)Shake.mc.field_71439_g, Shake.mc.field_71439_g.func_174813_aQ().func_72314_b(0.01, 0.0, 0.01)).size() < 2) {
            Shake.mc.field_71439_g.func_70107_b(this.roundToClosest(Shake.mc.field_71439_g.field_70165_t, Math.floor(Shake.mc.field_71439_g.field_70165_t) + pp1, Math.floor(Shake.mc.field_71439_g.field_70165_t) + pp2), Shake.mc.field_71439_g.field_70163_u, this.roundToClosest(Shake.mc.field_71439_g.field_70161_v, Math.floor(Shake.mc.field_71439_g.field_70161_v) + pp1, Math.floor(Shake.mc.field_71439_g.field_70161_v) + pp2));
            this.packets = 0;
        } else if (Shake.mc.field_71439_g.field_70173_aa % 2 == 0) {
            Shake.mc.field_71439_g.func_70107_b(Shake.mc.field_71439_g.field_70165_t + MathHelper.func_151237_a((double)(this.roundToClosest(Shake.mc.field_71439_g.field_70165_t, Math.floor(Shake.mc.field_71439_g.field_70165_t) + 0.241, Math.floor(Shake.mc.field_71439_g.field_70165_t) + 0.759) - Shake.mc.field_71439_g.field_70165_t), (double)-0.03, (double)0.03), Shake.mc.field_71439_g.field_70163_u, Shake.mc.field_71439_g.field_70161_v + MathHelper.func_151237_a((double)(this.roundToClosest(Shake.mc.field_71439_g.field_70161_v, Math.floor(Shake.mc.field_71439_g.field_70161_v) + 0.241, Math.floor(Shake.mc.field_71439_g.field_70161_v) + 0.759) - Shake.mc.field_71439_g.field_70161_v), (double)-0.03, (double)0.03));
            Shake.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Shake.mc.field_71439_g.field_70165_t, Shake.mc.field_71439_g.field_70163_u, Shake.mc.field_71439_g.field_70161_v, true));
            Shake.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(this.roundToClosest(Shake.mc.field_71439_g.field_70165_t, Math.floor(Shake.mc.field_71439_g.field_70165_t) + pp3, Math.floor(Shake.mc.field_71439_g.field_70165_t) + pp4), Shake.mc.field_71439_g.field_70163_u, this.roundToClosest(Shake.mc.field_71439_g.field_70161_v, Math.floor(Shake.mc.field_71439_g.field_70161_v) + pp3, Math.floor(Shake.mc.field_71439_g.field_70161_v) + pp4), true));
            ++this.packets;
        }
    }

    @Override
    public void onDisable() {
        this.packets = 0;
    }

    @Override
    public String getDisplayInfo() {
        return String.valueOf(this.packets);
    }

    public static Double stringToDouble(String input) {
        if (input == null || input.isEmpty()) {
            return null;
        }
        String put = input.trim();
        if (!put.matches("\\d+\\.?\\d*")) {
            return null;
        }
        return Double.parseDouble(put);
    }
}

