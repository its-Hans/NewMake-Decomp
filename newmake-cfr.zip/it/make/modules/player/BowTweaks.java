/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemBow
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 */
package it.make.modules.player;

import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.modules.Module;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBow;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;

public class BowTweaks
extends Module {
    public static BowTweaks instance;
    private final Setting<Boolean> quiver = this.register(new Setting<Boolean>("Quiver", Boolean.valueOf(true), "shoot arrow at sky"));
    private final Setting<Integer> fastBow = this.register(new Setting<Integer>("FastBow", Integer.valueOf(3), Integer.valueOf(0), Integer.valueOf(20), "autorelease, if 0 dont do"));

    public BowTweaks() {
        super(new I18NInfo("BowTweaks").bind(EnumI18N.Chinese, "\u5f13\u7bad\u8c03\u8bd5"), "dk", Module.Category.PLAYER);
        instance = this;
    }

    @Override
    public void onUpdate() {
        if (BowTweaks.fullNullCheck()) {
            return;
        }
        if (BowTweaks.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow && BowTweaks.mc.field_71439_g.func_184587_cr() && BowTweaks.mc.field_71439_g.func_184612_cw() >= this.fastBow.getValue()) {
            if (this.quiver.getValue().booleanValue()) {
                BowTweaks.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(BowTweaks.mc.field_71439_g.field_71109_bG, -90.0f, BowTweaks.mc.field_71439_g.field_70122_E));
            }
            if (this.fastBow.getValue() != 0) {
                BowTweaks.mc.field_71442_b.func_78766_c((EntityPlayer)BowTweaks.mc.field_71439_g);
            }
            BowTweaks.notiMessage("shoot");
        }
    }
}

