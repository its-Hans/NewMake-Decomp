/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Enchantments
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerDigging
 *  net.minecraft.network.play.client.CPacketPlayerDigging$Action
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.api.events.block.BlockEvent;
import it.make.api.events.render.Render3DEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.BlockUtil;
import it.make.api.utils.RenderUtil;
import it.make.api.utils.Timer;
import it.make.api.utils.second.m4ke.general.UtilsRewrite;
import it.make.api.utils.second.skid.MathUtil;
import it.make.api.utils.second.skid.RebirthUtil;
import it.make.api.utils.second.skid.RotationUtil;
import it.make.modules.Module;
import java.awt.Color;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class OldPacketMine
extends Module {
    private final Setting<Boolean> silent = this.register(new Setting<Boolean>("Silent", true));
    private final Setting<Boolean> debug = this.register(new Setting<Boolean>("Debug", true));
    private final Setting<Boolean> autoRetry = this.register(new Setting<Boolean>("AutoRetry", true));
    private final Setting<Double> resetRange = this.register(new Setting<Integer>("resetRange", (Integer)5.4, (Integer)1.0, 60));
    public BlockPos renderPos = null;
    public BlockPos breakPos = null;
    public EnumFacing breakFace = null;
    public Timer timer = new Timer();
    public Timer instaTimer = new Timer();
    public boolean readyToMine = false;
    public int oldSlot = -1;
    long start = -1L;
    boolean swapBack;

    public OldPacketMine() {
        super(new I18NInfo("OldPacketMine").bind(EnumI18N.Chinese, "\u795e\u5fc5\u6316\u6398"), "Mine", Module.Category.PLAYER);
    }

    public static int bestSlot(BlockPos pos) {
        int best = 0;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            int eff;
            float speed;
            ItemStack stack = OldPacketMine.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_190926_b() || !((speed = stack.func_150997_a(OldPacketMine.mc.field_71441_e.func_180495_p(pos))) > 1.0f) || !((double)(speed += (float)((eff = EnchantmentHelper.func_77506_a((Enchantment)Enchantments.field_185305_q, (ItemStack)stack)) > 0 ? Math.pow(eff, 2.0) + 1.0 : 0.0)) > max)) continue;
            max = speed;
            best = i;
        }
        return best;
    }

    public static boolean canBlockBeBroken(BlockPos pos) {
        IBlockState blockState = OldPacketMine.mc.field_71441_e.func_180495_p(pos);
        return blockState.func_185887_b((World)OldPacketMine.mc.field_71441_e, pos) != -1.0f;
    }

    public static void sP(Packet<?> packet) {
        OldPacketMine.mc.field_71439_g.field_71174_a.func_147297_a(packet);
    }

    public static CPacketPlayerDigging getDigBlockPacket(BlockPos pos, CPacketPlayerDigging.Action action) {
        return new CPacketPlayerDigging(action, pos, BlockUtil.getRayTraceFacing(pos));
    }

    public static void rotateToPosition(BlockPos pos) {
        Client.rotationManager.setRotation(OldPacketMine.getLegitRotations(pos.func_177963_a(0.5, 0.5, 0.5))[0], OldPacketMine.getLegitRotations(pos.func_177963_a(0.5, 0.5, 0.5))[1]);
    }

    public static float[] getLegitRotations(BlockPos vec) {
        Vec3d eyesPos = RotationUtil.getEyesPos();
        double diffX = (double)vec.func_177958_n() - eyesPos.field_72450_a;
        double diffY = (double)vec.func_177956_o() - eyesPos.field_72448_b;
        double diffZ = (double)vec.func_177952_p() - eyesPos.field_72449_c;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{OldPacketMine.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g((float)(yaw - OldPacketMine.mc.field_71439_g.field_70177_z)), OldPacketMine.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g((float)(pitch - OldPacketMine.mc.field_71439_g.field_70125_A))};
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (OldPacketMine.fullNullCheck()) {
            return;
        }
        if (this.breakPos == null) {
            return;
        }
        RenderUtil.drawBoxESP(this.breakPos, new Color(100, 100, 240), false, new Color(240, 100, 100), 1.0f, true, true, 90, false);
    }

    @Override
    public void onEnable() {
        this.breakPos = null;
        this.instaTimer.reset();
        this.timer.reset();
        this.swapBack = false;
    }

    @Override
    public void onDisable() {
        this.breakPos = null;
    }

    @Override
    public void onTick() {
        if (!OldPacketMine.nullCheck()) {
            if (this.swapBack) {
                if (this.oldSlot != -1) {
                    UtilsRewrite.UInventory.heldItemChange(this.oldSlot, true, true, false);
                    if (this.debug.getValue().booleanValue()) {
                        this.sendModuleMessage("swapback!");
                    }
                }
                this.swapBack = false;
            }
            if (this.breakPos != null) {
                float breakTime;
                this.oldSlot = OldPacketMine.mc.field_71439_g.field_71071_by.field_70461_c;
                if (OldPacketMine.mc.field_71439_g.func_174818_b(this.breakPos) > MathUtil.square(this.resetRange.getValue().floatValue()) || OldPacketMine.mc.field_71441_e.func_180495_p(this.breakPos).func_177230_c() == Blocks.field_150350_a) {
                    this.breakPos = null;
                    this.breakFace = null;
                    this.readyToMine = false;
                    return;
                }
                if (this.autoRetry.getValue().booleanValue()) {
                    this.retry();
                }
                if (this.timer.passedMs((long)(breakTime = OldPacketMine.mc.field_71441_e.func_180495_p(this.breakPos).func_185887_b((World)OldPacketMine.mc.field_71441_e, this.breakPos) * 40.0f))) {
                    this.readyToMine = true;
                }
                if (this.timer.passedMs((long)breakTime) && OldPacketMine.bestSlot(this.breakPos) != -1) {
                    int best = OldPacketMine.bestSlot(this.breakPos);
                    UtilsRewrite.UInventory.heldItemChange(best, true, true, false);
                }
                OldPacketMine.rotateToPosition(this.breakPos);
                OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK));
                if (this.oldSlot != -1) {
                    OldPacketMine.mc.field_71439_g.field_71071_by.field_70461_c = this.oldSlot;
                    OldPacketMine.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.oldSlot));
                    UtilsRewrite.UInventory.heldItemChange(this.oldSlot, true, true, false);
                }
            }
        }
    }

    @SubscribeEvent
    public void onDamageBlock(BlockEvent event) {
        if (OldPacketMine.nullCheck()) {
            return;
        }
        RebirthUtil.facePosFacing(event.pos, event.facing);
        if (this.breakPos != null && event.pos.func_177986_g() == this.breakPos.func_177986_g() && this.timer.passedMs((long)(OldPacketMine.mc.field_71441_e.func_180495_p(this.breakPos).func_185887_b((World)OldPacketMine.mc.field_71441_e, this.breakPos) * 40.0f)) && OldPacketMine.bestSlot(event.pos) != -1) {
            if (!this.silent.getValue().booleanValue()) {
                OldPacketMine.mc.field_71439_g.field_71071_by.field_70461_c = OldPacketMine.bestSlot(this.breakPos);
            }
            UtilsRewrite.UInventory.heldItemChange(OldPacketMine.bestSlot(this.breakPos), false, true, false);
            OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK));
            this.swapBack = true;
            event.setCanceled(true);
            this.sendModuleMessage("send packet and canceled " + ChatFormatting.RED + "STOP_DESTROY_BLOCK" + ChatFormatting.RESET + " on pos " + UtilsRewrite.UBlock.getPosString(this.breakPos));
            return;
        }
        if (OldPacketMine.canBlockBeBroken(event.pos)) {
            if (this.breakPos != null) {
                OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK));
            }
            this.start = System.currentTimeMillis();
            this.timer.reset();
            this.instaTimer.reset();
            this.breakPos = event.pos;
            this.breakFace = event.facing;
            this.readyToMine = false;
            OldPacketMine.rotateToPosition(this.breakPos);
            OldPacketMine.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
            OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.START_DESTROY_BLOCK));
            OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK));
            if (this.debug.getValue().booleanValue()) {
                this.sendModuleMessage("breakblock " + UtilsRewrite.UBlock.getPosString(this.breakPos));
            }
            event.setCanceled(true);
        }
    }

    public void retry() {
        if (this.timer.passedMs((long)(OldPacketMine.mc.field_71441_e.func_180495_p(this.breakPos).func_185887_b((World)OldPacketMine.mc.field_71441_e, this.breakPos) * 40.0f)) && OldPacketMine.bestSlot(this.breakPos) != -1) {
            UtilsRewrite.UInventory.heldItemChange(OldPacketMine.bestSlot(this.breakPos), false, true, false);
            OldPacketMine.sP(OldPacketMine.getDigBlockPacket(this.breakPos, CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK));
        }
    }
}

