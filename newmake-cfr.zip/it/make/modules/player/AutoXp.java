/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemExpBottle
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.input.Mouse
 */
package it.make.modules.player;

import it.make.api.events.player.UpdateWalkingPlayerEvent;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.InventoryUtil;
import it.make.api.utils.second.skid.RotationUtil;
import it.make.modules.Module;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

public class AutoXp
extends Module {
    public static AutoXp INSTANCE;
    private final Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 1, 0, 5));
    public final Setting<Boolean> down = this.register(new Setting<Boolean>("Down", true));
    public final Setting<Boolean> allowGui = this.register(new Setting<Boolean>("allowGui", false));
    public final Setting<Boolean> checkDura = this.register(new Setting<Boolean>("CheckDura", true));
    private final Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.Key));
    public final Setting<Bind> throwBind = this.register(new Setting<Bind>("ThrowBind", new Bind(-1), v -> this.mode.getValue() == Mode.Key));
    private final Timer delayTimer = new Timer();

    public AutoXp() {
        super("AutoXP", "Robot module", Module.Category.PLAYER);
        INSTANCE = this;
    }

    @Override
    public String getInfo() {
        return this.mode.getValue().name();
    }

    @Override
    public void onTick() {
        if (this.isThrow() && this.delayTimer.passedMs(this.delay.getValue() * 20)) {
            this.throwExp();
        }
    }

    public void throwExp() {
        int oldSlot = AutoXp.mc.field_71439_g.field_71071_by.field_70461_c;
        int newSlot = InventoryUtil.findHotbarClass(ItemExpBottle.class);
        if (newSlot != -1) {
            AutoXp.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(newSlot));
            AutoXp.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            AutoXp.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(oldSlot));
            this.delayTimer.reset();
        }
    }

    @SubscribeEvent
    public void onWalk(UpdateWalkingPlayerEvent event) {
        if (AutoXp.fullNullCheck()) {
            return;
        }
        if (!this.down.getValue().booleanValue()) {
            return;
        }
        if (this.isThrow()) {
            RotationUtil.faceYawAndPitch(AutoXp.mc.field_71439_g.field_70177_z, 90.0f);
        }
    }

    public boolean isThrow() {
        if (this.isOff()) {
            return false;
        }
        if (!this.allowGui.getValue().booleanValue() && AutoXp.mc.field_71462_r != null) {
            return false;
        }
        if (InventoryUtil.findHotbarClass(ItemExpBottle.class) == -1) {
            return false;
        }
        if (this.checkDura.getValue().booleanValue()) {
            ItemStack helm = AutoXp.mc.field_71439_g.field_71069_bz.func_75139_a(5).func_75211_c();
            ItemStack chest = AutoXp.mc.field_71439_g.field_71069_bz.func_75139_a(6).func_75211_c();
            ItemStack legging = AutoXp.mc.field_71439_g.field_71069_bz.func_75139_a(7).func_75211_c();
            ItemStack feet = AutoXp.mc.field_71439_g.field_71069_bz.func_75139_a(8).func_75211_c();
            if (!(!helm.field_190928_g && this.getDamagePercent(helm) < 100 || !chest.field_190928_g && this.getDamagePercent(chest) < 100 || !legging.field_190928_g && this.getDamagePercent(legging) < 100 || !feet.field_190928_g && this.getDamagePercent(feet) < 100)) {
                return false;
            }
        }
        if (this.mode.getValue() == Mode.Middle && Mouse.isButtonDown((int)2)) {
            return true;
        }
        return this.mode.getValue() == Mode.Key && this.throwBind.getValue().isDown();
    }

    public int getDamagePercent(ItemStack stack) {
        return (int)((double)(stack.func_77958_k() - stack.func_77952_i()) / Math.max(0.1, (double)stack.func_77958_k()) * 100.0);
    }

    protected static enum Mode {
        Key,
        Middle;

    }
}

