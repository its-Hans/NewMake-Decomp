/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.EnumHand
 *  net.minecraft.world.World
 */
package it.make.modules.player;

import it.make.Client;
import it.make.api.setting.Bind;
import it.make.api.setting.Setting;
import it.make.api.utils.Timer;
import it.make.api.utils.second.skid.EntityUtil;
import it.make.api.utils.second.skid.InventoryUtil;
import it.make.api.utils.second.skid.RotationUtil;
import it.make.modules.Module;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class AutoExp
extends Module {
    Setting<Boolean> feetThrow = this.rbool("FeetThrow", true);
    Setting<Integer> throwSpeed = this.rinte("ThorwDelay", 20, 1, 1000);
    Setting<Bind> throwKey = this.rbind("ThrowKey", new Bind(0));
    Setting<Boolean> stopXp = this.rbool("StopXP", true);
    Setting<Boolean> noLowDurable = this.rbool("NoLowDurable", true, v -> this.stopXp.getValue());
    Setting<Integer> stopDurable = this.rinte("StopDurable", 100, 0, 100, v -> this.stopXp.getValue());
    Setting<Boolean> autoXp = this.rbool("AutoThrowXp", false);
    Setting<Integer> autoXpRange = this.rinte("AutoXpRange", 8, 0, 20, v -> this.autoXp.getValue());
    Setting<Boolean> takeoffArmor = this.rbool("TakeoffArmor", true, v -> this.stopXp.getValue());
    Setting<Integer> takeoffDurable = this.rinte("TakeoffDurable", 100, 0, 100, v -> this.takeoffArmor.getValue());
    Setting<Integer> takeoffDelay = this.rinte("Delay", 0, 0, 5, v -> this.takeoffArmor.getValue());
    Timer timer = new Timer();
    int delay_count;

    public AutoExp() {
        super("AutoExp", "AutoXp by KijinSeija", Module.Category.PLAYER, true, false, false);
    }

    @Override
    public void onUpdate() {
        if (!this.throwKey.getValue().isDown() || !this.timer.passedDms(this.throwSpeed.getValue().intValue())) {
            if (this.autoXp.getValue().booleanValue() && !this.isRangeNotPlayer(this.autoXpRange.getValue().intValue()).booleanValue()) {
                return;
            }
            if (!this.autoXp.getValue().booleanValue()) {
                return;
            }
        }
        if (this.stopXp.getValue().booleanValue() && (double)this.stopDurable.getValue().intValue() <= this.getArmorDurable(this.noLowDurable.getValue())) {
            return;
        }
        int XpSlot = InventoryUtil.getItemHotbar(Items.field_151062_by);
        if (XpSlot == -1) {
            return;
        }
        if (this.takeoffArmor.getValue().booleanValue()) {
            this.takeArmorOff();
        }
        int oldSlot = AutoExp.mc.field_71439_g.field_71071_by.field_70461_c;
        if (this.feetThrow.getValue().booleanValue()) {
            float yaw = AutoExp.mc.field_71439_g.field_71109_bG;
            RotationUtil.faceYawAndPitch(yaw, 90.0f);
        }
        InventoryUtil.switchToHotbarSlot(XpSlot, false);
        AutoExp.mc.field_71442_b.func_187101_a((EntityPlayer)AutoExp.mc.field_71439_g, (World)AutoExp.mc.field_71441_e, EnumHand.MAIN_HAND);
        InventoryUtil.switchToHotbarSlot(oldSlot, false);
    }

    public Double getArmorDurable(boolean getLowestValue) {
        ArrayList<Double> DurableList = new ArrayList<Double>();
        for (int i = 5; i <= 8; ++i) {
            ItemStack armor = (ItemStack)AutoExp.mc.field_71439_g.field_71069_bz.func_75138_a().get(i);
            double max_dam = armor.func_77958_k();
            double dam_left = armor.func_77958_k() - armor.func_77952_i();
            double percent = dam_left / max_dam * 100.0;
            DurableList.add(percent);
        }
        DurableList.sort(Comparator.naturalOrder());
        if (getLowestValue) {
            return (Double)DurableList.get(0);
        }
        return (Double)DurableList.get(DurableList.size() - 1);
    }

    private Boolean isRangeNotPlayer(double range) {
        EntityPlayer target = null;
        double distance = range;
        for (EntityPlayer player : AutoExp.mc.field_71441_e.field_73010_i) {
            if (EntityUtil.isntValid((Entity)player, range) || Client.friendManager.isFriend(player.func_70005_c_()) || AutoExp.mc.field_71439_g.field_70163_u - player.field_70163_u >= 5.0 || target != null && EntityUtil.mc.field_71439_g.func_70068_e((Entity)player) >= distance) continue;
            target = player;
            distance = EntityUtil.mc.field_71439_g.func_70068_e((Entity)player);
        }
        return target == null;
    }

    private ItemStack getArmor(int first) {
        return (ItemStack)AutoExp.mc.field_71439_g.field_71069_bz.func_75138_a().get(first);
    }

    private void takeArmorOff() {
        for (int slot = 5; slot <= 8; ++slot) {
            ItemStack item = this.getArmor(slot);
            double max_dam = item.func_77958_k();
            double dam_left = item.func_77958_k() - item.func_77952_i();
            double percent = dam_left / max_dam * 100.0;
            if (!(percent >= (double)this.takeoffDurable.getValue().intValue()) || item.func_77973_b() == Items.field_190931_a) continue;
            if (InventoryUtil.findItemInventorySlot(Items.field_190931_a, false) == -1) {
                return;
            }
            if (this.delay_count < this.takeoffDelay.getValue()) {
                ++this.delay_count;
                return;
            }
            this.delay_count = 0;
            AutoExp.mc.field_71442_b.func_187098_a(0, slot, 0, ClickType.QUICK_MOVE, (EntityPlayer)AutoExp.mc.field_71439_g);
        }
    }

    @Override
    public void onEnable() {
        this.delay_count = 0;
    }
}

