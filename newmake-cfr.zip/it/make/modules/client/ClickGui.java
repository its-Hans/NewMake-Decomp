/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.ResourceLocation
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package it.make.modules.client;

import it.make.Client;
import it.make.TweaksClient;
import it.make.api.events.client.ClientEvent;
import it.make.api.events.render.RenderGuiEvent;
import it.make.api.i18n.EnumI18N;
import it.make.api.i18n.I18NInfo;
import it.make.api.setting.Setting;
import it.make.api.utils.ColorUtil;
import it.make.features.guis.oyvey.OyVeyGui;
import it.make.features.guis.phobos.PhobosGui;
import it.make.modules.Module;
import java.awt.Color;
import java.util.function.Predicate;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickGui
extends Module {
    private static ClickGui INSTANCE = new ClickGui();
    public final Setting<Boolean> cleanGui = this.rbool("CleanGui", false);
    public final Setting<Boolean> blur = this.rbool("Blur", false);
    public Setting<GuiList> guiSelect = this.rother("GuiSelect", GuiList.Phobos);
    public Setting<Boolean> outline = this.register(new Setting<Object>("outline", Boolean.valueOf(true), v -> this.guiSelect.getValue() != GuiList.OyVey));
    public Setting<Integer> oRed = this.register(new Setting<Integer>("OutlineRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), this.lambda1()));
    public Setting<Integer> oGreen = this.register(new Setting<Integer>("OutlineGreen", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), this.lambda1()));
    public Setting<Integer> oBlue = this.register(new Setting<Integer>("OutlineBlue", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), this.lambda1()));
    public Setting<Integer> oAlpha = this.register(new Setting<Integer>("OutlineAlpha", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(255), this.lambda1()));
    public Setting<Integer> topAlpha = this.register(new Setting<Integer>("topAlpha", Integer.valueOf(150), Integer.valueOf(0), Integer.valueOf(255), this.lambda1()));
    public Setting<Boolean> openCloseString = this.register(new Setting<Boolean>("openAndClose", Boolean.valueOf(true), v -> this.guiSelect.getValue() != GuiList.OyVey));
    public Setting<String> moduleButton = this.register(new Setting<Object>("Buttons:", "", v -> this.openCloseString.getValue() == false));
    public Setting<String> openstring = this.register(new Setting<String>("openString", "", this.lambda2()));
    public Setting<String> closestring = this.register(new Setting<String>("closeString", "-", this.lambda2()));
    public Setting<Integer> red = this.register(new Setting<Integer>("Red", 0, 0, 255));
    public Setting<Integer> green = this.register(new Setting<Integer>("Green", 0, 0, 255));
    public Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 255, 0, 255));
    public Setting<Integer> hoverAlpha = this.register(new Setting<Integer>("Alpha", 180, 0, 255));
    public Setting<Integer> topRed = this.register(new Setting<Integer>("SecondRed", 0, 0, 255));
    public Setting<Integer> topGreen = this.register(new Setting<Integer>("SecondGreen", 0, 0, 255));
    public Setting<Integer> topBlue = this.register(new Setting<Integer>("SecondBlue", 150, 0, 255));
    public Setting<Integer> alpha = this.register(new Setting<Integer>("HoverAlpha", 240, 0, 255));
    public Setting<Boolean> rainbow = this.register(new Setting<Boolean>("Rainbow", false));
    public Setting<rainbowMode> rainbowModeHud = this.register(new Setting<Object>("HRainbowMode", (Object)rainbowMode.Static, v -> this.rainbow.getValue()));
    public Setting<rainbowModeArray> rainbowModeA = this.register(new Setting<Object>("ARainbowMode", (Object)rainbowModeArray.Static, v -> this.rainbow.getValue()));
    public Setting<Integer> rainbowHue = this.register(new Setting<Object>("Delay", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(600), v -> this.rainbow.getValue()));
    public Setting<Float> rainbowBrightness = this.register(new Setting<Object>("Brightness ", Float.valueOf(150.0f), Float.valueOf(1.0f), Float.valueOf(255.0f), v -> this.rainbow.getValue()));
    public Setting<Float> rainbowSaturation = this.register(new Setting<Object>("Saturation", Float.valueOf(150.0f), Float.valueOf(1.0f), Float.valueOf(255.0f), v -> this.rainbow.getValue()));
    boolean bl = false;

    public ClickGui() {
        super(new I18NInfo("ClickGui").bind(EnumI18N.Chinese, "\u70b9\u51fb\u754c\u9762"), "Opens the ClickGui", Module.Category.CLIENT, true, false, false);
        this.setInstance();
    }

    public static ClickGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ClickGui();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    public Predicate lambda1() {
        return v -> this.guiSelect.getValue() != GuiList.OyVey && this.outline.getValue() != false;
    }

    public Predicate lambda2() {
        return v -> this.guiSelect.getValue() == GuiList.Phobos && this.openCloseString.getValue() != false;
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting() == this.guiSelect) {
                this.refreshGui();
            }
            Client.colorManager.setColor(this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.hoverAlpha.getPlannedValue());
        }
    }

    @Override
    public void onEnable() {
        this.displayGui(this.nowGUI());
        this.bl = true;
    }

    public void refreshGui() {
        PhobosGui.refreshGui();
        OyVeyGui.refreshGui();
        if (this.isOn()) {
            this.toggle();
            this.toggle();
        }
    }

    @Override
    public void onDisable() {
        this.bl = false;
        this.deleteBlur();
        this.displayGui(null);
    }

    private void displayGui(GuiScreen gui) {
        mc.func_147108_a(gui);
        this.sendModuleMessage("Gui: " + gui);
    }

    @Override
    public void onLoad() {
        Client.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.hoverAlpha.getValue());
    }

    @Override
    public void onTick() {
        if (!this.bl) {
            return;
        }
        if (ClickGui.mc.field_71462_r != this.nowGUI()) {
            this.disable();
            if (TweaksClient.getInstance().autoSave.getValue().booleanValue()) {
                Client.configManager.saveConfigByCurrent();
            }
        }
    }

    public Color getGuiColor() {
        return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }

    public int getCurrentColorHex() {
        return ColorUtil.toARGB(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }

    public GuiScreen nowGUI() {
        GuiScreen gui;
        switch (this.guiSelect.getValue()) {
            case OyVey: {
                gui = OyVeyGui.getClickGui();
                break;
            }
            case Phobos: {
                gui = PhobosGui.getClickGui();
                break;
            }
            default: {
                gui = null;
            }
        }
        return gui;
    }

    @Override
    public void onUpdate() {
        if (this.blur.getValue().booleanValue()) {
            if (OpenGlHelper.field_148824_g && mc.func_175606_aa() instanceof EntityPlayer) {
                this.deleteBlur();
                this.drawBlur();
            }
        } else {
            this.deleteBlur();
        }
    }

    private void deleteBlur() {
        if (ClickGui.mc.field_71460_t.func_147706_e() != null) {
            ClickGui.mc.field_71460_t.func_147706_e().func_148021_a();
        }
    }

    private void drawBlur() {
        try {
            ClickGui.mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @SubscribeEvent
    public void onDrawGui(RenderGuiEvent event) {
        if (event.gui == RenderGuiEvent.Guis.DrawWorldBackground && ClickGui.mc.field_71462_r == this.nowGUI() && this.cleanGui.getValue().booleanValue()) {
            event.setCanceled(true);
        }
    }

    public static enum rainbowMode {
        Static,
        Sideway;

    }

    public static enum rainbowModeArray {
        Static,
        Up;

    }

    static enum GuiList {
        OyVey,
        Phobos;

    }
}

