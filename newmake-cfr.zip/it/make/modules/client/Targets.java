/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 */
package it.make.modules.client;

import it.make.Client;
import it.make.api.setting.Setting;
import it.make.api.utils.second.skid.EntityUtil;
import it.make.modules.Module;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class Targets
extends Module {
    public Setting<Float> range = this.rfloa("Range", Float.valueOf(5.4f), Float.valueOf(1.0f), Float.valueOf(10.0f));
    public Setting<Boolean> singleMode = this.rbool("SingleMode", false);
    static EntityPlayer cache;
    private static Targets INSTANCE;

    public Targets() {
        super("TargetControl", "Manage COMBAT!!", Module.Category.CLIENT, true, false, true);
        cache = null;
        INSTANCE = this;
    }

    public static Targets getInstance() {
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.disable();
    }

    @Override
    public void onDisable() {
        cache = null;
    }

    public static EntityPlayer getTarget() {
        if (Targets.mc.field_71441_e == null) {
            cache = null;
            return null;
        }
        float range = Targets.getInstance().range.getValue().floatValue();
        if (Targets.getInstance().needRefresh()) {
            cache = Targets.mc.field_71441_e.func_175661_b(EntityPlayer.class, Targets::canTarget).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < (double)(range * range)).min(Comparator.comparingDouble(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()))).orElse(null);
        }
        return cache;
    }

    public static EntityPlayer getTargetByRange(Double range) {
        if (Targets.mc.field_71441_e == null) {
            return null;
        }
        return Targets.mc.field_71441_e.func_175661_b(EntityPlayer.class, Targets::canTarget).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < range * range).min(Comparator.comparingDouble(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()))).orElse(null);
    }

    public static Entity getTargetByRange_Mob(Float range) {
        if (Targets.mc.field_71441_e == null) {
            return null;
        }
        return Targets.mc.field_71441_e.func_175644_a(Entity.class, Targets::canTarget2).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < (double)(range.floatValue() * range.floatValue())).min(Comparator.comparingDouble(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()))).orElse(null);
    }

    public static EntityPlayer getTargetByRange_Mob(Double range) {
        if (Targets.mc.field_71441_e == null) {
            return null;
        }
        return Targets.mc.field_71441_e.func_175644_a(EntityPlayer.class, Targets::canTarget2).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < range * range).min(Comparator.comparingDouble(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()))).orElse(null);
    }

    public static EntityPlayer getTargetByRange(Float range) {
        if (Targets.mc.field_71441_e == null) {
            return null;
        }
        return Targets.findPlayersByRange(range, Targets.mc.field_71441_e).stream().min(Comparator.comparingDouble(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()))).orElse(null);
    }

    public static List<EntityPlayer> findPlayersByRange(Float range, WorldClient world) {
        return world.func_175661_b(EntityPlayer.class, Targets::canTarget).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < (double)(range.floatValue() * range.floatValue())).collect(Collectors.toList());
    }

    public static List<Entity> findEntitiesByRange(Float range, WorldClient world) {
        return world.func_175644_a(Entity.class, Targets::canTarget3).stream().filter(player -> Targets.mc.field_71439_g.func_174831_c(player.func_180425_c()) < (double)(range.floatValue() * range.floatValue())).collect(Collectors.toList());
    }

    public static boolean canTarget(Entity entity) {
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            return !EntityUtil.isDead((Entity)player) && !player.equals((Object)Targets.mc.field_71439_g) && !Client.friendManager.isFriend(player);
        }
        return false;
    }

    public static boolean canTarget2(Entity entity) {
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            return !EntityUtil.isDead((Entity)player) && !player.equals((Object)Targets.mc.field_71439_g) && !Client.friendManager.isFriend(player);
        }
        return !EntityUtil.isDead(entity) && !entity.equals((Object)Targets.mc.field_71439_g) && EntityUtil.isHostileMob(entity);
    }

    public static boolean canTarget3(Entity entity) {
        boolean bl;
        boolean bl2 = bl = !EntityUtil.isDead(entity) && !entity.equals((Object)Targets.mc.field_71439_g);
        if (entity instanceof EntityPlayer) {
            return bl && !Client.friendManager.isFriend((EntityPlayer)entity);
        }
        return bl;
    }

    public boolean needRefresh() {
        if (cache == null) {
            return true;
        }
        if (!this.singleMode.getValue().booleanValue()) {
            return true;
        }
        float range = this.range.getValue().floatValue();
        return Targets.mc.field_71439_g.func_174831_c(cache.func_180425_c()) > (double)(range * range);
    }
}

