/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentString
 */
package it.make.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.api.events.render.Render2DEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.ColorUtil;
import it.make.api.utils.second.skid.FadeUtils;
import it.make.api.utils.second.skid.RenderUtil;
import it.make.modules.Module;
import it.make.modules.client.ClickGui;
import java.util.ArrayList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class NotifyModule
extends Module {
    static NotifyModule noti;
    public static final ArrayList<Notifys> notifyList;
    private final Setting<Boolean> chat = this.rbool("Chat", true);
    private final Setting<Boolean> noMulti = this.rbool("NoMulti", true, v -> this.chat.getValue());
    private final Setting<Boolean> render = this.rbool("Render", true);
    private final Setting<Integer> notifyY = this.rinte("Y", 18, 25, 500, v -> this.render.getValue());
    private final Setting<Integer> alpha = this.rinte("Alpha", 155, 0, 255, v -> this.render.getValue());

    public NotifyModule() {
        super("Notify", "Notify toggle module", Module.Category.CLIENT);
        noti = this;
    }

    public static NotifyModule getNoti() {
        if (noti == null) {
            noti = new NotifyModule();
        }
        return noti;
    }

    @Override
    public void onRender2D(Render2DEvent render2DEvent) {
        if (!this.render.getValue().booleanValue()) {
            return;
        }
        boolean bl = true;
        int n = this.renderer.scaledHeight - this.notifyY.getValue();
        int n2 = this.renderer.scaledWidth;
        int n3 = ColorUtil.toRGBA(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue());
        for (Notifys notifys : notifyList) {
            if (notifys == null || notifys.first == null || notifys.firstFade == null || notifys.delayed < 1) continue;
            bl = false;
            if (notifys.delayed < 5 && !notifys.end) {
                notifys.end = true;
                notifys.endFade.reset();
            }
            n = (int)((double)n - 18.0 * notifys.yFade.easeOutQuad());
            String string = notifys.first;
            double d = notifys.delayed < 5 ? (double)n2 - (double)(this.renderer.getStringWidth(string) + 10) * (1.0 - notifys.endFade.easeOutQuad()) : (double)n2 - (double)(this.renderer.getStringWidth(string) + 10) * notifys.firstFade.easeOutQuad();
            RenderUtil.drawRectangleCorrectly((int)d, n, 10 + this.renderer.getStringWidth(string), 15, ColorUtil.toRGBA(20, 20, 20, this.alpha.getValue()));
            this.renderer.drawString(string, 5 + (int)d, 4 + n, ColorUtil.toRGBA(255, 255, 255), true);
            if (notifys.delayed < 5) {
                n = (int)((double)n + 18.0 * notifys.yFade.easeOutQuad() - 18.0 * (1.0 - notifys.endFade.easeOutQuad()));
                continue;
            }
            RenderUtil.drawRectangleCorrectly((int)d, n + 14, (10 + this.renderer.getStringWidth(string)) * (notifys.delayed - 4) / 62, 1, n3);
        }
        if (bl) {
            notifyList.clear();
        }
    }

    @Override
    public void onUpdate() {
        for (Notifys notifys : notifyList) {
            if (notifys == null || notifys.first == null || notifys.firstFade == null) continue;
            --notifys.delayed;
        }
    }

    @Override
    public void onDisable() {
        notifyList.clear();
    }

    public void pushEnable(String moduleName) {
        this.pushString(ChatFormatting.AQUA + moduleName + ChatFormatting.GREEN + " on");
    }

    public void pushDisable(String moduleName) {
        this.pushString(ChatFormatting.AQUA + moduleName + ChatFormatting.RED + " off");
    }

    public void pushString(String string) {
        notifyList.add(new Notifys(string));
    }

    public void putModuleToggle(boolean enable, Module module) {
        if (!this.chat.getValue().booleanValue()) {
            return;
        }
        String message = ChatFormatting.GRAY + "Module " + ChatFormatting.RESET + ChatFormatting.DARK_GRAY + module.getDisplayName() + ChatFormatting.RESET + (enable ? ChatFormatting.GREEN + " on" : ChatFormatting.RED + " off" + ChatFormatting.RESET);
        if (this.noMulti.getValue().booleanValue()) {
            NotifyModule.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(message), 1);
        } else {
            this.sendModuleMessage(message);
        }
    }

    static {
        notifyList = new ArrayList();
    }

    public static class Notifys {
        public final FadeUtils firstFade = new FadeUtils(500L);
        public final FadeUtils endFade;
        public final FadeUtils yFade = new FadeUtils(500L);
        public final String first;
        public int delayed = 55;
        public boolean end;

        public Notifys(String string) {
            this.endFade = new FadeUtils(350L);
            this.first = string;
            this.firstFade.reset();
            this.yFade.reset();
            this.endFade.reset();
            this.end = false;
        }
    }
}

