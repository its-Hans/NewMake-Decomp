/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package it.make.features.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.features.commands.Command;

public class PrefixCommand
extends Command {
    public PrefixCommand() {
        super("prefix", new String[]{"<char>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.GREEN + "Current prefix is " + Client.commandManager.getPrefix());
            return;
        }
        Client.commandManager.setPrefixTwo(commands[0]);
        Command.sendMessage("Prefix changed to " + ChatFormatting.GRAY + Client.commandManager.getPrefix());
    }
}

