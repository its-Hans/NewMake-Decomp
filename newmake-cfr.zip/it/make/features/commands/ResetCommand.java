/*
 * Decompiled with CFR 0.152.
 */
package it.make.features.commands;

import it.make.Client;
import it.make.api.setting.Setting;
import it.make.features.commands.Command;
import it.make.modules.Module;

public class ResetCommand
extends Command {
    public ResetCommand() {
        super("reset", new String[]{"<module>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            ResetCommand.sendMessage("Please specify a module.");
            return;
        }
        String moduleName = commands[0];
        Module module = Client.moduleManager.getModuleByName(moduleName);
        if (module == null) {
            ResetCommand.sendMessage("Unknown module!");
            return;
        }
        for (Setting setting : module.settings) {
            if (setting.getName().equals(module.bind.getName()) || setting.getName().equals(module.enabled.getName())) continue;
            setting.setValue(setting.getDefaultValue());
        }
    }
}

