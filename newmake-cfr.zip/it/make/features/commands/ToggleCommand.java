/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package it.make.features.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.features.commands.Command;
import it.make.modules.Module;

public class ToggleCommand
extends Command {
    public ToggleCommand() {
        super("toggle", new String[]{"<module>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            ToggleCommand.sendMessage("Please specify a module.");
            return;
        }
        String moduleName = commands[0];
        Module module = Client.moduleManager.getModuleByName(moduleName);
        if (module == null) {
            ToggleCommand.sendMessage("Unknown module!");
            return;
        }
        String setMessage = "module " + ChatFormatting.AQUA + module.getDisplayName() + ChatFormatting.RESET + " now ";
        String green = ChatFormatting.GREEN + "on";
        String red = ChatFormatting.RED + "off";
        if (module.enabled.getValue().booleanValue()) {
            module.disable();
            ToggleCommand.sendMessage(setMessage + green);
        } else {
            module.enable();
            ToggleCommand.sendMessage(setMessage + red);
        }
    }
}

