/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package it.make.features.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.features.commands.Command;

public class HelpCommand
extends Command {
    public HelpCommand() {
        super("help");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("Commands: ");
        for (Command command : Client.commandManager.getCommands()) {
            HelpCommand.sendMessage(ChatFormatting.GRAY + Client.commandManager.getPrefix() + command.getName());
        }
    }
}

