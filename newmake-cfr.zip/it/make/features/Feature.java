/*
 * Decompiled with CFR 0.152.
 */
package it.make.features;

import it.make.Client;
import it.make.api.Wrapper;
import it.make.api.managers.TextManager;
import it.make.api.setting.Setting;
import it.make.features.guis.oyvey.OyVeyGui;
import it.make.features.guis.phobos.PhobosGui;
import it.make.modules.Module;
import java.util.ArrayList;
import java.util.List;

public class Feature
implements Wrapper {
    public List<Setting> settings = new ArrayList<Setting>();
    public TextManager renderer = Client.textManager;
    private String name;

    public Feature() {
    }

    public Feature(String name) {
        this.name = name;
    }

    public static boolean nullCheck() {
        return Feature.mc.field_71439_g == null;
    }

    public static boolean fullNullCheck() {
        return Feature.mc.field_71439_g == null || Feature.mc.field_71441_e == null;
    }

    public String getName() {
        return this.name;
    }

    public List<Setting> getSettings() {
        return this.settings;
    }

    public boolean hasSettings() {
        return !this.settings.isEmpty();
    }

    public boolean isEnabled() {
        if (this instanceof Module) {
            return ((Module)this).isOn();
        }
        return false;
    }

    public boolean isDisabled() {
        return !this.isEnabled();
    }

    public Setting register(Setting setting) {
        setting.setFeature(this);
        this.settings.add(setting);
        if (this instanceof Module) {
            Module m = (Module)this;
            if (Feature.mc.field_71462_r instanceof OyVeyGui) {
                OyVeyGui.getInstance().updateModule(m);
            }
            if (Feature.mc.field_71462_r instanceof PhobosGui) {
                PhobosGui.getInstance().updateModule(m);
            }
        }
        return setting;
    }

    public void unregister(Setting settingIn) {
        ArrayList<Setting> removeList = new ArrayList<Setting>();
        for (Setting setting : this.settings) {
            if (!setting.equals(settingIn)) continue;
            removeList.add(setting);
        }
        if (!removeList.isEmpty()) {
            this.settings.removeAll(removeList);
        }
        if (this instanceof Module) {
            Module m = (Module)this;
            if (Feature.mc.field_71462_r instanceof OyVeyGui) {
                OyVeyGui.getInstance().updateModule(m);
            }
            if (Feature.mc.field_71462_r instanceof PhobosGui) {
                PhobosGui.getInstance().updateModule(m);
            }
        }
    }

    public Setting getSettingByName(String name) {
        for (Setting setting : this.settings) {
            if (!setting.getName().equalsIgnoreCase(name)) continue;
            return setting;
        }
        return null;
    }

    public void reset() {
        for (Setting setting : this.settings) {
            setting.setValue(setting.getDefaultValue());
        }
    }

    public void clearSettings() {
        this.settings = new ArrayList<Setting>();
    }
}

