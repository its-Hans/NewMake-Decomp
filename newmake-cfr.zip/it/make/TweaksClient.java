/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.opengl.Display
 */
package it.make;

import com.mojang.realmsclient.gui.ChatFormatting;
import it.make.Client;
import it.make.api.events.client.ClientEvent;
import it.make.api.events.player.DeathEvent;
import it.make.api.setting.Setting;
import it.make.api.utils.TextUtil;
import it.make.modules.Module;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.Display;

public class TweaksClient
extends Module {
    static TweaksClient INSTANCE;
    public Map<EntityPlayer, Vec3d> deathPoints = new HashMap<EntityPlayer, Vec3d>();
    public Setting<String> clientName = this.register(new Setting<String>("ClientName", "Make.Life"));
    public Setting<String> cmLeft = this.register(new Setting<String>("cmLeft", "["));
    public Setting<String> cmRight = this.register(new Setting<String>("cmRight", "]"));
    public Setting<ChatFormatting> brColor = this.register(new Setting<ChatFormatting>("BracketColor", ChatFormatting.GOLD));
    public Setting<ChatFormatting> cmColor = this.register(new Setting<ChatFormatting>("MessageColor", ChatFormatting.DARK_AQUA));
    public Setting<String> clientPrefix = this.register(new Setting<String>("ClientPrefix", "-"));
    public Setting<String> clientTitle = this.register(new Setting<String>("ClientTitle", "Make.Life"));
    public Setting<Boolean> autoSave = this.register(new Setting<Boolean>("AutoSaving", true));
    public Setting<Boolean> deathBackup = this.rbool("DeathBackup", true);
    public static final String clientid = "makecc";
    public static final String clientname = "Make.Life";
    public static final String MessageLeft = "[";
    public static final String MessageRight = "]";
    public static final String clientversion = "0";
    public static final String simplecfgpath = "MakeCat";
    public static final String defaultPrefix = "-";
    public static final String title = "Make.Life";
    public static final String configpath = "MakeCat/";

    public TweaksClient() {
        super("ClientSetting", "set", Module.Category.CLIENT, true, false, true);
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        this.disable();
    }

    @SubscribeEvent
    public void onDeath(DeathEvent e) {
        if (!this.deathBackup.getValue().booleanValue()) {
            return;
        }
        if (e.player == TweaksClient.mc.field_71439_g) {
            // empty if block
        }
        this.deathPoints.remove(e.player);
        this.deathPoints.put(e.player, e.player.func_174791_d());
    }

    public static TweaksClient getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new TweaksClient();
        }
        return INSTANCE;
    }

    static String clientMessageLeft() {
        return TweaksClient.getInstance().brColor.getValue() + TweaksClient.getInstance().cmLeft.getValue() + TextUtil.RESET;
    }

    static String clientMessageRight() {
        return TweaksClient.getInstance().brColor.getValue() + TweaksClient.getInstance().cmRight.getValue() + TextUtil.RESET;
    }

    static String clentMessage() {
        return TweaksClient.getInstance().cmColor.getValue() + TweaksClient.getInstance().clientName.getValue() + TextUtil.RESET;
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        Setting setting;
        if (event.getStage() == 2 && (setting = event.getSetting()) != null && setting.getFeature().equals(this)) {
            TweaksClient.setClient();
        }
    }

    public static boolean setClient() {
        boolean name = TweaksClient.setClientName();
        boolean prefix = TweaksClient.setClientPrefix();
        boolean title = TweaksClient.setTitle();
        return name && prefix && title;
    }

    public static boolean setClientPre() {
        boolean name = TweaksClient.setClientName();
        boolean prefix = TweaksClient.setClientPrefix();
        boolean title = TweaksClient.setTitlePre();
        return name && prefix && title;
    }

    public static boolean setTitle() {
        if (!TweaksClient.isManagersLoaded()) {
            return false;
        }
        String ti = TweaksClient.getInstance().clientTitle.getValue();
        String getti = Display.getTitle();
        if (!Objects.equals(getti, ti)) {
            TweaksClient.setTitle(ti);
        }
        return Objects.equals(getti, ti);
    }

    public static boolean setTitlePre() {
        if (!TweaksClient.isManagersLoaded()) {
            return false;
        }
        String ti = TweaksClient.getInstance().clientTitle.getValue() + " Loading..";
        String getti = Display.getTitle();
        if (!Objects.equals(getti, ti)) {
            TweaksClient.setTitle(ti);
        }
        return Objects.equals(getti, ti);
    }

    public static boolean setClientName() {
        if (!TweaksClient.isManagersLoaded()) {
            return false;
        }
        String cm = TweaksClient.getCustomClientMessage();
        String getcm = Client.commandManager.getClientMessage();
        if (!Objects.equals(getcm, cm)) {
            Client.commandManager.setClientMessage(cm);
        }
        return Objects.equals(getcm, cm);
    }

    public static boolean setClientPrefix() {
        if (!TweaksClient.isManagersLoaded()) {
            return false;
        }
        String cp = TweaksClient.getInstance().clientPrefix.getValue();
        String getcp = Client.commandManager.getPrefix();
        if (!Objects.equals(getcp, cp)) {
            Client.commandManager.setPrefix(cp);
        }
        return Objects.equals(getcp, cp);
    }

    public static boolean isManagersLoaded() {
        if (Client.moduleManager == null || Client.commandManager == null) {
            Client.LOGGER.warn("cannot link managers");
            return false;
        }
        return true;
    }

    static void setTitle(String titleName) {
        if (!Objects.equals(titleName, "no")) {
            Display.setTitle((String)titleName);
        }
    }

    static String getCustomClientMessage() {
        return TweaksClient.clientMessageLeft() + TweaksClient.clentMessage() + TweaksClient.clientMessageRight();
    }

    public static TextUtil.Color toTextUtilColor(ChatFormatting color) {
        if (color == ChatFormatting.BLACK) {
            return TextUtil.Color.BLACK;
        }
        if (color == ChatFormatting.DARK_BLUE) {
            return TextUtil.Color.DARK_BLUE;
        }
        if (color == ChatFormatting.DARK_GREEN) {
            return TextUtil.Color.DARK_GREEN;
        }
        if (color == ChatFormatting.DARK_AQUA) {
            return TextUtil.Color.DARK_AQUA;
        }
        if (color == ChatFormatting.DARK_RED) {
            return TextUtil.Color.DARK_RED;
        }
        if (color == ChatFormatting.DARK_PURPLE) {
            return TextUtil.Color.DARK_PURPLE;
        }
        if (color == ChatFormatting.GOLD) {
            return TextUtil.Color.GOLD;
        }
        if (color == ChatFormatting.GRAY) {
            return TextUtil.Color.GRAY;
        }
        if (color == ChatFormatting.DARK_GRAY) {
            return TextUtil.Color.DARK_GRAY;
        }
        if (color == ChatFormatting.BLUE) {
            return TextUtil.Color.BLUE;
        }
        if (color == ChatFormatting.GREEN) {
            return TextUtil.Color.GREEN;
        }
        if (color == ChatFormatting.AQUA) {
            return TextUtil.Color.AQUA;
        }
        if (color == ChatFormatting.RED) {
            return TextUtil.Color.RED;
        }
        if (color == ChatFormatting.LIGHT_PURPLE) {
            return TextUtil.Color.LIGHT_PURPLE;
        }
        if (color == ChatFormatting.YELLOW) {
            return TextUtil.Color.YELLOW;
        }
        if (color == ChatFormatting.WHITE) {
            return TextUtil.Color.WHITE;
        }
        return TextUtil.Color.NONE;
    }
}

