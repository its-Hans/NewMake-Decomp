/*
 * Decompiled with CFR 0.152.
 */
package kotlin.comparisons;

import kotlin.Metadata;
import kotlin.comparisons.ComparisonsKt___ComparisonsKt;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/comparisons/ComparisonsKt__ComparisonsKt", "kotlin/comparisons/ComparisonsKt___ComparisonsJvmKt", "kotlin/comparisons/ComparisonsKt___ComparisonsKt"})
public final class ComparisonsKt
extends ComparisonsKt___ComparisonsKt {
    private ComparisonsKt() {
    }
}

