/*
 * Decompiled with CFR 0.152.
 */
package kotlin.coroutines.intrinsics;

import kotlin.Metadata;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt", "kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt"})
public final class IntrinsicsKt
extends IntrinsicsKt__IntrinsicsKt {
    private IntrinsicsKt() {
    }
}

