/*
 * Decompiled with CFR 0.152.
 */
package kotlin.contracts;

import kotlin.Metadata;
import kotlin.SinceKotlin;
import kotlin.contracts.Effect;
import kotlin.contracts.ExperimentalContracts;
import kotlin.internal.ContractsDsl;

@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bg\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"}, d2={"Lkotlin/contracts/ConditionalEffect;", "Lkotlin/contracts/Effect;", "kotlin-stdlib"})
@ContractsDsl
@ExperimentalContracts
@SinceKotlin(version="1.3")
public interface ConditionalEffect
extends Effect {
}

