/*
 * Decompiled with CFR 0.152.
 */
package kotlin.io.path;

import kotlin.Metadata;
import kotlin.io.path.PathsKt__PathUtilsKt;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/io/path/PathsKt__PathReadWriteKt", "kotlin/io/path/PathsKt__PathUtilsKt"})
public final class PathsKt
extends PathsKt__PathUtilsKt {
    private PathsKt() {
    }
}

