/*
 * Decompiled with CFR 0.152.
 */
package kotlin;

import kotlin.ExceptionsKt__ExceptionsKt;
import kotlin.Metadata;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/ExceptionsKt__ExceptionsKt"})
public final class ExceptionsKt
extends ExceptionsKt__ExceptionsKt {
    private ExceptionsKt() {
    }
}

