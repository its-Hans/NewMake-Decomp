/*
 * Decompiled with CFR 0.152.
 */
package kotlin.collections;

import kotlin.Metadata;
import kotlin.collections.GroupingKt__GroupingKt;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/collections/GroupingKt__GroupingJVMKt", "kotlin/collections/GroupingKt__GroupingKt"})
public final class GroupingKt
extends GroupingKt__GroupingKt {
    private GroupingKt() {
    }
}

