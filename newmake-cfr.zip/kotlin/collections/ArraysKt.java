/*
 * Decompiled with CFR 0.152.
 */
package kotlin.collections;

import kotlin.Metadata;
import kotlin.collections.ArraysKt___ArraysKt;

@Metadata(mv={1, 6, 0}, k=4, xi=49, d1={"kotlin/collections/ArraysKt__ArraysJVMKt", "kotlin/collections/ArraysKt__ArraysKt", "kotlin/collections/ArraysKt___ArraysJvmKt", "kotlin/collections/ArraysKt___ArraysKt"})
public final class ArraysKt
extends ArraysKt___ArraysKt {
    private ArraysKt() {
    }
}

